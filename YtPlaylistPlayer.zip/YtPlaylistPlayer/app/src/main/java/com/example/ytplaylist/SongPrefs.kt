package com.example.ytplaylist

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONArray
import org.json.JSONObject

/**
 * 곡마다 따로 기억하는 값들 (앱과 재생 서비스가 같이 써요).
 * - 메모, 시작 지점, 가사 싱크 조절
 * - 건너뛴/끝까지 들은 횟수 (똑똑한 셔플), 소리 세기 (분위기 이어 섞기)
 * - 앨범 색 (색으로 둘러보기), 목록에 들어온 시각 (새로 들어온 곡), 날짜별 들은 곡 (청취 달력)
 */
object SongPrefs {
    private var prefs: SharedPreferences? = null

    /** 화면이 바로 반응해야 하는 것들은 Compose 상태 맵으로 */
    val notes = mutableStateMapOf<String, String>()
    val startMs = mutableStateMapOf<String, Long>()
    val lyricOffset = mutableStateMapOf<String, Long>()

    private val skips = HashMap<String, Int>()
    private val dones = HashMap<String, Int>()
    private val energy = HashMap<String, Float>()
    private val colors = HashMap<String, Int>()
    private val addedAt = HashMap<String, Long>()
    private val days = HashMap<String, MutableList<String>>()

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("yt", Context.MODE_PRIVATE)
        prefs = p
        readStr(p, "sp_notes") { k, v -> notes[k] = v }
        readNum(p, "sp_start") { k, v -> startMs[k] = v.toLong() }
        readNum(p, "sp_lyoff") { k, v -> lyricOffset[k] = v.toLong() }
        readNum(p, "sp_skip") { k, v -> skips[k] = v.toInt() }
        readNum(p, "sp_done") { k, v -> dones[k] = v.toInt() }
        readNum(p, "sp_energy") { k, v -> energy[k] = v.toFloat() }
        readNum(p, "sp_color") { k, v -> colors[k] = v.toInt() }
        readNum(p, "sp_added") { k, v -> addedAt[k] = v.toLong() }
        runCatching {
            val o = JSONObject(p.getString("sp_days", "{}") ?: "{}")
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                days[k] = MutableList(a.length()) { a.getString(it) }
            }
        }
    }

    // ---------------- 메모 / 시작 지점 / 가사 싱크 ----------------
    fun setNote(url: String, text: String) {
        if (text.isBlank()) notes.remove(url) else notes[url] = text.trim()
        writeStr("sp_notes", notes)
    }

    fun setStart(url: String, ms: Long) {
        if (ms <= 0) startMs.remove(url) else startMs[url] = ms
        writeNum("sp_start", startMs)
    }

    fun nudgeLyrics(url: String, deltaMs: Long) {
        val v = (lyricOffset[url] ?: 0L) + deltaMs
        if (v == 0L) lyricOffset.remove(url) else lyricOffset[url] = v
        writeNum("sp_lyoff", lyricOffset)
    }

    // ---------------- 건너뛰기 / 끝까지 ----------------
    @Synchronized
    fun markSkip(url: String) {
        skips[url] = (skips[url] ?: 0) + 1
        writeNum("sp_skip", skips)
    }

    @Synchronized
    fun markDone(url: String) {
        dones[url] = (dones[url] ?: 0) + 1
        writeNum("sp_done", dones)
    }

    /** 셔플에서 얼마나 자주 나올지 (끝까지 들으면 ↑, 자주 넘기면 ↓) */
    @Synchronized
    fun weight(url: String): Double {
        val s = skips[url] ?: 0
        val d = dones[url] ?: 0
        return ((1.0 + d) / (1.0 + 2.0 * s)).coerceIn(0.15, 4.0)
    }

    fun skipCount(url: String): Int = skips[url] ?: 0

    // ---------------- 소리 세기 (분위기) ----------------
    @Synchronized
    fun putEnergy(url: String, v: Float) {
        val old = energy[url]
        energy[url] = if (old == null) v else old * 0.6f + v * 0.4f
        writeNum("sp_energy", energy)
    }

    @Synchronized
    fun energyOf(url: String): Float? = energy[url]

    // ---------------- 색 ----------------
    @Synchronized
    fun colorOf(url: String): Int? = colors[url]

    @Synchronized
    fun putColors(map: Map<String, Int>) {
        colors.putAll(map)
        writeNum("sp_color", colors)
    }

    // ---------------- 들어온 시각 ----------------
    @Synchronized
    fun markAdded(urls: Collection<String>) {
        val now = System.currentTimeMillis()
        var changed = false
        for (u in urls) if (u !in addedAt) { addedAt[u] = now; changed = true }
        if (changed) writeNum("sp_added", addedAt)
    }

    @Synchronized
    fun addedTime(url: String): Long = addedAt[url] ?: 0L

    /** 처음 한 번: 이미 있던 곡들은 '새 곡'이 아닌 것으로 */
    @Synchronized
    fun seedOld(urls: Collection<String>) {
        for (u in urls) if (u !in addedAt) addedAt[u] = 1L
        writeNum("sp_added", addedAt)
    }

    // ---------------- 날짜별 들은 곡 ----------------
    @Synchronized
    fun addDay(day: String, url: String) {
        val l = days.getOrPut(day) { mutableListOf() }
        if (url in l) return
        l.add(url)
        if (l.size > 60) l.removeAt(0)
        // 1년치만
        if (days.size > 400) days.keys.sorted().take(days.size - 400).forEach { days.remove(it) }
        val o = JSONObject()
        for ((k, v) in days) o.put(k, JSONArray(v))
        prefs?.edit()?.putString("sp_days", o.toString())?.apply()
    }

    @Synchronized
    fun dayUrls(day: String): List<String> = days[day]?.toList() ?: emptyList()

    // ---------------- 저장 도우미 ----------------
    private fun readStr(p: SharedPreferences, key: String, put: (String, String) -> Unit) = runCatching {
        val o = JSONObject(p.getString(key, "{}") ?: "{}")
        for (k in o.keys()) put(k, o.getString(k))
    }

    private fun readNum(p: SharedPreferences, key: String, put: (String, Double) -> Unit) = runCatching {
        val o = JSONObject(p.getString(key, "{}") ?: "{}")
        for (k in o.keys()) put(k, o.getDouble(k))
    }

    private fun writeStr(key: String, m: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        prefs?.edit()?.putString(key, o.toString())?.apply()
    }

    private fun writeNum(key: String, m: Map<String, Number>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        prefs?.edit()?.putString(key, o.toString())?.apply()
    }
}
