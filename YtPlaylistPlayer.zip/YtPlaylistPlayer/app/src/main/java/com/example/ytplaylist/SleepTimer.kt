package com.example.ytplaylist

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** 재생 서비스에서 만든 플레이어를 앱 안 어디서든 쓰기 위한 보관소 */
object PlayerHolder {
    @Volatile var player: ExoPlayer? = null
}

/** 수면 타이머: 정해진 시간 뒤(또는 현재 곡이 끝나면) 소리를 서서히 줄이고 멈춤 */
object SleepTimer {
    var remainingMs by mutableLongStateOf(0L)
    var endOfTrack by mutableStateOf(false)

    private val handler = Handler(Looper.getMainLooper())

    val active: Boolean get() = remainingMs > 0L || endOfTrack

    private val tick = object : Runnable {
        override fun run() {
            remainingMs -= 1000L
            if (remainingMs <= 0L) {
                remainingMs = 0L
                fadeOutAndPause()
            } else {
                handler.postDelayed(this, 1000L)
            }
        }
    }

    private val endListener = object : Player.Listener {
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) {
                clearEndOfTrack()
            }
        }
    }

    fun startMinutes(min: Int) {
        cancel()
        remainingMs = min * 60_000L
        handler.postDelayed(tick, 1000L)
    }

    fun startEndOfTrack() {
        cancel()
        val p = PlayerHolder.player ?: return
        endOfTrack = true
        p.pauseAtEndOfMediaItems = true
        p.addListener(endListener)
    }

    fun cancel() {
        handler.removeCallbacks(tick)
        remainingMs = 0L
        clearEndOfTrack()
    }

    private fun clearEndOfTrack() {
        if (!endOfTrack) return
        endOfTrack = false
        PlayerHolder.player?.let {
            it.pauseAtEndOfMediaItems = false
            it.removeListener(endListener)
        }
    }

    private fun fadeOutAndPause() {
        val p = PlayerHolder.player ?: return
        val steps = 15
        var step = 0
        val r = object : Runnable {
            override fun run() {
                step++
                p.volume = (1f - step / steps.toFloat()).coerceAtLeast(0f)
                if (step >= steps) {
                    p.pause()
                    p.volume = 1f
                } else {
                    handler.postDelayed(this, 200L)
                }
            }
        }
        handler.post(r)
    }
}
