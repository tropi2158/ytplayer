@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.ytplaylist

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.util.Calendar

// ======================= 유튜브 검색 =======================

@Composable
fun SearchSheet(vm: MainViewModel, onDismiss: () -> Unit, onTrackMenu: (Track, String, Int) -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var text by remember { mutableStateOf(vm.lastQuery) }
    val keyboard = LocalSoftwareKeyboardController.current
    LaunchedEffect(vm.lastQuery) { if (vm.lastQuery.isNotEmpty()) text = vm.lastQuery }
    val go = {
        keyboard?.hide()
        vm.search(text)
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.92f).padding(horizontal = 16.dp)) {
            Text("유튜브에서 찾기", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            GlassSurface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                TextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("곡 제목이나 가수 이름") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (text.isNotEmpty()) IconButton(onClick = { text = "" }) { Icon(Icons.Default.Close, "지우기") }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { go() }),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Text(
                "누르면 바로 재생, 길게 누르면 좋아요·플레이리스트에 담기 메뉴가 나와요",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            when {
                vm.searching -> SkeletonList(Modifier.weight(1f))
                vm.searchError != null -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(vm.searchError ?: "", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
                else -> {
                    val results = vm.searchResults
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
                        itemsIndexed(results, key = { i, t -> "$i${t.url}" }) { i, t ->
                            val isCurrent = vm.playingPid == SEARCH_PID && t.url == vm.playingUrl
                            TrackRow(
                                t = t,
                                selected = isCurrent,
                                playing = isCurrent && vm.isPlaying,
                                cached = false,
                                pinned = false,
                                favorite = vm.isFavorite(t.url),
                                dimmed = false,
                                onClick = { vm.playList(results, SEARCH_PID, i) },
                                onLongClick = { onTrackMenu(t, SEARCH_PID, i) },
                                onSwipeRight = { vm.playNext(t, SEARCH_PID) },
                                onSwipeLeft = { vm.addToQueue(t, SEARCH_PID) },
                                modifier = Modifier.animateItem()
                            )
                        }
                    }
                }
            }
        }
    }
}

// ======================= 청취 통계 =======================

private fun minutesLabel(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60}시간 ${m % 60}분" else "${m}분"
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    GlassSurface(modifier = modifier, shape = RoundedCornerShape(20.dp), strong = true) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

/** 막대 그래프 (값 목록, 아래 이름표) */
@Composable
private fun Bars(values: List<Long>, labels: List<String>, highlight: Int) {
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)
    val max = (values.maxOrNull() ?: 0L).coerceAtLeast(1L)
    Column {
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val n = values.size
            val gap = size.width / n * 0.28f
            val bw = size.width / n - gap
            values.forEachIndexed { i, v ->
                val h = (v.toFloat() / max) * size.height
                val x = i * (bw + gap) + gap / 2
                drawRoundRect(
                    if (i == highlight) primary else dim.copy(alpha = if (v > 0) 0.45f else 0.18f),
                    topLeft = Offset(x, size.height - h.coerceAtLeast(3f)),
                    size = Size(bw, h.coerceAtLeast(3f)),
                    cornerRadius = CornerRadius(bw / 3)
                )
            }
        }
        Row(Modifier.fillMaxWidth()) {
            labels.forEach {
                Text(
                    it,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun StatsSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var version by remember { mutableIntStateOf(0) }
    val snap = remember(version) { vm.statsSnapshot() }
    val now = System.currentTimeMillis()
    val days = (6 downTo 0).map { now - it * 86_400_000L }
    val dayValues = days.map { snap.daily[Stats.dayKey(it)] ?: 0L }
    val dayNames = listOf("일", "월", "화", "수", "목", "금", "토")
    val dayLabels = days.map { val c = Calendar.getInstance(); c.timeInMillis = it; dayNames[c.get(Calendar.DAY_OF_WEEK) - 1] }
    val top = snap.tracks.filter { it.count > 0 }.sortedWith(compareByDescending<Stats.TrackStat> { it.count }.thenByDescending { it.ms }).take(10)
    val hourNow = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val peak = snap.hourly.withIndex().maxByOrNull { it.value }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("청취 통계", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("오늘", minutesLabel(dayValues.last()), Modifier.weight(1f))
                StatTile("최근 7일", minutesLabel(dayValues.sum()), Modifier.weight(1f))
                StatTile("들은 곡", "${snap.tracks.size}곡", Modifier.weight(1f))
            }

            Text("최근 7일", style = MaterialTheme.typography.titleSmall)
            Bars(dayValues, dayLabels, dayValues.lastIndex)

            Text("자주 듣는 시간대", style = MaterialTheme.typography.titleSmall)
            Bars(snap.hourly, (0 until 24).map { if (it % 6 == 0) "${it}시" else "" }, hourNow)
            if (peak != null && peak.value > 0) {
                Text(
                    "주로 ${peak.index}시쯤 가장 많이 들어요",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("많이 들은 곡", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                if (top.isNotEmpty()) {
                    GlassSurface(shape = RoundedCornerShape(16.dp), tint = MaterialTheme.colorScheme.primary, onClick = { vm.playTopTracks() }) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("모아 듣기", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
            if (top.isEmpty()) {
                Text(
                    "아직 기록이 없어요. 한 곡을 30초 이상 들으면 1회로 기록돼요",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            top.forEachIndexed { i, t ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { vm.playTrackIn(t.pid, t.url) }.padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${i + 1}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.width(26.dp))
                    AsyncImage(
                        model = t.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.shownTitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${t.count}회 · ${minutesLabel(t.ms)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            TextButton(onClick = { vm.clearStats(); version++ }) { Text("기록 초기화") }
        }
    }
}

// ======================= 섞어 듣기 =======================

@Composable
fun MixDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val candidates = vm.playlists.filter { it.tracks.isNotEmpty() }
    var picked by remember { mutableStateOf(candidates.filter { it.id != FAV_ID }.map { it.id }.toSet()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("섞어 듣기") },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                Text(
                    "고른 플레이리스트의 곡을 한데 모아 섞어서 재생해요",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                candidates.forEach { p ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .clickable { picked = if (p.id in picked) picked - p.id else picked + p.id }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = p.id in picked,
                            onCheckedChange = { picked = if (it) picked + p.id else picked - p.id }
                        )
                        Text(
                            "${if (p.id == FAV_ID) "좋아요" else p.name} (${p.tracks.size})",
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.playMix(picked); onDismiss() }, enabled = picked.isNotEmpty()) { Text("섞어서 재생") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}

// ======================= 태그 =======================

@Composable
fun TagDialog(vm: MainViewModel, pid: String, onDismiss: () -> Unit) {
    val p = vm.playlists.firstOrNull { it.id == pid } ?: run { onDismiss(); return }
    var text by remember { mutableStateOf(p.tag) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("태그 정하기") },
        text = {
            Column {
                Text(
                    "운동, 공부, 잠잘 때처럼 묶어두면 홈에서 태그별로 골라 볼 수 있어요",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = text, onValueChange = { text = it.take(12) }, singleLine = true, label = { Text("태그") })
                if (vm.tags.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        vm.tags.forEach { t -> AssistChip(onClick = { text = t }, label = { Text("#$t") }) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.updateTag(pid, text); onDismiss() }) { Text("저장") } },
        dismissButton = {
            TextButton(onClick = { vm.updateTag(pid, ""); onDismiss() }) { Text("태그 없애기") }
        }
    )
}
