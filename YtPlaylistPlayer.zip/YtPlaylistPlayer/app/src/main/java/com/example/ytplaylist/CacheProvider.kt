@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.ContentMetadata
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File

/**
 * 오디오 저장소 두 종류 (프로세스당 하나씩만 존재해야 함)
 * - 자동 캐시: 들은 곡이 저장되고, 용량을 넘으면 오래된 곡부터 삭제
 * - 오프라인 저장: 사용자가 직접 저장한 곡. 자동으로 지워지지 않음
 */
object CacheProvider {
    const val DEFAULT_MB = 1024

    @Volatile private var auto: SimpleCache? = null
    @Volatile private var pinned: SimpleCache? = null
    @Volatile private var dbProvider: StandaloneDatabaseProvider? = null

    private fun db(ctx: Context): StandaloneDatabaseProvider = dbProvider ?: synchronized(this) {
        dbProvider ?: StandaloneDatabaseProvider(ctx.applicationContext).also { dbProvider = it }
    }

    /** 자동 캐시 최대 용량 (설정값, 앱을 완전히 다시 켜야 반영됨) */
    fun maxBytes(ctx: Context): Long =
        ctx.applicationContext.getSharedPreferences("yt", Context.MODE_PRIVATE)
            .getInt("cache_mb", DEFAULT_MB) * 1024L * 1024L

    fun get(ctx: Context): SimpleCache = auto ?: synchronized(this) {
        auto ?: SimpleCache(
            File(ctx.applicationContext.cacheDir, "audio_cache"),
            LeastRecentlyUsedCacheEvictor(maxBytes(ctx)),
            db(ctx)
        ).also { auto = it }
    }

    fun getPinned(ctx: Context): SimpleCache = pinned ?: synchronized(this) {
        pinned ?: SimpleCache(
            File(ctx.applicationContext.filesDir, "pinned_cache"),
            NoOpCacheEvictor(),
            db(ctx)
        ).also { pinned = it }
    }

    fun isFullyCached(c: SimpleCache, key: String): Boolean {
        val len = ContentMetadata.getContentLength(c.getContentMetadata(key))
        return len > 0 && c.isCached(key, 0, len)
    }

    fun clear(ctx: Context) {
        val c = get(ctx)
        c.keys.toList().forEach { runCatching { c.removeResource(it) } }
    }

    fun clearPinned(ctx: Context) {
        val c = getPinned(ctx)
        c.keys.toList().forEach { runCatching { c.removeResource(it) } }
    }

    fun removePinned(ctx: Context, urls: Collection<String>) {
        val c = getPinned(ctx)
        urls.forEach { runCatching { c.removeResource(it) } }
    }
}
