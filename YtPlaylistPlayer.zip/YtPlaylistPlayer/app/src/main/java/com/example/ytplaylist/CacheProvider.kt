@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.ContentMetadata
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File

/** 서비스와 화면이 같이 쓰는 오디오 캐시 (프로세스당 하나만 존재해야 함) */
object CacheProvider {
    const val MAX_BYTES = 1024L * 1024 * 1024 // 1GB, 넘으면 오래된 곡부터 삭제

    @Volatile private var cache: SimpleCache? = null

    fun get(context: Context): SimpleCache = cache ?: synchronized(this) {
        cache ?: SimpleCache(
            File(context.applicationContext.cacheDir, "audio_cache"),
            LeastRecentlyUsedCacheEvictor(MAX_BYTES),
            StandaloneDatabaseProvider(context.applicationContext)
        ).also { cache = it }
    }

    fun isFullyCached(c: SimpleCache, key: String): Boolean {
        val len = ContentMetadata.getContentLength(c.getContentMetadata(key))
        return len > 0 && c.isCached(key, 0, len)
    }

    fun clear(context: Context) {
        val c = get(context)
        c.keys.toList().forEach { runCatching { c.removeResource(it) } }
    }
}
