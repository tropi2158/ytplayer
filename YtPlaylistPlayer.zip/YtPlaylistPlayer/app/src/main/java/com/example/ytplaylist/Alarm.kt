package com.example.ytplaylist

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** 음악 알람 예약 (매일 같은 시간, 정해진 플레이리스트를 서서히 커지는 소리로 재생) */
object AlarmScheduler {
    const val ACTION_ALARM = "com.example.ytplaylist.ALARM"

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("yt", Context.MODE_PRIVATE)

    private fun pending(ctx: Context): PendingIntent = PendingIntent.getForegroundService(
        ctx.applicationContext, 77,
        Intent(ctx.applicationContext, PlaybackService::class.java).setAction(ACTION_ALARM),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return false
        return am.canScheduleExactAlarms()
    }

    fun nextTrigger(h: Int, m: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis() + 5_000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    /** 설정대로 다음 알람을 예약해요. 권한이 없으면 false */
    fun schedule(ctx: Context): Boolean {
        val p = prefs(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return false
        if (!p.getBoolean("alarm_on", false)) {
            am.cancel(pending(ctx))
            return true
        }
        if (!canExact(ctx)) return false
        val t = nextTrigger(p.getInt("alarm_h", 7), p.getInt("alarm_m", 0))
        val show = PendingIntent.getActivity(
            ctx.applicationContext, 78, Intent(ctx.applicationContext, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pending(ctx))
            true
        } catch (e: SecurityException) {
            false
        }
    }
}

/** 폰을 다시 켜면 알람을 다시 예약 */
class AlarmBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.schedule(context)
    }
}
