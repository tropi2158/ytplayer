package com.example.ytplaylist

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.LayoutCoordinates

/**
 * 미니 플레이어의 작은 아트 <-> 재생 화면의 큰 아트 위치를 공유해서,
 * 펼치고 접는 동안 아트 한 장이 두 자리 사이를 날아가게 해요.
 */
object ArtMorph {
    /** 재생 화면 패널(움직이는 판)의 좌표. 큰 아트 위치를 '다 펼쳤을 때' 기준으로 구하는 데 써요 */
    var panel: LayoutCoordinates? = null
    var mini by mutableStateOf(Rect.Zero)
    var big by mutableStateOf(Rect.Zero)
    var flying by mutableStateOf(false)

    fun measureBig(c: LayoutCoordinates) {
        val p = panel ?: return
        if (!p.isAttached || !c.isAttached) return
        big = p.localBoundingBoxOf(c, clipBounds = false)
    }
}


/** 지금 곡 앨범에서 뽑은 포인트 색 (재생 바, 켜진 셔플/반복, 하트, 재생 버튼 글자) */
object AlbumAccent {
    var color by mutableStateOf(androidx.compose.ui.graphics.Color.White)
        private set

    fun update(cols: List<androidx.compose.ui.graphics.Color>) {
        val hsv = FloatArray(3)
        var best: FloatArray? = null
        for (c in cols) {
            val f = FloatArray(3)
            android.graphics.Color.colorToHSV(
                android.graphics.Color.rgb((c.red * 255).toInt(), (c.green * 255).toInt(), (c.blue * 255).toInt()), f
            )
            if (best == null || f[1] * f[2] > best[1] * best[2]) best = f
        }
        val b = best
        color = if (b == null || b[1] < 0.18f || b[2] < 0.15f) {
            androidx.compose.ui.graphics.Color.White
        } else {
            hsv[0] = b[0]
            hsv[1] = b[1].coerceIn(0.35f, 0.62f) // 너무 쨍하지 않게
            hsv[2] = 1f                         // 어두운 배경에서 잘 보이게 밝게
            androidx.compose.ui.graphics.Color(android.graphics.Color.HSVToColor(hsv))
        }
    }
}
