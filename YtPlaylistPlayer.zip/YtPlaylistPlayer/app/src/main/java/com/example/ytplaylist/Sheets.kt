@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ytplaylist

import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlin.math.roundToInt

// ======================= 재생 도구 대화상자 =======================

fun speedLabel(v: Float): String =
    if (v == v.roundToInt().toFloat()) "${v.roundToInt()}.0x" else "${v}x"

@Composable
fun SleepTimerDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("수면 타이머") },
        text = {
            Column {
                if (SleepTimer.active) {
                    Text(
                        if (SleepTimer.endOfTrack) "현재 곡이 끝나면 멈춰요"
                        else "${fmtTime(SleepTimer.remainingMs)} 뒤에 서서히 멈춰요",
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                listOf(15, 30, 45, 60, 90).forEach { m ->
                    TextButton(onClick = { SleepTimer.startMinutes(m); onDismiss() }) { Text("${m}분 뒤") }
                }
                TextButton(onClick = { SleepTimer.startEndOfTrack(); onDismiss() }) { Text("현재 곡이 끝나면") }
            }
        },
        confirmButton = {
            if (SleepTimer.active) TextButton(onClick = { SleepTimer.cancel(); onDismiss() }) { Text("타이머 끄기") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("닫기") } }
    )
}

@Composable
fun SpeedDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("재생 속도") },
        text = {
            Column {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .clickable { vm.updateSpeed(s); onDismiss() }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (s == 1f) "보통 (1.0x)" else speedLabel(s), modifier = Modifier.weight(1f))
                        if (vm.speed == s) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("닫기") } }
    )
}

// ======================= 대기열 =======================

@Composable
fun QueueSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val q = vm.queue
    val curPos = q.indexOfFirst { it.index == vm.currentIndex }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (curPos - 2).coerceAtLeast(0))
    val glass = LocalGlass.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = if (glass) 0.9f else 1f)
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("재생 대기열", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${q.size}곡", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                if (vm.shuffle) "셔플 순서로 보여줘요. 셔플 중에는 순서를 바꿀 수 없어요"
                else "화살표로 순서를 바꾸고, X로 대기열에서 빼요",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            if (q.isEmpty()) {
                Text("대기열이 비어 있어요", modifier = Modifier.padding(vertical = 32.dp).align(Alignment.CenterHorizontally))
            }
            LazyColumn(state = listState, modifier = Modifier.heightIn(max = 560.dp)) {
                itemsIndexed(q, key = { _, e -> e.index }) { pos, e ->
                    val isCur = e.index == vm.currentIndex
                    val rowMod = Modifier.animateItem().fillMaxWidth().padding(vertical = 2.dp)
                    val inner: @Composable () -> Unit = {
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.queuePlay(e.index) }.padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${pos + 1}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.width(30.dp)
                            )
                            AsyncImage(
                                model = e.art, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    e.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (isCur) FontWeight.SemiBold else FontWeight.Normal
                                )
                                Text(
                                    e.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (!vm.shuffle) {
                                IconButton(onClick = { vm.queueMove(e.index, e.index - 1) }, enabled = e.index > 0) {
                                    Icon(Icons.Default.KeyboardArrowUp, "위로")
                                }
                                IconButton(onClick = { vm.queueMove(e.index, e.index + 1) }, enabled = e.index < q.size - 1) {
                                    Icon(Icons.Default.KeyboardArrowDown, "아래로")
                                }
                            }
                            if (!isCur) {
                                IconButton(onClick = { vm.queueRemove(e.index) }) {
                                    Icon(Icons.Default.Close, "빼기", Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                    if (isCur) {
                        GlassSurface(modifier = rowMod, shape = RoundedCornerShape(14.dp), tint = MaterialTheme.colorScheme.primary) { inner() }
                    } else {
                        Box(rowMod.clip(RoundedCornerShape(14.dp))) { inner() }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ======================= 곡 길게 누르기 메뉴 =======================

@Composable
private fun MenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    val tick = rememberTick()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { tick(); onClick() }
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null)
        Spacer(Modifier.width(16.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun TrackMenuSheet(
    vm: MainViewModel,
    t: Track,
    pid: String,
    index: Int,
    onDismiss: () -> Unit,
    onNewPlaylist: (Track) -> Unit
) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val uri = LocalUriHandler.current
    val ctx = LocalContext.current
    val fav = vm.isFavorite(t.url)
    val owner = vm.playlists.firstOrNull { it.id == pid }
    val canRemove = owner != null && owner.url.isBlank()
    var pickTarget by remember { mutableStateOf(false) }
    val targets = vm.playlists.filter { it.url.isBlank() && it.id != FAV_ID && it.id != pid }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                AsyncImage(
                    model = t.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(56.dp).clip(RoundedCornerShape(12.dp))
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(t.artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            HorizontalDivider()
            if (!pickTarget) {
                MenuRow(Icons.Default.SkipNext, "다음에 재생") { vm.playNext(t, pid); onDismiss() }
                MenuRow(Icons.Default.QueueMusic, "대기열에 추가") { vm.addToQueue(t, pid); onDismiss() }
                MenuRow(
                    if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    if (fav) "좋아요 취소" else "좋아요"
                ) { vm.toggleFavorite(t); onDismiss() }
                MenuRow(Icons.Default.PlaylistAdd, "내 플레이리스트에 추가") { pickTarget = true }
                MenuRow(Icons.Default.OpenInNew, "유튜브에서 열기") {
                    runCatching { uri.openUri(t.url) }
                    onDismiss()
                }
                MenuRow(Icons.Default.Share, "링크 공유") {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.url)
                    runCatching { ctx.startActivity(Intent.createChooser(send, null)) }
                    onDismiss()
                }
                if (canRemove) {
                    MenuRow(Icons.Default.RemoveCircleOutline, "이 목록에서 빼기") {
                        if (pid == FAV_ID) vm.toggleFavorite(t) else vm.removeFromPlaylist(pid, index)
                        onDismiss()
                    }
                }
            } else {
                Text(
                    "어느 플레이리스트에 넣을까요?",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                MenuRow(Icons.Default.Add, "새 플레이리스트 만들기") { onNewPlaylist(t); onDismiss() }
                targets.forEach { p ->
                    MenuRow(Icons.Default.LibraryMusic, "${p.name} (${p.tracks.size}곡)") { vm.copyTo(t, p.id); onDismiss() }
                }
                if (targets.isEmpty()) {
                    Text(
                        "직접 만든 플레이리스트가 아직 없어요. 유튜브에서 가져온 목록은 새로고침하면 바뀌어서, 곡을 담을 수 없어요",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(8.dp)
                    )
                }
                TextButton(onClick = { pickTarget = false }) { Text("뒤로") }
            }
        }
    }
}

// ======================= 이퀄라이저 =======================

@Composable
fun EqualizerSheet(onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("이퀄라이저", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Switch(checked = AudioFx.fxOn, onCheckedChange = { AudioFx.updateOn(it) })
            }
            if (!AudioFx.available) {
                Text(
                    "곡을 재생하면 사용할 수 있어요. 일부 기기는 지원하지 않아요",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                if (AudioFx.presets.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { AudioFx.resetLevels() }, label = { Text("초기화") }, enabled = AudioFx.fxOn)
                        AudioFx.presets.forEachIndexed { i, n ->
                            AssistChip(onClick = { AudioFx.usePreset(i) }, label = { Text(n) }, enabled = AudioFx.fxOn)
                        }
                    }
                }
                AudioFx.levels.forEachIndexed { b, lv ->
                    val hz = AudioFx.freqs.getOrElse(b) { 0 }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (hz >= 1000) "${hz / 1000}kHz" else "${hz}Hz",
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.width(56.dp)
                        )
                        Slider(
                            value = lv.toFloat(),
                            onValueChange = { AudioFx.updateLevel(b, it.roundToInt()) },
                            valueRange = AudioFx.minLevel.toFloat()..AudioFx.maxLevel.toFloat(),
                            enabled = AudioFx.fxOn,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            "%+d dB".format(lv / 100),
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.width(52.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("저음 강화", style = MaterialTheme.typography.titleSmall)
            Slider(
                value = AudioFx.bass.toFloat(),
                onValueChange = { AudioFx.updateBass(it.roundToInt()) },
                valueRange = 0f..1000f,
                enabled = AudioFx.fxOn
            )
            Text("음량 키우기", style = MaterialTheme.typography.titleSmall)
            Slider(
                value = AudioFx.boost.toFloat(),
                onValueChange = { AudioFx.updateBoost(it.roundToInt()) },
                valueRange = 0f..1500f,
                enabled = AudioFx.fxOn
            )
            Text(
                "작게 녹음된 곡을 크게 들을 때 써요. 너무 높이면 소리가 깨질 수 있어요",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ======================= 설정 =======================

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
    )
}

@Composable
fun SettingsSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val dynamicAvailable = Build.VERSION.SDK_INT >= 31
    val dynamicOn = vm.dynamicColor && dynamicAvailable
    val glass = LocalGlass.current
    val tick = rememberTick()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) vm.exportTo(u)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.importFrom(u)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = if (glass) 0.9f else 1f)
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("설정", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            // ---------- 화면 ----------
            SectionTitle("화면")
            Text("테마", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("시스템", "라이트", "다크", "시간 예약").forEachIndexed { i, label ->
                    FilterChip(selected = vm.themeMode == i, onClick = { tick(); vm.updateThemeMode(i) }, label = { Text(label) })
                }
            }
            if (vm.themeMode == 3) {
                HourStepper("다크 모드 시작", vm.nightStart) { vm.updateNight(it, vm.nightEnd) }
                HourStepper("다크 모드 끝", vm.nightEnd) { vm.updateNight(vm.nightStart, it) }
            }

            Text("강조 색상", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ACCENTS.forEachIndexed { i, (name, color) ->
                    val selected = vm.accent == i
                    val bg: Modifier = if (color == MONO) {
                        Modifier.background(
                            Brush.horizontalGradient(
                                0f to Color.Black, 0.5f to Color.Black, 0.5f to Color.White, 1f to Color.White
                            )
                        )
                    } else Modifier.background(color)
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .alpha(if (dynamicOn) 0.35f else 1f)
                            .then(bg)
                            .border(
                                if (selected) 3.dp else 1.dp,
                                if (selected) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                CircleShape
                            )
                            .clickable { tick(); vm.updateAccent(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) Icon(Icons.Default.Check, name, tint = if (color == MONO) Color.Gray else Color.White)
                    }
                }
            }
            SwitchRow(
                "앨범 아트 색 따라가기",
                "재생 중인 곡의 앨범 아트에서 색을 뽑아 화면 색이 바뀌어요 (흑백 테마에서는 꺼져요)",
                vm.useArtColor, vm::updateArtColor
            )
            if (dynamicAvailable) {
                SwitchRow("배경화면 색상 사용", "폰 배경화면에서 색을 가져와요 (다른 색 설정보다 우선)", vm.dynamicColor, vm::updateDynamic)
            }
            SwitchRow("리퀴드 글래스", "반투명 유리 질감과 앨범 아트 배경", vm.glass, vm::updateGlass)

            Text("글자 크기", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.9f to "작게", 1f to "보통", 1.15f to "크게", 1.3f to "아주 크게").forEach { (v, label) ->
                    FilterChip(selected = vm.fontScale == v, onClick = { tick(); vm.updateFontScale(v) }, label = { Text(label) })
                }
            }
            SwitchRow("한 손 모드", "플레이리스트 선택과 재생 버튼을 화면 아래쪽으로 내려요", vm.oneHand, vm::updateOneHand)
            SwitchRow("진동 반응", "버튼을 누르거나 밀 때 가볍게 진동해요", vm.haptics, vm::updateHaptics)

            // ---------- 재생 ----------
            SectionTitle("재생")
            SwitchRow("이어듣기", "앱을 다시 열면 마지막으로 듣던 곡과 위치부터 이어져요", vm.resumeEnabled, vm::updateResume)
            SwitchRow("다음 곡 미리 받기", "곡 사이 끊김이 줄고, 인터넷이 끊겨도 다음 곡까지 들을 수 있어요", vm.prefetch, vm::updatePrefetch)
            if (vm.prefetch) {
                SwitchRow("와이파이에서만 미리 받기", "모바일 데이터를 아껴요", vm.prefetchWifi, vm::updatePrefetchWifi)
            }
            SwitchRow(
                "음악 아닌 구간 건너뛰기",
                "뮤직비디오의 인트로 대사, 아웃트로 같은 부분을 SponsorBlock 데이터로 찾아 넘겨요",
                vm.skipOfftopic, vm::updateSkipOfftopic
            )
            Text("곡 전환 페이드", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 4.dp))
            Text(
                "곡 끝에서 소리가 서서히 작아지고, 다음 곡은 서서히 커져요",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "끄기", 2000 to "2초", 4000 to "4초", 6000 to "6초").forEach { (v, label) ->
                    FilterChip(selected = vm.fadeMs == v, onClick = { tick(); vm.updateFadeMs(v) }, label = { Text(label) })
                }
            }
            SwitchRow(
                "이어폰 연결하면 자동 재생",
                "유선·블루투스 이어폰을 연결하면 이어서 재생해요 (앱이 켜져 있거나 최근에 재생했을 때)",
                vm.autoPlayConnect, vm::updateAutoPlayConnect
            )
            SwitchRow(
                "열 때 새 곡 확인",
                "앱을 열면 유튜브 플레이리스트에 새로 추가된 곡이 있는지 확인해서 알려줘요",
                vm.checkUpdates, vm::updateCheckUpdates
            )
            SwitchRow(
                "데이터 절약 음질",
                "낮은 음질로 받아서 데이터를 덜 써요 (새로 재생하는 곡부터 적용)",
                vm.lowQuality, vm::updateLowQuality
            )

            // ---------- 음악 알람 ----------
            SectionTitle("음악 알람")
            SwitchRow(
                "음악으로 깨우기",
                if (vm.alarmOn) "다음 알람: ${vm.alarmLabel()} · 소리가 40초에 걸쳐 서서히 커져요" else "매일 정한 시간에 플레이리스트를 틀어줘요",
                vm.alarmOn
            ) { vm.updateAlarm(on = it) }
            if (vm.alarmOn) {
                HourStepper("시", vm.alarmHour) { vm.updateAlarm(h = it) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("분", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.updateAlarm(m = vm.alarmMinute - 5) }) { Icon(Icons.Default.Remove, "5분 빼기") }
                    Text("%02d".format(vm.alarmMinute), style = MaterialTheme.typography.titleMedium, modifier = Modifier.width(64.dp))
                    IconButton(onClick = { vm.updateAlarm(m = vm.alarmMinute + 5) }) { Icon(Icons.Default.Add, "5분 더하기") }
                }
                Text("틀어줄 플레이리스트", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    vm.playlists.filter { it.tracks.isNotEmpty() }.forEach { p ->
                        FilterChip(
                            selected = vm.alarmPid == p.id,
                            onClick = { tick(); vm.updateAlarm(pid = p.id) },
                            label = { Text(if (p.id == FAV_ID) "좋아요" else p.name, maxLines = 1) }
                        )
                    }
                }
            }

            // ---------- 저장 공간 ----------
            SectionTitle("저장 공간")
            Text("자동 캐시 크기", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(512, 1024, 2048, 5120).forEach { m ->
                    FilterChip(
                        selected = vm.cacheMb == m,
                        onClick = { tick(); vm.updateCacheMb(m) },
                        label = { Text(if (m >= 1024) "${m / 1024}GB" else "${m}MB") }
                    )
                }
            }
            Text(
                "자동 캐시 ${mb(vm.cacheBytes)} 사용 중 · 한 번 끝까지 들은 곡은 인터넷 없이 재생돼요. 꽉 차면 오래된 곡부터 지워져요",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "오프라인 저장 ${mb(vm.pinnedBytes)} 사용 중 · 플레이리스트 메뉴(⋮)의 '오프라인에 저장'으로 받은 곡은 자동으로 지워지지 않아요",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = vm::clearCache) { Text("자동 캐시 비우기") }
                OutlinedButton(onClick = vm::clearPinned) { Text("저장 곡 모두 삭제") }
            }

            // ---------- 백업 ----------
            SectionTitle("백업")
            Text(
                "플레이리스트 목록과 좋아요를 파일로 저장해 두면, 폰을 바꿔도 그대로 가져올 수 있어요 (곡 파일은 포함되지 않아요)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exportLauncher.launch("ytplaylist_backup.json") }) {
                    Icon(Icons.Default.FileDownload, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("내보내기")
                }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) {
                    Icon(Icons.Default.FileUpload, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("가져오기")
                }
            }

            // ---------- 기타 ----------
            SectionTitle("기타")
            TextButton(onClick = { vm.clearRecent() }) { Text("최근 들은 곡 기록 지우기") }
            TextButton(onClick = { vm.showOnboardingAgain(); onDismiss() }) { Text("사용법 안내 다시 보기") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun HourStepper(label: String, hour: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        IconButton(onClick = { onChange((hour + 23) % 24) }) { Icon(Icons.Default.Remove, "1시간 빼기") }
        Text("%02d:00".format(hour), style = MaterialTheme.typography.titleMedium, modifier = Modifier.width(64.dp))
        IconButton(onClick = { onChange((hour + 1) % 24) }) { Icon(Icons.Default.Add, "1시간 더하기") }
    }
}

// ======================= 입력 대화상자 =======================

@Composable
fun AddPlaylistDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit, onCreateEmpty: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("플레이리스트 추가") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("유튜브 플레이리스트 링크") },
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = { clipboard.getText()?.text?.let { text = it } }) {
                            Icon(Icons.Default.ContentPaste, "붙여넣기")
                        }
                    }
                )
                Text(
                    "팁: 유튜브 앱에서 플레이리스트 → 공유 → Playlist를 고르면 바로 추가돼요",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
                TextButton(onClick = { onCreateEmpty(); onDismiss() }) { Text("링크 없이 빈 플레이리스트 만들기") }
            }
        },
        confirmButton = {
            TextButton(onClick = { onAdd(text); onDismiss() }, enabled = text.isNotBlank()) { Text("추가") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}

@Composable
fun NameDialog(title: String, initial: String, confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true, label = { Text("이름") }) },
        confirmButton = {
            TextButton(onClick = { onConfirm(text); onDismiss() }, enabled = text.isNotBlank()) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}
