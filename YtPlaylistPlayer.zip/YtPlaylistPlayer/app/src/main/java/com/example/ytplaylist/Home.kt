@file:OptIn(ExperimentalSharedTransitionApi::class, ExperimentalMaterial3Api::class)

package com.example.ytplaylist

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.BoundsTransform
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.VisibilityThreshold
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import java.util.Calendar
import kotlin.random.Random

// ======================= 화면 전환용 공유 요소 =======================

/** 홈의 카드 커버가 플레이리스트 화면의 큰 커버로 이어지며 커지는 스프링 */
val SharedSpring = BoundsTransform { _, _ ->
    spring(dampingRatio = 0.78f, stiffness = 260f, visibilityThreshold = Rect.VisibilityThreshold)
}

@Composable
fun Modifier.sharedEl(key: String, s: SharedTransitionScope?, a: AnimatedVisibilityScope?): Modifier {
    if (s == null || a == null) return this
    return with(s) { this@sharedEl.sharedElement(rememberSharedContentState(key), a, boundsTransform = SharedSpring) }
}

@Composable
fun Modifier.sharedBox(key: String, s: SharedTransitionScope?, a: AnimatedVisibilityScope?): Modifier {
    if (s == null || a == null) return this
    return with(s) { this@sharedBox.sharedBounds(rememberSharedContentState(key), a, boundsTransform = SharedSpring) }
}

/** 화면에 들어올 때 아래에서 스프링으로 떠오르기 */
fun Modifier.riseIn(a: AnimatedVisibilityScope?, delay: Int = 0, divisor: Int = 5): Modifier {
    if (a == null) return this
    return with(a) {
        this@riseIn.animateEnterExit(
            enter = slideInVertically(
                spring(dampingRatio = 0.72f, stiffness = 240f, visibilityThreshold = IntOffset.VisibilityThreshold)
            ) { it / divisor } + fadeIn(tween(320, delayMillis = delay)),
            exit = fadeOut(tween(140))
        )
    }
}

// ======================= 커버 =======================

/** 플레이리스트 커버: 곡이 4개 이상이면 2x2 콜라주, 아니면 첫 곡 썸네일 */
@Composable
fun PlaylistCover(p: Playlist, modifier: Modifier, corner: Dp = 18.dp) {
    val shape = RoundedCornerShape(corner)
    val cs = MaterialTheme.colorScheme
    Box(modifier.clip(shape).background(cs.surfaceVariant)) {
        when {
            p.id == FAV_ID -> FavCover(p)

            p.tracks.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.LibraryMusic, null, Modifier.fillMaxSize(0.35f), tint = cs.onSurfaceVariant)
            }

            p.tracks.size >= 4 -> Column(Modifier.fillMaxSize()) {
                for (r in 0 until 2) {
                    Row(Modifier.weight(1f)) {
                        for (c in 0 until 2) {
                            AsyncImage(
                                model = p.tracks[r * 2 + c].thumb, contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.weight(1f).fillMaxHeight()
                            )
                        }
                    }
                }
            }

            else -> AsyncImage(
                model = p.tracks.first().thumb, contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/**
 * 좋아요 커버: 가장 최근에 좋아요한 곡의 아트를 흐리게 깔고, 가운데에 빛나는 하트.
 * 곡이 없을 땐 은은한 장밋빛 그라데이션.
 */
@Composable
private fun FavCover(p: Playlist) {
    // 맑은 장밋빛 → 보랏빛 그라데이션 + 흰 하트 (아트를 섞지 않아 탁해지지 않게)
    BoxWithConstraints(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFFFF6B8B), Color(0xFFE0457B), Color(0xFF7A3CF0)))
        ),
        contentAlignment = Alignment.Center
    ) {
        val side = minOf(maxWidth, maxHeight)
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
                    radius = with(androidx.compose.ui.platform.LocalDensity.current) { (side * 0.6f).toPx() }
                )
            )
        )
        Icon(Icons.Default.Favorite, null, Modifier.size(side * 0.34f), tint = Color.White)
    }
}

// ======================= 홈 화면 =======================

private val MESSAGES = listOf(
    "오늘은 어떤 노래로\n하루를 채워볼까요?",
    "좋아하는 노래 한 곡이면\n충분한 날도 있어요",
    "이어폰 꽂고\n잠깐 쉬어가요",
    "기분이 노래를 고르고,\n노래가 기분을 바꿔요",
    "오래된 플레이리스트에서\n보물을 찾아보세요",
    "셔플이 오늘의\n운세예요",
    "지금 이 순간의\n배경음악은 뭘까요?",
    "한 곡만 더 듣고 잘게요…\n아마도",
    "가사가 마음을 대신\n말해줄 때가 있죠",
    "집중이 필요할 땐\n가사 없는 곡도 좋아요",
    "반복 재생은\n사랑이에요",
    "오늘 하루도\n수고했어요",
    "산책하기 좋은 노래,\n하나쯤 있죠?",
    "볼륨은 조금 낮게,\n마음은 조금 크게",
    "좋은 노래는 나눌수록\n더 좋아져요"
)

private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 5..10 -> "좋은 아침이에요"
    in 11..16 -> "좋은 오후예요"
    in 17..21 -> "좋은 저녁이에요"
    else -> "늦은 밤이네요"
}

/** 화면 가운데 랜덤 메시지: 12초마다, 또는 누르면 다음 문장이 아래에서 떠올라요 */
@Composable
private fun RandomMessage(modifier: Modifier = Modifier) {
    var idx by remember { mutableIntStateOf(Random.nextInt(MESSAGES.size)) }
    val next = { idx = (idx + 1 + Random.nextInt(MESSAGES.size - 1)) % MESSAGES.size }
    LaunchedEffect(Unit) {
        while (true) {
            delay(12_000)
            next()
        }
    }
    Column(
        modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { next() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            greeting(),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(10.dp))
        AnimatedContent(
            targetState = idx,
            transitionSpec = {
                (slideInVertically(
                    spring(dampingRatio = 0.7f, stiffness = 180f, visibilityThreshold = IntOffset.VisibilityThreshold)
                ) { it / 2 } + fadeIn(tween(450))) togetherWith
                    (slideOutVertically(tween(280)) { -it / 2 } + fadeOut(tween(220)))
            },
            label = "message"
        ) { i ->
            Text(
                MESSAGES[i],
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun HomeScreen(
    vm: MainViewModel,
    s: SharedTransitionScope?,
    a: AnimatedVisibilityScope?,
    bottomInset: Dp,
    onOpen: (String) -> Unit,
    onPlaylistMenu: (String) -> Unit,
    onAdd: () -> Unit,
    onSettings: () -> Unit,
    onSearch: () -> Unit,
    onStats: () -> Unit,
    onMix: () -> Unit
) {
    var tagFilter by rememberSaveable { mutableStateOf("") }
    val tags = vm.tags
    LaunchedEffect(tags) { if (tagFilter.isNotEmpty() && tagFilter !in tags) tagFilter = "" }
    val shownPlaylists = if (tagFilter.isEmpty()) vm.playlists else vm.playlists.filter { it.tag == tagFilter }
    val muted = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
    var menu by remember { mutableStateOf(false) }

    LazyVerticalGrid(
        // 태블릿처럼 넓으면 커버를 더 크게
        columns = GridCells.Adaptive(
            if (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 840) 210.dp else 150.dp
        ),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 8.dp,
            bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + bottomInset + 24.dp
        ),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        // ----- 머리글: 인사 + 큰 제목 + 한 줄 메시지 -----
        item(key = "__header__", span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.riseIn(a, 0)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (vm.online) greeting() else "오프라인 · 저장한 곡만 재생돼요",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (vm.online) muted else MaterialTheme.colorScheme.error,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "유튜브에서 찾기") }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreHoriz, "더보기") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("새 플레이리스트") },
                                leadingIcon = { Icon(Icons.Default.Add, null) },
                                onClick = { menu = false; onAdd() }
                            )
                            DropdownMenuItem(
                                text = { Text("모두 섞어 듣기") },
                                leadingIcon = { Icon(Icons.Default.Shuffle, null) },
                                onClick = { menu = false; onMix() }
                            )
                            DropdownMenuItem(
                                text = { Text("청취 통계") },
                                leadingIcon = { Icon(Icons.Default.BarChart, null) },
                                onClick = { menu = false; onStats() }
                            )
                            DropdownMenuItem(
                                text = { Text("설정") },
                                leadingIcon = { Icon(Icons.Default.Settings, null) },
                                onClick = { menu = false; onSettings() }
                            )
                        }
                    }
                }
                Text(
                    "Playlist",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(Modifier.height(4.dp))
                QuietMessage(muted)
                if (tags.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TagPill("전체", tagFilter.isEmpty()) { tagFilter = "" }
                        tags.forEach { t -> TagPill("#$t", tagFilter == t) { tagFilter = if (tagFilter == t) "" else t } }
                    }
                }
            }
        }

        // ----- 플레이리스트: 커버 + 이름만 -----
        items(shownPlaylists, key = { it.id }) { p ->
            PlaylistTile(
                p = p,
                modifier = Modifier.animateItem().riseIn(a, 60, 3),
                s = s, a = a,
                onClick = { onOpen(p.id) },
                onLongClick = { onPlaylistMenu(p.id) }
            )
        }

        // ----- 새 플레이리스트 (맨 끝 빈 칸) -----
        item(key = "__add__") {
            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val sc by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.5f, stiffness = 600f), label = "addPress")
            Column(
                Modifier.graphicsLayer { scaleX = sc; scaleY = sc }
                    .clickable(interactionSource = src, indication = null, onClick = onAdd)
            ) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(alpha = 0.06f))
                        .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Add, null, Modifier.size(34.dp), tint = muted)
                }
                Spacer(Modifier.height(8.dp))
                Text("새 플레이리스트", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = muted)
            }
        }
    }
}

/** 한 줄짜리 조용한 메시지 (12초마다, 누르면 바로 바뀜) */
@Composable
private fun QuietMessage(color: Color) {
    var idx by remember { mutableIntStateOf(Random.nextInt(MESSAGES.size)) }
    val next = { idx = (idx + 1 + Random.nextInt(MESSAGES.size - 1)) % MESSAGES.size }
    LaunchedEffect(Unit) {
        while (true) {
            delay(12_000)
            next()
        }
    }
    Crossfade(targetState = idx, animationSpec = tween(500), label = "quietMsg") { i ->
        Text(
            MESSAGES[i].replace("\n", " "),
            style = MaterialTheme.typography.bodyMedium,
            color = color,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { next() }
        )
    }
}

@Composable
private fun TagPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(
        label,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
        color = if (selected) Color.Black else cs.onSurface.copy(alpha = 0.75f),
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.08f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

/** 플레이리스트 칸: 판 없이 커버와 글자만 (Apple Music 보관함 느낌) */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PlaylistTile(
    p: Playlist,
    modifier: Modifier,
    s: SharedTransitionScope?,
    a: AnimatedVisibilityScope?,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val tick = rememberTick()
    val longTick = rememberLongTick()
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.5f, stiffness = 600f), label = "tilePress")
    val name = if (p.id == FAV_ID) "좋아요" else p.name
    val downloading = PinnedDownloader.progress[p.id]
    Column(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .combinedClickable(
                interactionSource = src, indication = null,
                onClick = { tick(); onClick() },
                onLongClick = { longTick(); onLongClick() }
            )
    ) {
        PlaylistCover(
            p,
            Modifier.sharedEl("cover-${p.id}", s, a).fillMaxWidth().aspectRatio(1f)
                .shadow(10.dp, RoundedCornerShape(14.dp), ambientColor = Color.Black, spotColor = Color.Black),
            corner = 14.dp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            name,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.sharedBox("title-${p.id}", s, a)
        )
        Text(
            when {
                downloading != null -> "저장 중 ${downloading.first}/${downloading.second}"
                p.tag.isNotBlank() -> "${p.tracks.size}곡 · #${p.tag}"
                else -> "${p.tracks.size}곡"
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )
    }
}

// ======================= 플레이리스트 길게 누르기 메뉴 =======================

@Composable
fun PlaylistMenuSheet(
    vm: MainViewModel,
    pid: String,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onTag: () -> Unit
) {
    val p = vm.playlists.firstOrNull { it.id == pid } ?: run { onDismiss(); return }
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val downloading = PinnedDownloader.progress.containsKey(pid)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                PlaylistCover(p, Modifier.size(56.dp), 12.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(if (p.id == FAV_ID) "좋아요" else p.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${p.tracks.size}곡", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            HorizontalDivider()
            SheetRow(Icons.Default.PlaylistPlay, "열기") { onOpen(); onDismiss() }
            if (p.tracks.isNotEmpty()) {
                SheetRow(Icons.Default.PlayArrow, "바로 재생") { vm.playAllIn(p.id); onDismiss() }
                SheetRow(Icons.Default.Shuffle, "셔플 재생") { vm.shuffleIn(p.id); onDismiss() }
            }
            if (p.id != FAV_ID) SheetRow(Icons.Default.VerticalAlignTop, "맨 앞으로 옮기기") { vm.movePlaylistToFront(p.id); onDismiss() }
            if (p.url.isNotBlank()) SheetRow(Icons.Default.Refresh, "새로고침") { vm.refreshPlaylist(p.id); onDismiss() }
            val dup = remember(p.tracks) { vm.duplicateCount(p.id) }
            if (dup > 0) SheetRow(Icons.Default.CleaningServices, "중복 곡 정리 (${dup}곡)") { vm.removeDuplicates(p.id); onDismiss() }
            if (p.tracks.isNotEmpty()) {
                if (downloading) SheetRow(Icons.Default.Close, "오프라인 저장 멈추기") { vm.cancelOffline(p.id); onDismiss() }
                else SheetRow(Icons.Default.Download, "오프라인에 저장") { vm.startOffline(p.id); onDismiss() }
            }
            if (p.id != FAV_ID) {
                SheetRow(Icons.Default.Label, if (p.tag.isBlank()) "태그 정하기" else "태그 바꾸기 (#${p.tag})") { onTag(); onDismiss() }
                SheetRow(Icons.Default.Edit, "이름 바꾸기") { onRename(); onDismiss() }
                SheetRow(Icons.Default.Delete, "삭제") { onDelete(); onDismiss() }
            }
        }
    }
}

@Composable
fun SheetRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    val tick = rememberTick()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { tick(); onClick() }
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null)
        Spacer(Modifier.width(16.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
