package com.example.ytplaylist

import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 오디오 비주얼라이저용 스펙트럼.
 * 재생기로 흘러가는 소리(PCM)를 옆에서 받아 FFT로 주파수별 세기를 구해요. 마이크 권한은 필요 없어요.
 * 소리가 스피커에 닿기까지 조금 늦으므로, 계산한 값은 약간 늦춰서 화면에 보여줘요.
 */
@UnstableApi
object Spectrum {
    const val BANDS = 48
    private const val N = 2048
    private const val LATENCY_MS = 160L

    private class Frame(val at: Long, val v: FloatArray)
    private val frames = ArrayDeque<Frame>()
    private val lock = Any()
    private val last = FloatArray(BANDS)

    private val ring = FloatArray(N)
    private var filled = 0
    private var sinceLast = 0
    private var sampleRate = 44100
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT

    private val window = FloatArray(N) { i -> (0.5 - 0.5 * cos(2 * PI * i / (N - 1))).toFloat() }
    private val re = FloatArray(N)
    private val im = FloatArray(N)

    /** 화면이 그릴 때 부르는 값: 지금 들리고 있을 소리의 세기 (0~1) */
    fun current(out: FloatArray) {
        val now = System.nanoTime() / 1_000_000L
        synchronized(lock) {
            while (frames.size > 1 && frames[1].at <= now) frames.removeFirst()
            val f = frames.firstOrNull()
            if (f != null && f.at <= now) System.arraycopy(f.v, 0, last, 0, BANDS)
            else if (frames.isEmpty()) java.util.Arrays.fill(last, 0f)
        }
        System.arraycopy(last, 0, out, 0, BANDS)
    }

    fun clear() = synchronized(lock) { frames.clear(); java.util.Arrays.fill(last, 0f) }

    val sink = object : TeeAudioProcessor.AudioBufferSink {
        override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
            sampleRate = sampleRateHz
            channels = channelCount.coerceAtLeast(1)
            this@Spectrum.encoding = encoding
            filled = 0
            sinceLast = 0
            clear()
        }

        override fun handleBuffer(buffer: ByteBuffer) {
            val b = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            val ch = channels
            when (encoding) {
                C.ENCODING_PCM_16BIT -> {
                    val frameBytes = 2 * ch
                    while (b.remaining() >= frameBytes) {
                        var sum = 0f
                        for (c in 0 until ch) sum += b.short / 32768f
                        push(sum / ch)
                    }
                }
                C.ENCODING_PCM_FLOAT -> {
                    val frameBytes = 4 * ch
                    while (b.remaining() >= frameBytes) {
                        var sum = 0f
                        for (c in 0 until ch) sum += b.float
                        push(sum / ch)
                    }
                }
                else -> Unit
            }
        }
    }

    private fun push(s: Float) {
        System.arraycopy(ring, 1, ring, 0, N - 1) // 간단한 밀어넣기 (N이 작아서 충분히 빨라요)
        ring[N - 1] = s
        if (filled < N) filled++
        sinceLast++
        // 약 1/40초마다 한 번 계산
        if (filled == N && sinceLast >= sampleRate / 40) {
            sinceLast = 0
            analyze()
        }
    }

    private fun analyze() {
        for (i in 0 until N) { re[i] = ring[i] * window[i]; im[i] = 0f }
        fft(re, im)
        val out = FloatArray(BANDS)
        val nyq = sampleRate / 2f
        val fMin = 40f
        val fMax = minOf(16000f, nyq)
        for (k in 0 until BANDS) {
            // 낮은음~높은음을 귀에 맞게 로그 간격으로 나눠요
            val f0 = fMin * (fMax / fMin).pow(k / BANDS.toFloat())
            val f1 = fMin * (fMax / fMin).pow((k + 1) / BANDS.toFloat())
            val i0 = (f0 / nyq * (N / 2)).toInt().coerceIn(1, N / 2 - 1)
            val i1 = (f1 / nyq * (N / 2)).toInt().coerceIn(i0 + 1, N / 2)
            var peak = 0f
            for (i in i0 until i1) {
                val m = sqrt(re[i] * re[i] + im[i] * im[i])
                if (m > peak) peak = m
            }
            val db = 20f * log10((peak / (N / 4f)).coerceAtLeast(1e-6f))
            // 높은음은 원래 약하니 조금 올려줘요
            val tilt = 6f * k / BANDS
            out[k] = ((db + tilt + 62f) / 56f).coerceIn(0f, 1f)
        }
        val at = System.nanoTime() / 1_000_000L + LATENCY_MS
        synchronized(lock) {
            frames.addLast(Frame(at, out))
            while (frames.size > 40) frames.removeFirst()
        }
    }

    /** 제자리 radix-2 FFT */
    private fun fft(x: FloatArray, y: FloatArray) {
        val n = x.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                var t = x[i]; x[i] = x[j]; x[j] = t
                t = y[i]; y[i] = y[j]; y[j] = t
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k
                    val b = a + len / 2
                    val tr = x[b] * cr - y[b] * ci
                    val ti = x[b] * ci + y[b] * cr
                    x[b] = x[a] - tr; y[b] = y[a] - ti
                    x[a] += tr; y[a] += ti
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
