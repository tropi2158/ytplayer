package com.example.ytplaylist

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

private data class OnboardPage(val icon: ImageVector, val title: String, val body: String)

/** 처음 실행할 때 보여주는 짧은 안내 (마지막에 알림 권한 요청) */
@Composable
fun Onboarding(onFinish: () -> Unit) {
    val pages = remember {
        listOf(
            OnboardPage(
                Icons.Default.MusicNote,
                "YT Playlist에 오신 걸 환영해요",
                "유튜브 플레이리스트를 음악 앱처럼 들을 수 있어요. 화면을 꺼도, 다른 앱을 써도 계속 재생돼요."
            ),
            OnboardPage(
                Icons.Default.PlaylistAdd,
                "플레이리스트 추가하기",
                "유튜브 앱에서 플레이리스트를 열고 공유 → YT Playlist를 누르면 바로 추가돼요.\n링크를 복사해서 '+ 추가'에 붙여넣어도 돼요."
            ),
            OnboardPage(
                Icons.Default.TouchApp,
                "이렇게 조작해요",
                "곡을 길게 누르면 메뉴가 나와요.\n오른쪽으로 밀면 다음에 재생, 왼쪽으로 밀면 대기열에 추가.\n아래 플레이어를 좌우로 밀면 곡이 넘어가고, 위로 밀면 크게 열려요."
            ),
            OnboardPage(
                Icons.Default.Notifications,
                "알림 권한",
                "알림바와 잠금화면에서 재생을 조절하려면 알림 권한이 필요해요.\n다음 창에서 '허용'을 눌러주세요."
            )
        )
    }
    var page by remember { mutableIntStateOf(0) }
    val tick = rememberTick()

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.96f))
            .pointerInput(Unit) { detectTapGestures { } }
            .systemBarsPadding()
            .padding(24.dp)
    ) {
        TextButton(onClick = onFinish, modifier = Modifier.align(Alignment.TopEnd)) { Text("건너뛰기") }

        AnimatedContent(targetState = page, label = "onboard", modifier = Modifier.align(Alignment.Center)) { i ->
            val p = pages[i]
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                GlassSurface(
                    modifier = Modifier.size(112.dp),
                    shape = RoundedCornerShape(32.dp),
                    tint = MaterialTheme.colorScheme.primary
                ) {
                    Icon(p.icon, null, Modifier.size(52.dp))
                }
                Spacer(Modifier.height(28.dp))
                Text(
                    p.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    p.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pages.indices.forEach { i ->
                    Box(
                        Modifier
                            .size(width = if (i == page) 22.dp else 8.dp, height = 8.dp)
                            .clip(CircleShape)
                            .background(
                                if (i == page) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                            )
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            GlassSurface(
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(27.dp),
                tint = MaterialTheme.colorScheme.primary,
                onClick = {
                    tick()
                    if (page < pages.lastIndex) page++ else onFinish()
                }
            ) {
                Text(
                    if (page < pages.lastIndex) "다음" else "시작하기",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
