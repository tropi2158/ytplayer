package com.example.ytplaylist

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.PresetReverb
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * 소리 효과 모음.
 * - 키(음정): 속도는 그대로, 반음 단위로
 * - 노래방: 가운데 모인 목소리를 줄임 (재생기 안의 처리기)
 * - 8D: 소리가 머리 주위를 천천히 도는 느낌 (재생기 안의 처리기)
 * - 리버브: 방/홀 울림 (안드로이드 효과)
 * - 음량 고르게: 압축기 + 리미터로 곡마다 다른 크기를 비슷하게 (안드로이드 9 이상)
 */
@UnstableApi
object SoundFx {
    var pitchSemis by mutableIntStateOf(0)
        private set
    var karaoke by mutableStateOf(false)
        private set
    var spin8d by mutableStateOf(false)
        private set
    var reverb by mutableIntStateOf(0)
        private set
    var evenLoudness by mutableStateOf(false)
        private set

    val reverbNames = listOf("끄기", "작은 방", "보통 방", "큰 방", "홀", "큰 홀", "플레이트")
    private val reverbPresets = shortArrayOf(
        PresetReverb.PRESET_NONE, PresetReverb.PRESET_SMALLROOM, PresetReverb.PRESET_MEDIUMROOM,
        PresetReverb.PRESET_LARGEROOM, PresetReverb.PRESET_MEDIUMHALL, PresetReverb.PRESET_LARGEHALL, PresetReverb.PRESET_PLATE
    )

    private var prefs: SharedPreferences? = null
    private var session = 0
    private var rv: PresetReverb? = null
    private var dp: DynamicsProcessing? = null

    /** 재생 속도와 함께 쓰는 음정 배율 */
    val pitchFactor: Float get() = 2f.pow(pitchSemis / 12f)

    fun load(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("yt", Context.MODE_PRIVATE)
        prefs = p
        pitchSemis = p.getInt("fx_pitch", 0)
        karaoke = p.getBoolean("fx_karaoke", false)
        spin8d = p.getBoolean("fx_8d", false)
        reverb = p.getInt("fx_reverb", 0)
        evenLoudness = p.getBoolean("fx_even", false)
    }

    fun updatePitch(semis: Int) { pitchSemis = semis.coerceIn(-6, 6); prefs?.edit()?.putInt("fx_pitch", pitchSemis)?.apply() }
    fun updateKaraoke(v: Boolean) { karaoke = v; prefs?.edit()?.putBoolean("fx_karaoke", v)?.apply() }
    fun update8d(v: Boolean) { spin8d = v; prefs?.edit()?.putBoolean("fx_8d", v)?.apply() }
    fun updateReverb(i: Int) { reverb = i.coerceIn(0, reverbPresets.size - 1); prefs?.edit()?.putInt("fx_reverb", reverb)?.apply(); applyEffects() }
    fun updateEven(v: Boolean) { evenLoudness = v; prefs?.edit()?.putBoolean("fx_even", v)?.apply(); applyEffects() }

    /** 재생 서비스의 오디오 세션에 붙이기 */
    fun attach(sessionId: Int) {
        if (sessionId == session && (rv != null || dp != null)) { applyEffects(); return }
        release()
        session = sessionId
        applyEffects()
    }

    fun release() {
        runCatching { rv?.release() }
        runCatching { dp?.release() }
        rv = null
        dp = null
    }

    private fun applyEffects() {
        if (session == 0) return
        // 리버브
        runCatching {
            if (reverb > 0) {
                val r = rv ?: PresetReverb(0, session).also { rv = it }
                r.preset = reverbPresets[reverb]
                r.enabled = true
            } else rv?.enabled = false
        }
        // 음량 고르게
        if (Build.VERSION.SDK_INT >= 28) runCatching {
            if (evenLoudness) {
                val d = dp ?: buildDynamics(session).also { dp = it }
                d.enabled = true
            } else dp?.enabled = false
        }
    }

    @androidx.annotation.RequiresApi(28)
    private fun buildDynamics(session: Int): DynamicsProcessing {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
            false, 0, true, 1, false, 0, true
        ).build()
        // 큰 소리는 눌러주고, 전체를 조금 올려서 작은 곡도 들리게
        cfg.setMbcBandAllChannelsTo(0, DynamicsProcessing.MbcBand(true, 20000f, 8f, 250f, 3.5f, -26f, 6f, -90f, 1f, 0f, 7f))
        cfg.setLimiterAllChannelsTo(DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -1.5f, 0f))
        return DynamicsProcessing(0, session, cfg)
    }

    // ================= 재생기 안의 처리기 (노래방, 8D) =================

    /** 16비트 스테레오에서만 동작, 효과가 꺼져 있으면 그대로 통과 */
    class Processor : BaseAudioProcessor() {
        private var rate = 44100
        private var frames = 0L

        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
                return AudioProcessor.AudioFormat.NOT_SET
            }
            rate = inputAudioFormat.sampleRate
            return inputAudioFormat
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val size = inputBuffer.remaining()
            if (size == 0) return
            val out = replaceOutputBuffer(size)
            val inb = inputBuffer.order(ByteOrder.LITTLE_ENDIAN)
            val k = karaoke
            val spin = spin8d
            if (!k && !spin) {
                out.put(inb)
            } else {
                while (inb.remaining() >= 4) {
                    var l = inb.short.toFloat()
                    var r = inb.short.toFloat()
                    if (k) {
                        // 가운데(목소리)를 빼고 양옆 소리만 남겨요
                        val side = (l - r) * 0.9f
                        l = side
                        r = -side
                    }
                    if (spin) {
                        // 8초에 한 바퀴, 왼쪽 ↔ 오른쪽으로 부드럽게 옮겨가요
                        val t = frames.toDouble() / rate
                        val pan = sin(2.0 * PI * t / 8.0)
                        val a = (pan + 1.0) * PI / 4.0
                        val mid = (l + r) * 0.5f
                        val gl = cos(a).toFloat() * 1.3f
                        val gr = sin(a).toFloat() * 1.3f
                        l = mid * gl * 0.75f + l * 0.25f
                        r = mid * gr * 0.75f + r * 0.25f
                    }
                    frames++
                    out.putShort(l.coerceIn(-32768f, 32767f).toInt().toShort())
                    out.putShort(r.coerceIn(-32768f, 32767f).toInt().toShort())
                }
            }
            inputBuffer.position(inputBuffer.limit())
            out.flip()
        }

        override fun onReset() { frames = 0L }
    }
}
