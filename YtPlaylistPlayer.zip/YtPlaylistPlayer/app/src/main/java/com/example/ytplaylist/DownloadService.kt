package com.example.ytplaylist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * 오프라인 저장을 앱을 닫아도 계속 받게 해 주는 서비스.
 * 받는 동안 알림에 진행률이 보이고, 알림의 '멈추기'로 그만둘 수 있어요.
 * 받을 게 없으면 스스로 꺼져요.
 */
class DownloadService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var started = false

    private val tick = object : Runnable {
        override fun run() {
            val prog = PinnedDownloader.progress.toMap()
            if (prog.isEmpty()) {
                ServiceCompat.stopForeground(this@DownloadService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }
            getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, build(prog))
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            PinnedDownloader.progress.keys.toList().forEach { PinnedDownloader.cancel(it) }
        }
        ensureChannel(this)
        val n = build(PinnedDownloader.progress.toMap())
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        runCatching { ServiceCompat.startForeground(this, NOTIF_ID, n, type) }
        if (!started) {
            started = true
            handler.post(tick)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun build(prog: Map<String, Pair<Int, Int>>): Notification {
        val done = prog.values.sumOf { it.first }
        val all = prog.values.sumOf { it.second }.coerceAtLeast(1)
        val names = prog.keys.joinToString(", ") { PinnedDownloader.names[it] ?: "플레이리스트" }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, DownloadService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(if (prog.isEmpty()) "오프라인 저장 준비 중" else "오프라인 저장 중 · $done/$all")
            .setContentText(names)
            .setProgress(all, done, prog.isEmpty())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(open)
            .addAction(0, "멈추기", stop)
            .build()
    }

    companion object {
        private const val CHANNEL = "offline"
        private const val NOTIF_ID = 4021
        private const val ACTION_STOP = "stop"

        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "오프라인 저장", NotificationManager.IMPORTANCE_LOW).apply {
                        description = "오프라인 저장 진행 상황"
                        setShowBadge(false)
                    }
                )
            }
        }

        /** 받기 시작할 때 부르면, 앱을 닫아도 계속 받아요 */
        fun kick(ctx: Context) {
            runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java)) }
        }
    }
}
