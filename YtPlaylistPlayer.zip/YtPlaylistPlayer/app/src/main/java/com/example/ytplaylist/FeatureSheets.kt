@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.ytplaylist

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.layer.drawLayer
import kotlinx.coroutines.launch

/** 소리 효과: 키, 노래방, 8D, 리버브, 음량 고르게, 베이스 진동, 이퀄라이저 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun SoundFxSheet(vm: MainViewModel, onDismiss: () -> Unit, onOpenEq: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("소리 효과", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            // 키(음정)
            Text("키 (음정)", style = MaterialTheme.typography.titleSmall)
            Text("속도는 그대로, 음 높이만 반음씩 바꿔요. 노래 연습할 때 좋아요", style = MaterialTheme.typography.bodySmall, color = muted)
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledTonalIconButton(onClick = { vm.updatePitch(SoundFx.pitchSemis - 1) }, enabled = SoundFx.pitchSemis > -6) {
                    Icon(Icons.Default.Remove, "내리기")
                }
                Text(
                    when {
                        SoundFx.pitchSemis == 0 -> "원래 키"
                        SoundFx.pitchSemis > 0 -> "+${SoundFx.pitchSemis} 반음"
                        else -> "${SoundFx.pitchSemis} 반음"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                FilledTonalIconButton(onClick = { vm.updatePitch(SoundFx.pitchSemis + 1) }, enabled = SoundFx.pitchSemis < 6) {
                    Icon(Icons.Default.Add, "올리기")
                }
            }

            SwitchRow("노래방 모드", "가운데에 모인 목소리를 줄여서 반주만 남겨요 (곡마다 효과가 달라요)", SoundFx.karaoke, SoundFx::updateKaraoke)
            SwitchRow("8D 오디오", "소리가 머리 주위를 천천히 도는 느낌 (이어폰 추천)", SoundFx.spin8d, SoundFx::update8d)

            Text("울림 (리버브)", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SoundFx.reverbNames.forEachIndexed { i, n ->
                    FilterChip(selected = SoundFx.reverb == i, onClick = { SoundFx.updateReverb(i) }, label = { Text(n) })
                }
            }

            SwitchRow("음량 고르게", "영상마다 다른 소리 크기를 비슷하게 맞춰요 (안드로이드 9 이상)", SoundFx.evenLoudness, SoundFx::updateEven)
            SwitchRow("베이스 진동", "베이스가 칠 때 폰이 살짝 진동해요", vm.bassHaptic, vm::updateBassHaptic)

            OutlinedButton(onClick = { onDismiss(); onOpenEq() }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Equalizer, null)
                Spacer(Modifier.width(8.dp))
                Text("이퀄라이저 열기")
            }
        }
    }
}


/**
 * 가사 공유 카드: 흐린 앨범 아트 위에 가사 한 줄과 곡 이름.
 * '공유'는 바로 보내기, '저장'은 사진 앱(Pictures/Playlist)에 저장.
 */
@Composable
fun LyricShareDialog(vm: MainViewModel, line: String, onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val layer = androidx.compose.ui.graphics.rememberGraphicsLayer()
    val title = TitleClean.title(vm.nowTitle, vm.nowArtist)
    val artist = TitleClean.artist(vm.nowArtist)
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ShareCardFrame(layer) {
                coil.compose.AsyncImage(
                    model = vm.nowArt, contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.matchParentSize().blur(36.dp)
                )
                Box(Modifier.matchParentSize().background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.45f)))
                Column(Modifier.fillMaxSize().padding(26.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Icon(Icons.Default.FormatQuote, null, Modifier.size(34.dp), tint = AlbumAccent.color)
                    Text(
                        line,
                        style = MaterialTheme.typography.headlineSmall.copy(lineHeight = 34.sp),
                        fontWeight = FontWeight.ExtraBold,
                        color = androidx.compose.ui.graphics.Color.White
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        coil.compose.AsyncImage(
                            model = vm.nowArt, contentDescription = null,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            Text(artist, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        }
                        Text("Playlist", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.6f))
                    }
                }
            }
            CardActions(scope, layer, ctx, "lyric_${System.currentTimeMillis()}", onDismiss)
        }
    }
}

/** 카드 모양 틀 (그린 내용을 이미지로 저장할 수 있게 기록해 둬요) */
@Composable
fun ShareCardFrame(layer: androidx.compose.ui.graphics.layer.GraphicsLayer, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .width(320.dp)
            .aspectRatio(0.8f)
            .clip(RoundedCornerShape(24.dp))
            .drawWithContent {
                layer.record { this@drawWithContent.drawContent() }
                drawLayer(layer)
            }
            .background(androidx.compose.ui.graphics.Color(0xFF111114)),
        content = content
    )
}

@Composable
fun CardActions(
    scope: kotlinx.coroutines.CoroutineScope,
    layer: androidx.compose.ui.graphics.layer.GraphicsLayer,
    ctx: android.content.Context,
    name: String,
    onDone: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        FilledTonalButton(onClick = {
            scope.launch {
                val bmp = layer.toImageBitmap().asAndroidBitmap()
                val ok = ImageShare.saveToGallery(ctx, bmp, name)
                android.widget.Toast.makeText(ctx, if (ok) "사진 앱에 저장했어요" else "저장하지 못했어요", android.widget.Toast.LENGTH_SHORT).show()
            }
        }) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("저장") }
        Button(onClick = {
            scope.launch {
                val bmp = layer.toImageBitmap().asAndroidBitmap()
                ImageShare.share(ctx, bmp, name)
                onDone()
            }
        }) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("공유") }
    }
}
