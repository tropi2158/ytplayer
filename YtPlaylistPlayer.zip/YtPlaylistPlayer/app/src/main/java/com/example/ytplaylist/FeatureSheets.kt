@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.ytplaylist

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** 소리 효과: 키, 노래방, 8D, 리버브, 음량 고르게, 베이스 진동, 이퀄라이저 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun SoundFxSheet(vm: MainViewModel, onDismiss: () -> Unit, onOpenEq: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("소리 효과", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            // 키(음정)
            Text("키 (음정)", style = MaterialTheme.typography.titleSmall)
            Text("속도는 그대로, 음 높이만 반음씩 바꿔요. 노래 연습할 때 좋아요", style = MaterialTheme.typography.bodySmall, color = muted)
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledTonalIconButton(onClick = { vm.updatePitch(SoundFx.pitchSemis - 1) }, enabled = SoundFx.pitchSemis > -6) {
                    Icon(Icons.Default.Remove, "내리기")
                }
                Text(
                    when {
                        SoundFx.pitchSemis == 0 -> "원래 키"
                        SoundFx.pitchSemis > 0 -> "+${SoundFx.pitchSemis} 반음"
                        else -> "${SoundFx.pitchSemis} 반음"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                FilledTonalIconButton(onClick = { vm.updatePitch(SoundFx.pitchSemis + 1) }, enabled = SoundFx.pitchSemis < 6) {
                    Icon(Icons.Default.Add, "올리기")
                }
            }

            SwitchRow("노래방 모드", "가운데에 모인 목소리를 줄여서 반주만 남겨요 (곡마다 효과가 달라요)", SoundFx.karaoke, SoundFx::updateKaraoke)
            SwitchRow("8D 오디오", "소리가 머리 주위를 천천히 도는 느낌 (이어폰 추천)", SoundFx.spin8d, SoundFx::update8d)

            Text("울림 (리버브)", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SoundFx.reverbNames.forEachIndexed { i, n ->
                    FilterChip(selected = SoundFx.reverb == i, onClick = { SoundFx.updateReverb(i) }, label = { Text(n) })
                }
            }

            SwitchRow("음량 고르게", "영상마다 다른 소리 크기를 비슷하게 맞춰요 (안드로이드 9 이상)", SoundFx.evenLoudness, SoundFx::updateEven)
            SwitchRow("베이스 진동", "베이스가 칠 때 폰이 살짝 진동해요", vm.bassHaptic, vm::updateBassHaptic)

            OutlinedButton(onClick = { onDismiss(); onOpenEq() }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Equalizer, null)
                Spacer(Modifier.width(8.dp))
                Text("이퀄라이저 열기")
            }
        }
    }
}

