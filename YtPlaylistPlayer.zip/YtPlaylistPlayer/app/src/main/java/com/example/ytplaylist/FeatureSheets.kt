@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.ytplaylist

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.layer.drawLayer
import kotlinx.coroutines.launch

/** 소리 효과: 키, 노래방, 8D, 리버브, 음량 고르게, 베이스 진동, 이퀄라이저 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun SoundFxSheet(vm: MainViewModel, onDismiss: () -> Unit, onOpenEq: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("소리 효과", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            // 키(음정)
            Text("키 (음정)", style = MaterialTheme.typography.titleSmall)
            Text("속도는 그대로, 음 높이만 반음씩 바꿔요. 노래 연습할 때 좋아요", style = MaterialTheme.typography.bodySmall, color = muted)
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledTonalIconButton(onClick = { vm.updatePitch(SoundFx.pitchSemis - 1) }, enabled = SoundFx.pitchSemis > -6) {
                    Icon(Icons.Default.Remove, "내리기")
                }
                Text(
                    when {
                        SoundFx.pitchSemis == 0 -> "원래 키"
                        SoundFx.pitchSemis > 0 -> "+${SoundFx.pitchSemis} 반음"
                        else -> "${SoundFx.pitchSemis} 반음"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                FilledTonalIconButton(onClick = { vm.updatePitch(SoundFx.pitchSemis + 1) }, enabled = SoundFx.pitchSemis < 6) {
                    Icon(Icons.Default.Add, "올리기")
                }
            }

            SwitchRow("노래방 모드", "가운데에 모인 목소리를 줄여서 반주만 남겨요 (곡마다 효과가 달라요)", SoundFx.karaoke, SoundFx::updateKaraoke)
            SwitchRow("8D 오디오", "소리가 머리 주위를 천천히 도는 느낌 (이어폰 추천)", SoundFx.spin8d, SoundFx::update8d)

            Text("울림 (리버브)", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SoundFx.reverbNames.forEachIndexed { i, n ->
                    FilterChip(selected = SoundFx.reverb == i, onClick = { SoundFx.updateReverb(i) }, label = { Text(n) })
                }
            }

            SwitchRow("음량 고르게", "영상마다 다른 소리 크기를 비슷하게 맞춰요 (안드로이드 9 이상)", SoundFx.evenLoudness, SoundFx::updateEven)
            SwitchRow("베이스 진동", "베이스가 칠 때 폰이 살짝 진동해요", vm.bassHaptic, vm::updateBassHaptic)

            OutlinedButton(onClick = { onDismiss(); onOpenEq() }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Equalizer, null)
                Spacer(Modifier.width(8.dp))
                Text("이퀄라이저 열기")
            }
        }
    }
}


/**
 * 가사 공유 카드: 흐린 앨범 아트 위에 가사 한 줄과 곡 이름.
 * '공유'는 바로 보내기, '저장'은 사진 앱(Pictures/Playlist)에 저장.
 */
@Composable
fun LyricShareDialog(vm: MainViewModel, line: String, onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val layer = androidx.compose.ui.graphics.rememberGraphicsLayer()
    val title = TitleClean.title(vm.nowTitle, vm.nowArtist)
    val artist = TitleClean.artist(vm.nowArtist)
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ShareCardFrame(layer) {
                coil.compose.AsyncImage(
                    model = vm.nowArt, contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.matchParentSize().blur(36.dp)
                )
                Box(Modifier.matchParentSize().background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.45f)))
                Column(Modifier.fillMaxSize().padding(26.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Icon(Icons.Default.FormatQuote, null, Modifier.size(34.dp), tint = AlbumAccent.color)
                    Text(
                        line,
                        style = MaterialTheme.typography.headlineSmall.copy(lineHeight = 34.sp),
                        fontWeight = FontWeight.ExtraBold,
                        color = androidx.compose.ui.graphics.Color.White
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        coil.compose.AsyncImage(
                            model = vm.nowArt, contentDescription = null,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            Text(artist, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        }
                        Text("Playlist", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.6f))
                    }
                }
            }
            CardActions(scope, layer, ctx, "lyric_${System.currentTimeMillis()}", onDismiss)
        }
    }
}

/** 카드 모양 틀 (그린 내용을 이미지로 저장할 수 있게 기록해 둬요) */
@Composable
fun ShareCardFrame(layer: androidx.compose.ui.graphics.layer.GraphicsLayer, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .width(320.dp)
            .aspectRatio(0.8f)
            .clip(RoundedCornerShape(24.dp))
            .drawWithContent {
                layer.record { this@drawWithContent.drawContent() }
                drawLayer(layer)
            }
            .background(androidx.compose.ui.graphics.Color(0xFF111114)),
        content = content
    )
}

@Composable
fun CardActions(
    scope: kotlinx.coroutines.CoroutineScope,
    layer: androidx.compose.ui.graphics.layer.GraphicsLayer,
    ctx: android.content.Context,
    name: String,
    onDone: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        FilledTonalButton(onClick = {
            scope.launch {
                val bmp = layer.toImageBitmap().asAndroidBitmap()
                val ok = ImageShare.saveToGallery(ctx, bmp, name)
                android.widget.Toast.makeText(ctx, if (ok) "사진 앱에 저장했어요" else "저장하지 못했어요", android.widget.Toast.LENGTH_SHORT).show()
            }
        }) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("저장") }
        Button(onClick = {
            scope.launch {
                val bmp = layer.toImageBitmap().asAndroidBitmap()
                ImageShare.share(ctx, bmp, name)
                onDone()
            }
        }) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("공유") }
    }
}

// ======================= 곡/목록 기능 (메모, 가수 페이지, 커버, 공유) =======================

/** 여러 메뉴에서 여는 창들의 상태 (메인 화면이 그려줘요) */
object ListUi {
    var noteFor by mutableStateOf<Track?>(null)
    var artist by mutableStateOf<String?>(null)
    var coverFor by mutableStateOf<String?>(null)
    var shareFor by mutableStateOf<String?>(null)
}

@Composable
fun NoteDialog(t: Track, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(SongPrefs.notes[t.url] ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("곡 메모") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t.shownTitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                OutlinedTextField(
                    value = text, onValueChange = { text = it.take(200) },
                    placeholder = { Text("예: 2절이 좋음, 시험 전날 듣기") },
                    shape = RoundedCornerShape(14.dp), minLines = 2
                )
            }
        },
        confirmButton = { TextButton(onClick = { SongPrefs.setNote(t.url, text); onDismiss() }) { Text("저장") } },
        dismissButton = {
            if (SongPrefs.notes.containsKey(t.url)) TextButton(onClick = { SongPrefs.setNote(t.url, ""); onDismiss() }) { Text("지우기") }
            else TextButton(onClick = onDismiss) { Text("취소") }
        }
    )
}

/** 가수 페이지: 내 목록에 있는 이 가수 곡 + 유튜브 인기곡 */
@Composable
fun ArtistSheet(vm: MainViewModel, artist: String, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val name = TitleClean.artist(artist)
    val mine = remember(artist) {
        vm.playlists.flatMap { pl -> pl.tracks.map { pl.id to it } }
            .filter { (_, t) -> TitleClean.artist(t.artist).equals(name, ignoreCase = true) || t.title.contains(name, ignoreCase = true) }
            .distinctBy { it.second.url }
    }
    LaunchedEffect(artist) { vm.findArtist(artist) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        androidx.compose.foundation.lazy.LazyColumn(
            Modifier.fillMaxWidth().heightIn(max = 640.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 28.dp)
        ) {
            item {
                Column(Modifier.padding(horizontal = 4.dp, vertical = 6.dp)) {
                    Text(name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("내 목록 ${mine.size}곡", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (mine.isNotEmpty()) Button(onClick = { vm.playList(mine.map { it.second }.shuffled(), "__artist__", 0); onDismiss() }) {
                            Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("내 곡 섞어 듣기")
                        }
                        val first = mine.firstOrNull()?.second ?: vm.searchResults.firstOrNull()
                        if (first != null) OutlinedButton(onClick = { vm.startRadio(first); onDismiss() }) { Text("이 가수 라디오") }
                    }
                }
            }
            if (mine.isNotEmpty()) {
                item { Text("내 목록에 있는 곡", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) }
                items(mine.size) { i ->
                    val (pid, t) = mine[i]
                    ArtistRow(t) { vm.playTrackIn(pid, t.url); onDismiss() }
                }
            }
            item { Text("유튜브 인기곡", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)) }
            if (vm.searching) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(8.dp)) }
            val res = vm.searchResults.take(15)
            items(res.size) { i -> ArtistRow(res[i]) { vm.playList(res, SEARCH_PID, i); onDismiss() } }
        }
    }
}

@Composable
private fun ArtistRow(t: Track, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        coil.compose.AsyncImage(
            model = t.thumb, contentDescription = null, contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.shownTitle, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(t.shownArtist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

/** 커버 꾸미기: 자동(콜라주) / 사진 / 이모지+색 */
@Composable
fun CoverDialog(vm: MainViewModel, id: String, onDismiss: () -> Unit) {
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()
    ) { u -> if (u != null) vm.setCoverImage(id, u); onDismiss() }
    val emojis = listOf("🎧", "🎵", "🔥", "🌙", "☀️", "💜", "📚", "🏃", "☕", "🌧️", "🎮", "✨")
    val colors = listOf("#FF6B8B", "#7A3CF0", "#38A1F3", "#43E97B", "#FFB347", "#FF5E62", "#2D2D34", "#E0E0E0")
    var emoji by remember { mutableStateOf(emojis[0]) }
    var color by remember { mutableStateOf(colors[0]) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("커버 바꾸기") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.size(96.dp).clip(RoundedCornerShape(16.dp)).background(androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(color)))
                        .align(Alignment.CenterHorizontally),
                    contentAlignment = Alignment.Center
                ) { Text(emoji, fontSize = 44.sp) }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    emojis.forEach { e ->
                        Text(e, fontSize = 24.sp, modifier = Modifier.clip(CircleShape)
                            .background(if (e == emoji) androidx.compose.ui.graphics.Color.White.copy(alpha = 0.18f) else androidx.compose.ui.graphics.Color.Transparent)
                            .clickable { emoji = e }.padding(4.dp))
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    colors.forEach { c ->
                        Box(Modifier.size(30.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(c)))
                            .then(if (c == color) Modifier.border(2.dp, androidx.compose.ui.graphics.Color.White, CircleShape) else Modifier)
                            .clickable { color = c })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        pick.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(4.dp)); Text("사진") }
                    OutlinedButton(onClick = { vm.setCover(id, ""); onDismiss() }) { Text("자동으로") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.setCover(id, "emoji:$emoji:$color"); onDismiss() }) { Text("이모지로") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}

/** 목록 공유: 링크 + QR코드 (친구가 Playlist 앱으로 찍거나 링크를 열면 그대로 들어와요) */
@Composable
fun ShareListSheet(vm: MainViewModel, id: String, onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val p = vm.playlists.firstOrNull { it.id == id } ?: return
    val link = remember(p) { vm.shareLinkOf(p) }
    val qr = remember(link) { runCatching { qrBitmap(link, 720) }.getOrNull() }
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("'${if (p.id == FAV_ID) "좋아요" else p.name}' 공유", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (qr != null) {
                androidx.compose.foundation.Image(
                    bitmap = qr.asImageBitmap(), contentDescription = "QR코드",
                    modifier = Modifier.size(240.dp).clip(RoundedCornerShape(16.dp)).background(androidx.compose.ui.graphics.Color.White).padding(10.dp)
                )
            } else {
                Text("곡이 많아서 QR코드를 만들 수 없어요. 링크로 보내 주세요", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                if (p.url.isNotBlank()) "유튜브 플레이리스트 주소예요. 친구가 Playlist 앱에서 추가하면 돼요"
                else "친구 폰에 Playlist 앱이 있으면 링크를 누르거나 QR을 찍어서 바로 가져올 수 있어요",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    ctx.getSystemService(android.content.ClipboardManager::class.java)?.setPrimaryClip(android.content.ClipData.newPlainText("플레이리스트", link))
                    android.widget.Toast.makeText(ctx, "링크를 복사했어요", android.widget.Toast.LENGTH_SHORT).show()
                }) { Text("링크 복사") }
                Button(onClick = {
                    val i = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(android.content.Intent.EXTRA_TEXT, "🎧 ${p.name}\n$link")
                    ctx.startActivity(android.content.Intent.createChooser(i, "플레이리스트 공유"))
                }) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("보내기") }
            }
        }
    }
}

fun qrBitmap(text: String, size: Int): android.graphics.Bitmap {
    val m = com.google.zxing.qrcode.QRCodeWriter().encode(text, com.google.zxing.BarcodeFormat.QR_CODE, size, size, mapOf(com.google.zxing.EncodeHintType.MARGIN to 1))
    val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.RGB_565)
    for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (m[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    return bmp
}
