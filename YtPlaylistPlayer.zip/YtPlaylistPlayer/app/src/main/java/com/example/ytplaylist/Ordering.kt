package com.example.ytplaylist

import kotlin.math.abs
import kotlin.math.ln
import kotlin.random.Random

/** 화면에서 불러온 가사를 재생 서비스(잠금화면 가사)와 나눠 쓰기 */
object LyricsBridge {
    @Volatile var url: String = ""
    @Volatile var lines: List<LyricLine> = emptyList()
}

/** 셔플 순서 만들기 */
object ShuffleSmart {
    /**
     * 가중치 무작위 순서: 끝까지 자주 듣는 곡은 앞쪽에, 자주 넘기는 곡은 뒤쪽에 나올 확률이 높아요.
     * (Efraimidis–Spirakis 방식: key = ln(u) / w 가 큰 순서)
     */
    fun weightedOrder(idx: List<Int>, urlAt: (Int) -> String, rnd: Random): List<Int> =
        idx.map { i ->
            val w = SongPrefs.weight(urlAt(i))
            val u = rnd.nextDouble().coerceAtLeast(1e-12)
            i to ln(u) / w
        }.sortedByDescending { it.second }.map { it.first }

    /**
     * 분위기 이어 섞기: 지금 곡의 소리 세기에서 출발해, 비슷한 세기의 곡 중에서 무작위로 골라 이어가요.
     * 아직 세기를 모르는 곡은 중간중간 섞어 넣어요.
     */
    fun moodOrder(startUrl: String, idx: List<Int>, urlAt: (Int) -> String, rnd: Random): List<Int> {
        val known = idx.mapNotNull { i -> SongPrefs.energyOf(urlAt(i))?.let { i to it } }.toMutableList()
        val unknown = idx.filter { i -> SongPrefs.energyOf(urlAt(i)) == null }.shuffled(rnd).toMutableList()
        var cur = SongPrefs.energyOf(startUrl) ?: known.map { it.second }.average().toFloat().takeIf { !it.isNaN() } ?: 0.4f
        val out = ArrayList<Int>(idx.size)
        while (known.isNotEmpty()) {
            // 가장 가까운 몇 곡 중 하나 (너무 똑같은 순서가 되지 않게)
            val near = known.sortedBy { abs(it.second - cur) }.take(4)
            val pick = near[rnd.nextInt(near.size)]
            known.remove(pick)
            out += pick.first
            cur = cur * 0.4f + pick.second * 0.6f
            if (unknown.isNotEmpty() && rnd.nextInt(4) == 0) out += unknown.removeAt(0)
        }
        out += unknown
        return out
    }
}
