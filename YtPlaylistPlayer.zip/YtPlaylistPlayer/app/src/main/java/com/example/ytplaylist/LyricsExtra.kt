package com.example.ytplaylist

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

/** 가사 화면의 상태 (번역/발음 보기, 전체 화면, 공유할 줄) */
object LyricsUi {
    /** 0 원문만, 1 번역, 2 발음 */
    var mode by mutableIntStateOf(0)
    var full by mutableStateOf(false)
    var shareLine by mutableStateOf<String?>(null)
}

/** 가사 번역 (기기 안에서, 처음 한 번 번역 모델을 받아요) */
object LyricsTranslate {
    /** url -> 줄별 번역 */
    val results = mutableStateMapOf<String, List<String>>()
    var busyUrl by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** 가사 언어 짐작: 일본어 / 영어 / (한국어면 null: 번역 필요 없음) */
    fun detect(text: String): String? {
        var kana = 0; var hangul = 0; var latin = 0; var han = 0
        for (ch in text) {
            when (ch) {
                in '぀'..'ヿ' -> kana++
                in '가'..'힣' -> hangul++
                in 'a'..'z', in 'A'..'Z' -> latin++
                in '一'..'鿿' -> han++
            }
        }
        return when {
            kana > 0 -> TranslateLanguage.JAPANESE
            hangul > latin && hangul > han -> null
            han > latin -> TranslateLanguage.CHINESE
            latin > 0 -> TranslateLanguage.ENGLISH
            else -> null
        }
    }

    fun isJapanese(lines: List<String>) = detect(lines.joinToString(" ")) == TranslateLanguage.JAPANESE

    suspend fun translate(url: String, lines: List<String>) {
        if (results.containsKey(url) || busyUrl == url) return
        val src = detect(lines.joinToString(" ")) ?: run { results[url] = lines.map { "" }; return }
        busyUrl = url
        error = null
        val tr = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(TranslateLanguage.KOREAN).build()
        )
        try {
            val ok = suspendCancellableCoroutine { c ->
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener { c.resume(true) }
                    .addOnFailureListener { c.resume(false) }
            }
            if (!ok) {
                error = "번역 모델을 받지 못했어요 (인터넷 연결을 확인해 주세요)"
                return
            }
            val out = ArrayList<String>(lines.size)
            for (l in lines) {
                if (l.isBlank()) { out += ""; continue }
                val t = suspendCancellableCoroutine { c ->
                    tr.translate(l).addOnSuccessListener { c.resume(it) }.addOnFailureListener { c.resume("") }
                }
                out += t
            }
            results[url] = out
        } catch (e: Exception) {
            error = "번역하지 못했어요"
        } finally {
            tr.close()
            if (busyUrl == url) busyUrl = ""
        }
    }
}

/** 일본어 가나 → 한글 발음 (한자는 그대로 남아요) */
object Kana {
    private val base: Map<Char, String> = run {
        val m = HashMap<Char, String>()
        fun row(kana: String, hangul: String) { for (i in kana.indices) m[kana[i]] = hangul.split(",")[i] }
        row("あいうえお", "아,이,우,에,오")
        row("かきくけこ", "카,키,쿠,케,코"); row("がぎぐげご", "가,기,구,게,고")
        row("さしすせそ", "사,시,스,세,소"); row("ざじずぜぞ", "자,지,즈,제,조")
        row("たちつてと", "타,치,츠,테,토"); row("だぢづでど", "다,지,즈,데,도")
        row("なにぬねの", "나,니,누,네,노")
        row("はひふへほ", "하,히,후,헤,호"); row("ばびぶべぼ", "바,비,부,베,보"); row("ぱぴぷぺぽ", "파,피,푸,페,포")
        row("まみむめも", "마,미,무,메,모")
        row("やゆよ", "야,유,요")
        row("らりるれろ", "라,리,루,레,로")
        row("わゐゑを", "와,이,에,오")
        row("ゔ", "부")
        m
    }

    private fun hira(c: Char): Char = if (c in 'ァ'..'ヶ') (c.code - 0x60).toChar() else c
    private fun isHangul(c: Char) = c in '가'..'힣'
    private fun cho(c: Char) = (c.code - 0xAC00) / 588
    private fun jung(c: Char) = ((c.code - 0xAC00) % 588) / 28
    private fun jong(c: Char) = (c.code - 0xAC00) % 28
    private fun make(cho: Int, jung: Int, jong: Int = 0) = (0xAC00 + (cho * 21 + jung) * 28 + jong).toChar()

    fun toHangul(text: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            val c = hira(text[i])
            val nxt = if (i + 1 < text.length) hira(text[i + 1]) else ' '
            when {
                c == 'ん' -> addJong(sb, 4)               // ㄴ 받침
                c == 'っ' -> addJong(sb, 19)              // ㅅ 받침
                c == 'ー' -> Unit                          // 길게: 생략
                base.containsKey(c) -> {
                    var h = base.getValue(c)[0]
                    // 작은 ゃゅょ: 캬/큐/쿄
                    val y = when (nxt) { 'ゃ' -> 2; 'ゅ' -> 17; 'ょ' -> 12; else -> -1 }
                    // 작은 ぁぃぅぇぉ: 파/티/위...
                    val v = when (nxt) { 'ぁ' -> 0; 'ぃ' -> 20; 'ぅ' -> 13; 'ぇ' -> 5; 'ぉ' -> 8; else -> -1 }
                    if (y >= 0 && isHangul(h)) { h = make(cho(h), y); i++ }
                    else if (v >= 0 && isHangul(h)) {
                        h = if (c == 'う') make(11, when (v) { 20 -> 16; 5 -> 15; 8 -> 14; else -> v }) else make(cho(h), v)
                        i++
                    }
                    sb.append(h)
                }
                c in "ゃゅょぁぃぅぇぉ" -> sb.append(base[(c.code + 1).toChar()] ?: "")
                else -> sb.append(text[i])
            }
            i++
        }
        return sb.toString()
    }

    private fun addJong(sb: StringBuilder, j: Int) {
        if (sb.isNotEmpty()) {
            val last = sb[sb.length - 1]
            if (isHangul(last) && jong(last) == 0) {
                sb.setCharAt(sb.length - 1, make(cho(last), jung(last), j))
                return
            }
        }
        sb.append(if (j == 4) "ㄴ" else "ㅅ")
    }
}

/** 만든 이미지 공유 / 갤러리에 저장 */
object ImageShare {
    fun share(ctx: Context, bmp: Bitmap, name: String) {
        runCatching {
            val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
            val f = File(dir, "$name.png")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            val i = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, "공유").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** 사진 앱의 Pictures/Playlist 폴더에 저장 */
    fun saveToGallery(ctx: Context, bmp: Bitmap, name: String): Boolean = runCatching {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Playlist")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        true
    }.getOrDefault(false)
}
