@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.mutableStateMapOf
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.datasource.cache.SimpleCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 플레이리스트 전체를 '오프라인 저장'(자동으로 지워지지 않는 저장소)에 받아두는 다운로더 */
object PinnedDownloader {
    /** 플레이리스트 id -> (처리한 곡 수, 전체 곡 수). 받는 중일 때만 들어 있음 */
    val progress = mutableStateMapOf<String, Pair<Int, Int>>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = HashMap<String, Job>()

    /** 완료 시 (실패한 곡 수)를 알려줘요 */
    fun start(ctx: Context, pl: Playlist, onDone: (failed: Int) -> Unit) {
        if (progress.containsKey(pl.id) || pl.tracks.isEmpty()) return
        val app = ctx.applicationContext
        val tracks = pl.tracks
        progress[pl.id] = 0 to tracks.size
        jobs[pl.id] = scope.launch {
            val cache = CacheProvider.getPinned(app)
            var done = 0
            var bad = 0
            var finished = false
            try {
                for (t in tracks) {
                    ensureActive()
                    if (!CacheProvider.isFullyCached(cache, t.url)) {
                        try {
                            downloadOne(cache, t.url)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            ensureActive()
                            bad++
                        }
                    }
                    done++
                    withContext(Dispatchers.Main) { progress[pl.id] = done to tracks.size }
                }
                finished = true
            } finally {
                withContext(NonCancellable + Dispatchers.Main) {
                    progress.remove(pl.id)
                    jobs.remove(pl.id)
                    if (finished) onDone(bad)
                }
            }
        }
    }

    fun cancel(id: String) {
        jobs[id]?.cancel()
        jobs.remove(id)
        progress.remove(id)
    }

    private suspend fun downloadOne(cache: SimpleCache, url: String) {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(NewPipeDownloader.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
        val factory = CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(ResolvingDataSource.Factory(http, YtResolver()))
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        val writer = CacheWriter(factory.createDataSource(), DataSpec(Uri.parse(url)), null, null)
        val handle = currentCoroutineContext()[Job]?.invokeOnCompletion { writer.cancel() }
        try {
            writer.cache()
        } finally {
            handle?.dispose()
        }
    }
}
