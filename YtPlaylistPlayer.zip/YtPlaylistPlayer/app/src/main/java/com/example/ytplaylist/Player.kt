@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ytplaylist

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * 전체 플레이어 패널.
 * expand(0=접힘, 1=펼침) 값을 손가락이 직접 움직이고, 놓으면 속도에 맞춰 스프링으로 이어서 움직여요.
 * 미니 플레이어에서 끌어올린 동작이 그대로 이 패널로 이어져요.
 */
@Composable
fun PlayerOverlay(
    vm: MainViewModel,
    expand: Animatable<Float, AnimationVector1D>,
    heightPx: Float,
    onSettle: (velocity: Float) -> Unit,
    onCollapse: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenEq: () -> Unit,
    onFindArtist: () -> Unit,
    onInfo: () -> Unit = {}
) {
    val visible by remember { derivedStateOf { expand.value > 0.001f } }
    if (!visible) return

    val scope = rememberCoroutineScope()
    val glass = LocalGlass.current
    val cs = MaterialTheme.colorScheme
    BackHandler { onCollapse() }

    // 바깥 상자: 제스처 + 뒤 화면 어둡게 (움직이지 않음)
    Box(
        Modifier
            .fillMaxSize()
            .drawBehind { drawRect(Color.Black.copy(alpha = 0.45f * expand.value)) }
            .draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { d ->
                    scope.launch { expand.snapTo((expand.value - d / heightPx).coerceIn(0f, 1f)) }
                },
                onDragStopped = { v -> onSettle(v) }
            )
    ) {
        // 안쪽 패널: expand에 따라 아래에서 올라옴
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = (1f - expand.value) * heightPx
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                    clip = true
                }
                .background(cs.surface)
        ) {
            val panelBackdrop = rememberBackdrop(detailed = true)
            Box(Modifier.fillMaxSize().backdropSource(panelBackdrop)) { GlassBackground(vm.bgColors, deep = true, art = vm.nowArt) }
            CompositionLocalProvider(LocalBackdrop provides panelBackdrop) {
                PlayerPanel(vm, expand, onCollapse, onOpenQueue, onOpenEq, onFindArtist, onInfo)
            }
        }
    }
}

@Composable
private fun PlayerPanel(
    vm: MainViewModel,
    expand: Animatable<Float, AnimationVector1D>,
    onCollapse: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenEq: () -> Unit,
    onFindArtist: () -> Unit,
    onInfo: () -> Unit = {}
) {
    var showSleep by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    val longTick = rememberLongTick()
    LaunchedEffect(showLyrics, vm.playingUrl) { if (showLyrics) vm.loadLyrics() }
    val fav = vm.isFavorite(vm.playingUrl)
    val plName = vm.playlists.firstOrNull { it.id == vm.playingPid }
        ?.let { if (it.id == FAV_ID) "좋아요" else it.name }
        ?: when (vm.playingPid) { RADIO_PID -> "비슷한 곡 라디오"; SEARCH_PID -> "검색 결과"; else -> "" }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            // 펼쳐질수록 내용이 살짝 커지며 또렷해져요
            .graphicsLayer {
                val e = expand.value
                alpha = ((e - 0.15f) / 0.85f).coerceIn(0f, 1f)
                val s = 0.94f + 0.06f * e
                scaleX = s
                scaleY = s
            },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ----- 상단 -----
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCollapse) { Icon(Icons.Default.KeyboardArrowDown, "접기", Modifier.size(32.dp)) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("지금 재생 중", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (plName.isNotEmpty()) {
                    Text(
                        plName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(onClick = onInfo) { Icon(Icons.Default.Info, "곡 정보") }
            IconButton(onClick = onOpenQueue) { Icon(Icons.Default.QueueMusic, "대기열") }
        }

        Spacer(Modifier.height(12.dp))

        // ----- 앨범 아트 캐러셀 (좌우로 넘겨 곡 바꾸기) <-> 가사 -----
        AnimatedContent(
            targetState = showLyrics,
            modifier = Modifier.fillMaxWidth().weight(1f),
            transitionSpec = {
                (fadeIn(tween(320)) + scaleIn(spring(dampingRatio = 0.8f, stiffness = 260f), initialScale = 0.92f)) togetherWith
                    (fadeOut(tween(180)) + scaleOut(tween(220), targetScale = 1.05f))
            },
            label = "artOrLyrics"
        ) { lyricsOn ->
            if (lyricsOn) LyricsView(vm, Modifier.fillMaxSize()) else ArtPager(vm, Modifier.fillMaxSize())
        }

        Text(
            if (showLyrics) "가사 줄을 누르면 그 부분으로 이동해요" else "← 앨범 아트를 밀어 곡 넘기기 →",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.padding(top = 6.dp)
        )
        Spacer(Modifier.height(14.dp))

        // ----- 제목 + 좋아요 -----
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            AnimatedContent(
                targetState = vm.nowTitle to vm.nowArtist,
                modifier = Modifier.weight(1f),
                transitionSpec = {
                    (fadeIn(tween(320)) + slideInVertically(tween(320)) { h -> h / 3 }) togetherWith
                        (fadeOut(tween(160)) + slideOutVertically(tween(160)) { h -> -h / 3 })
                },
                label = "title"
            ) { (t, a) ->
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        t, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).clickable { onFindArtist() },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            a, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Icon(
                            Icons.Default.ChevronRight, "이 가수 다른 곡 찾기",
                            Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            IconButton(onClick = { longTick(); vm.toggleFavoriteCurrent() }) {
                AnimatedContent(
                    targetState = fav,
                    transitionSpec = {
                        (scaleIn(initialScale = 0.3f, animationSpec = spring(0.4f, 500f)) + fadeIn()) togetherWith fadeOut(tween(100))
                    },
                    label = "fav"
                ) { f ->
                    Icon(
                        if (f) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        "좋아요",
                        tint = if (f) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        SeekBar(vm)

        // ----- 재생 버튼 -----
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = vm::toggleShuffle) {
                Icon(
                    Icons.Default.Shuffle, "셔플",
                    tint = if (vm.shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            GlassSurface(modifier = Modifier.size(56.dp), shape = CircleShape, onClick = vm::previous) {
                Icon(Icons.Default.SkipPrevious, "이전", Modifier.size(30.dp))
            }
            GlassSurface(
                modifier = Modifier.size(78.dp),
                shape = CircleShape,
                tint = MaterialTheme.colorScheme.primary,
                onClick = vm::togglePlay,
                pressScale = 0.9f
            ) {
                PlayPauseIcon(vm.isPlaying, 40.dp)
                if (vm.isBuffering) CircularProgressIndicator(Modifier.fillMaxSize(), strokeWidth = 2.dp)
            }
            GlassSurface(modifier = Modifier.size(56.dp), shape = CircleShape, onClick = vm::next) {
                Icon(Icons.Default.SkipNext, "다음", Modifier.size(30.dp))
            }
            IconButton(onClick = vm::cycleRepeat) {
                Icon(
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    "반복",
                    tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        UpNext(vm)
        Spacer(Modifier.height(8.dp))

        // ----- 도구 (배경과 구분되는 판 위에) -----
        GlassSurface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), strong = true) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                val sleepLabel = when {
                    SleepTimer.endOfTrack -> "곡 끝에서"
                    SleepTimer.remainingMs > 0L -> fmtTime(SleepTimer.remainingMs)
                    else -> "타이머"
                }
                ToolButton(Icons.Default.Bedtime, sleepLabel, SleepTimer.active) { showSleep = true }
                ToolButton(Icons.Default.Speed, speedLabel(vm.speed), vm.speed != 1f) { showSpeed = true }
                ToolButton(Icons.Default.FormatQuote, "가사", showLyrics) { showLyrics = !showLyrics }
                val abLabel = when {
                    AbLoop.url != vm.playingUrl || AbLoop.a < 0 -> "구간"
                    AbLoop.b < 0 -> "B 지정"
                    else -> "A-B"
                }
                ToolButton(Icons.Default.Loop, abLabel, AbLoop.url == vm.playingUrl && AbLoop.a >= 0) { vm.abStep() }
                ToolButton(Icons.Default.QueueMusic, "대기열", false, onOpenQueue)
                ToolButton(Icons.Default.Equalizer, "이퀄라이저", AudioFx.fxOn, onOpenEq)
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showSleep) SleepTimerDialog { showSleep = false }
    if (showSpeed) SpeedDialog(vm) { showSpeed = false }
}

/** 앨범 아트를 좌우로 넘겨 곡을 바꾸는 캐러셀. 옆 곡의 아트가 살짝 보여서 흐름이 이어져요 */
@Composable
private fun ArtPager(vm: MainViewModel, modifier: Modifier) {
    val queue = vm.queue
    if (queue.isEmpty()) {
        Box(modifier)
        return
    }
    val curPos = queue.indexOfFirst { it.index == vm.currentIndex }
    val pagerState = rememberPagerState(initialPage = curPos.coerceAtLeast(0)) { vm.queue.size }
    val longTick = rememberLongTick()
    val latestQueue by rememberUpdatedState(queue)
    val latestCur by rememberUpdatedState(curPos)
    var userSwiping by remember { mutableStateOf(false) }
    val dragged by pagerState.interactionSource.collectIsDraggedAsState()

    LaunchedEffect(dragged) { if (dragged) userSwiping = true }

    // 곡이 다른 곳(버튼, 알림, 자동 넘김)에서 바뀌면 캐러셀도 따라 이동
    LaunchedEffect(curPos) {
        if (curPos >= 0 && curPos != pagerState.currentPage && !pagerState.isScrollInProgress) {
            if (abs(curPos - pagerState.currentPage) > 3) pagerState.scrollToPage(curPos)
            else pagerState.animateScrollToPage(curPos, animationSpec = spring(dampingRatio = 0.72f, stiffness = 220f))
        }
    }

    // 사용자가 넘겨서 멈춘 곳의 곡을 재생
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.settledPage }.collect { p ->
            if (userSwiping) {
                userSwiping = false
                val q = latestQueue
                if (p != latestCur && p in q.indices) {
                    longTick()
                    vm.queuePlay(q[p].index)
                }
            }
        }
    }

    HorizontalPager(
        state = pagerState,
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 28.dp),
        pageSpacing = 4.dp,
        key = { i -> latestQueue.getOrNull(i)?.index ?: i }
    ) { page ->
        val e = queue.getOrNull(page)
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val off = abs((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).coerceIn(0f, 1f)
                    val s = 1f - 0.16f * off
                    scaleX = s
                    scaleY = s
                    alpha = 1f - 0.6f * off
                    rotationY = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).coerceIn(-1f, 1f) * -8f
                },
            contentAlignment = Alignment.Center
        ) {
            val side = if (maxWidth < maxHeight) maxWidth else maxHeight
            GlassSurface(
                modifier = Modifier.size(side).shadow(18.dp, RoundedCornerShape(30.dp)),
                shape = RoundedCornerShape(30.dp)
            ) {
                AsyncImage(
                    model = e?.art, contentDescription = e?.title, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().padding(5.dp).clip(RoundedCornerShape(25.dp))
                )
            }
        }
    }
}

/** 시크바: 진행 위치는 '그리기'에서만 계산해 매 프레임 흐르고, 끄는 동안 손잡이가 커지며 시간 풍선이 떠요 */
@Composable
private fun SeekBar(vm: MainViewModel) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val dragState = rememberUpdatedState(drag)
    var lastDrag by remember { mutableFloatStateOf(0f) }
    val clock = rememberFrameClock(vm.isPlaying && drag == null)
    val slow = rememberSlowClock(vm.isPlaying)
    val thumb = animateFloatAsState(
        if (drag != null) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 480f), label = "thumb"
    )
    val primary = MaterialTheme.colorScheme.primary
    val trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)

    Box(Modifier.fillMaxWidth().height(36.dp), contentAlignment = Alignment.BottomCenter) {
        if (thumb.value > 0.01f) {
            GlassSurface(
                modifier = Modifier.graphicsLayer {
                    alpha = thumb.value.coerceIn(0f, 1f)
                    scaleX = 0.8f + 0.2f * thumb.value
                    scaleY = 0.8f + 0.2f * thumb.value
                    translationY = (1f - thumb.value) * 12f
                },
                shape = CircleShape,
                tint = primary
            ) {
                Text(
                    "${fmtTime((lastDrag * vm.durationMs).toLong())} / ${fmtTime(vm.durationMs)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }
        }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(36.dp)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o ->
                    val f = (o.x / size.width).coerceIn(0f, 1f)
                    vm.seek((f * vm.durationMs).toLong())
                })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        val f = (o.x / size.width).coerceIn(0f, 1f)
                        drag = f
                        lastDrag = f
                    },
                    onDragEnd = {
                        drag?.let { vm.seek((it * vm.durationMs).toLong()) }
                        drag = null
                    },
                    onDragCancel = { drag = null }
                ) { change, _ ->
                    change.consume()
                    val f = (change.position.x / size.width).coerceIn(0f, 1f)
                    drag = f
                    lastDrag = f
                }
            }
            .drawBehind {
                clock.value
                val d = vm.durationMs
                val f = (dragState.value ?: if (d > 0) vm.livePosition().toFloat() / d else 0f).coerceIn(0f, 1f)
                val t = thumb.value
                val h = 4.dp.toPx() + 2.dp.toPx() * t
                val cy = size.height / 2f
                val r = CornerRadius(h / 2f)
                drawRoundRect(trackColor, topLeft = Offset(0f, cy - h / 2f), size = Size(size.width, h), cornerRadius = r)
                drawRoundRect(primary, topLeft = Offset(0f, cy - h / 2f), size = Size(size.width * f, h), cornerRadius = r)
                drawCircle(primary, radius = 6.dp.toPx() + 4.dp.toPx() * t, center = Offset(size.width * f, cy))
            }
    )
    val shownPos = drag?.let { (it * vm.durationMs).toLong() } ?: run {
        slow.value
        vm.livePosition()
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(fmtTime(shownPos), style = MaterialTheme.typography.bodySmall)
        Text("-" + fmtTime((vm.durationMs - shownPos).coerceAtLeast(0L)), style = MaterialTheme.typography.bodySmall)
    }
}

/** 가사: 싱크 가사면 지금 부르는 줄이 커지고 밝아지며 자동으로 따라 내려가요 */
@Composable
private fun LyricsView(vm: MainViewModel, modifier: Modifier) {
    val state = vm.lyrics
    Box(modifier, contentAlignment = Alignment.Center) {
        when (state) {
            LyricsState.Idle, LyricsState.Loading -> CircularProgressIndicator()
            LyricsState.NotFound -> Text(
                "이 곡의 가사를 찾지 못했어요",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            is LyricsState.Plain -> Text(
                state.text.ifBlank { "가사가 비어 있어요" },
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 24.dp)
            )
            is LyricsState.Synced -> SyncedLyrics(vm, state.lines)
        }
    }
}

@Composable
private fun SyncedLyrics(vm: MainViewModel, lines: List<LyricLine>) {
    val slow = rememberSlowClock(vm.isPlaying)
    val pos = run {
        slow.value
        vm.positionMs // 멈춰 있을 때도 위치 반영
        vm.livePosition()
    }
    val cur = lines.indexOfLast { it.ms <= pos + 250 }
    val listState = rememberLazyListState()
    LaunchedEffect(cur) {
        if (cur >= 0) listState.animateScrollToItem((cur - 2).coerceAtLeast(0))
    }
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        itemsIndexed(lines, key = { i, _ -> i }) { i, line ->
            val active = i == cur
            val weight by animateFloatAsState(if (active) 1f else 0f, spring(dampingRatio = 0.7f, stiffness = 300f), label = "lyric")
            Text(
                line.text.ifBlank { "♪" },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = if (active) FontWeight.ExtraBold else FontWeight.SemiBold,
                color = if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = 0.45f + 0.55f * weight
                        val sc = 0.94f + 0.06f * weight
                        scaleX = sc
                        scaleY = sc
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                    }
                    .clickable { vm.seek(line.ms) }
            )
        }
    }
}

/** 다음에 나올 곡 미리보기 (누르면 바로 넘어가요) */
@Composable
private fun UpNext(vm: MainViewModel) {
    val q = vm.queue
    val cp = q.indexOfFirst { it.index == vm.currentIndex }
    val next = when {
        vm.repeatMode == Player.REPEAT_MODE_ONE -> null
        cp >= 0 && cp + 1 < q.size -> q[cp + 1]
        vm.repeatMode == Player.REPEAT_MODE_ALL && q.isNotEmpty() -> q[0]
        else -> null
    }
    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        strong = true,
        onClick = if (next != null) vm::next else null,
        pressScale = 0.98f
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            AnimatedContent(
                targetState = next,
                transitionSpec = {
                    (fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 2 }) togetherWith
                        (fadeOut(tween(150)) + slideOutVertically(tween(150)) { -it / 2 })
                },
                label = "upNext",
                modifier = Modifier.weight(1f)
            ) { e ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (e != null) {
                        AsyncImage(
                            model = e.art, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(Modifier.width(10.dp))
                    }
                    Column {
                        Text(
                            if (vm.repeatMode == Player.REPEAT_MODE_ONE) "한 곡 반복 중" else "다음 곡",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            e?.title ?: if (vm.repeatMode == Player.REPEAT_MODE_ONE) vm.nowTitle else "대기열의 마지막 곡이에요",
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            if (next != null) Icon(Icons.Default.SkipNext, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
