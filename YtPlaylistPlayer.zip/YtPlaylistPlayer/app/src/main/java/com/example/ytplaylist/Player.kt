@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ytplaylist

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * 전체 플레이어 패널.
 * expand(0=접힘, 1=펼침) 값을 손가락이 직접 움직이고, 놓으면 속도에 맞춰 스프링으로 이어서 움직여요.
 * 미니 플레이어에서 끌어올린 동작이 그대로 이 패널로 이어져요.
 */
@Composable
fun PlayerOverlay(
    vm: MainViewModel,
    expand: Animatable<Float, AnimationVector1D>,
    heightPx: Float,
    onSettle: (velocity: Float) -> Unit,
    onCollapse: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenEq: () -> Unit,
    onFindArtist: () -> Unit,
    onInfo: () -> Unit = {}
) {
    val visible by remember { derivedStateOf { expand.value > 0.001f } }
    if (!visible) return

    val scope = rememberCoroutineScope()
    val glass = LocalGlass.current
    val cs = MaterialTheme.colorScheme
    BackHandler { onCollapse() }

    // 바깥 상자: 제스처 + 뒤 화면 어둡게 (움직이지 않음)
    Box(
        Modifier
            .fillMaxSize()
            .drawBehind { drawRect(Color.Black.copy(alpha = 0.45f * expand.value)) }
            .draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { d ->
                    scope.launch { expand.snapTo((expand.value - d / heightPx).coerceIn(0f, 1f)) }
                },
                onDragStopped = { v -> onSettle(v) }
            )
    ) {
        // 안쪽 패널: expand에 따라 아래에서 올라옴
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = (1f - expand.value) * heightPx
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                    clip = true
                }
                .onGloballyPositioned { ArtMorph.panel = it }
                .background(cs.surface)
        ) {
            val panelBackdrop = rememberBackdrop(detailed = true)
            Box(Modifier.fillMaxSize().backdropSource(panelBackdrop)) { GlassBackground(vm.bgColors, deep = true, art = vm.nowArt) }
            CompositionLocalProvider(LocalBackdrop provides panelBackdrop) {
                PlayerPanel(vm, expand, onCollapse, onOpenQueue, onOpenEq, onFindArtist, onInfo)
            }
        }
    }
}

@Composable
private fun PlayerPanel(
    vm: MainViewModel,
    expand: Animatable<Float, AnimationVector1D>,
    onCollapse: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenEq: () -> Unit,
    onFindArtist: () -> Unit,
    onInfo: () -> Unit = {}
) {
    var showSleep by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    val longTick = rememberLongTick()
    LaunchedEffect(showLyrics, vm.playingUrl) { if (showLyrics) vm.loadLyrics() }
    val fav = vm.isFavorite(vm.playingUrl)
    val plName = vm.playlists.firstOrNull { it.id == vm.playingPid }
        ?.let { if (it.id == FAV_ID) "좋아요" else it.name }
        ?: when (vm.playingPid) { RADIO_PID -> "비슷한 곡 라디오"; SEARCH_PID -> "검색 결과"; else -> "" }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            // 펼쳐질수록 내용이 살짝 커지며 또렷해져요
            .graphicsLayer {
                val e = expand.value
                alpha = (e / 0.2f).coerceIn(0f, 1f)
                val s = 0.94f + 0.06f * e
                scaleX = s
                scaleY = s
            }
    ) {
    // 태블릿 가로처럼 넓은 화면이면 왼쪽 아트 / 오른쪽 정보 두 칸
    val wide = maxWidth > maxHeight && maxWidth >= 700.dp
    val artBlock: @Composable (Modifier) -> Unit = { m ->
        // ----- 앨범 아트 캐러셀 (좌우로 넘겨 곡 바꾸기) <-> 가사 -----
        AnimatedContent(
            targetState = showLyrics,
            modifier = m,
            transitionSpec = {
                (fadeIn(tween(320)) + scaleIn(spring(dampingRatio = 0.8f, stiffness = 260f), initialScale = 0.92f)) togetherWith
                    (fadeOut(tween(180)) + scaleOut(tween(220), targetScale = 1.05f))
            },
            label = "artOrLyrics"
        ) { lyricsOn ->
            if (lyricsOn) LyricsView(vm, Modifier.fillMaxSize()) else ArtPager(vm, Modifier.fillMaxSize(), wide)
        }

    }
    val infoBlock: @Composable () -> Unit = {
        // ----- 제목 + 좋아요 -----
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            AnimatedContent(
                targetState = TitleClean.title(vm.nowTitle, vm.nowArtist) to TitleClean.artist(vm.nowArtist),
                modifier = Modifier.weight(1f),
                transitionSpec = {
                    // 아트와 같은 방향으로 옆에서 밀려 들어와요
                    val d = vm.navDir
                    (fadeIn(tween(260)) + androidx.compose.animation.slideInHorizontally(spring(dampingRatio = 0.8f, stiffness = 320f)) { w -> d * w / 3 }) togetherWith
                        (fadeOut(tween(160)) + androidx.compose.animation.slideOutHorizontally(spring(dampingRatio = 0.9f, stiffness = 380f)) { w -> -d * w / 4 })
                },
                label = "title"
            ) { (t, a) ->
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        t, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).clickable { onFindArtist() },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            a, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Icon(
                            Icons.Default.ChevronRight, "이 가수 다른 곡 찾기",
                            Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            IconButton(onClick = { longTick(); vm.toggleFavoriteCurrent() }) {
                AnimatedContent(
                    targetState = fav,
                    transitionSpec = {
                        (scaleIn(initialScale = 0.3f, animationSpec = spring(0.4f, 500f)) + fadeIn()) togetherWith fadeOut(tween(100))
                    },
                    label = "fav"
                ) { f ->
                    Icon(
                        if (f) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        "좋아요",
                        tint = if (f) AlbumAccent.color else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        SeekBar(vm)

    }
    val controlBlock: @Composable () -> Unit = {
        // ----- 재생 버튼: 판 없이 큼직한 아이콘만 -----
        val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        val on = MaterialTheme.colorScheme.onSurface
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PlainControl(48.dp, vm::toggleShuffle) {
                Icon(Icons.Default.Shuffle, "셔플", Modifier.size(22.dp), tint = if (vm.shuffle) AlbumAccent.color else dim)
            }
            PlainControl(64.dp, vm::previous) {
                Icon(Icons.Default.SkipPrevious, "이전", Modifier.size(42.dp), tint = on)
            }
            PlainControl(84.dp, vm::togglePlay) {
                PlayPauseIcon(vm.isPlaying, 58.dp)
                if (vm.isBuffering) CircularProgressIndicator(Modifier.size(76.dp), strokeWidth = 1.5.dp, color = dim)
            }
            PlainControl(64.dp, vm::next) {
                Icon(Icons.Default.SkipNext, "다음", Modifier.size(42.dp), tint = on)
            }
            PlainControl(48.dp, vm::cycleRepeat) {
                Icon(
                    if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    "반복", Modifier.size(22.dp),
                    tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) dim else AlbumAccent.color
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        AudioVisualizer(vm, expand)
        Spacer(Modifier.height(6.dp))

        // ----- 아래 도구: 가사 / 타이머 / 대기열 (아이콘만) -----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PlainControl(48.dp, { showLyrics = !showLyrics }) {
                Icon(Icons.Default.FormatQuote, "가사", Modifier.size(24.dp), tint = if (showLyrics) on else dim)
            }
            PlainControl(48.dp, { showSleep = true }) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Bedtime, "수면 타이머", Modifier.size(22.dp), tint = if (SleepTimer.active) on else dim)
                    if (SleepTimer.active) {
                        Text(
                            if (SleepTimer.endOfTrack) "곡 끝" else fmtTime(SleepTimer.remainingMs),
                            style = MaterialTheme.typography.labelSmall, color = on
                        )
                    }
                }
            }
            PlainControl(48.dp, onOpenQueue) {
                Icon(Icons.Default.QueueMusic, "대기열", Modifier.size(24.dp), tint = dim)
            }
        }
        Spacer(Modifier.height(6.dp))
    }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        // ----- 상단: 접기 / 어디서 재생 중인지 / 더보기 -----
        var more by remember { mutableStateOf(false) }
        Row(Modifier.fillMaxWidth().expandStagger(expand, 0), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCollapse) { Icon(Icons.Default.KeyboardArrowDown, "접기", Modifier.size(30.dp)) }
            Text(
                plName,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Box {
                IconButton(onClick = { more = true }) { Icon(Icons.Default.MoreHoriz, "더보기") }
                DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                    DropdownMenuItem(
                        text = { Text("곡 정보") },
                        leadingIcon = { Icon(Icons.Default.Info, null) },
                        onClick = { more = false; onInfo() }
                    )
                    DropdownMenuItem(
                        text = { Text("재생 속도 · ${speedLabel(vm.speed)}") },
                        leadingIcon = { Icon(Icons.Default.Speed, null) },
                        onClick = { more = false; showSpeed = true }
                    )
                    val abLabel = when {
                        AbLoop.url != vm.playingUrl || AbLoop.a < 0 -> "구간 반복 (A 지정)"
                        AbLoop.b < 0 -> "구간 반복 (B 지정)"
                        else -> "구간 반복 끄기"
                    }
                    DropdownMenuItem(
                        text = { Text(abLabel) },
                        leadingIcon = { Icon(Icons.Default.Loop, null) },
                        onClick = { more = false; vm.abStep() }
                    )
                    DropdownMenuItem(
                        text = { Text("이퀄라이저") },
                        leadingIcon = { Icon(Icons.Default.Equalizer, null) },
                        onClick = { more = false; onOpenEq() }
                    )
                    DropdownMenuItem(
                        text = { Text("이 가수 다른 곡") },
                        leadingIcon = { Icon(Icons.Default.PersonSearch, null) },
                        onClick = { more = false; onFindArtist() }
                    )
                }
            }
        }

        // 펼치는 동안 아트 → 제목 → 버튼 순으로 차례차례 떠올라요 (손가락을 그대로 따라감)
        if (wide) {
            Row(Modifier.fillMaxWidth().weight(1f), verticalAlignment = Alignment.CenterVertically) {
                artBlock(Modifier.weight(1f).fillMaxHeight().padding(vertical = 16.dp).expandStagger(expand, 1))
                Spacer(Modifier.width(48.dp))
                Column(
                    Modifier.weight(1f).widthIn(max = 520.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Column(Modifier.expandStagger(expand, 2)) { infoBlock() }
                    Spacer(Modifier.height(8.dp))
                    Column(Modifier.expandStagger(expand, 3)) { controlBlock() }
                }
            }
        } else {
            Column(
                Modifier.weight(1f).widthIn(max = 560.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(12.dp))
                artBlock(Modifier.fillMaxWidth().weight(1f).expandStagger(expand, 1))
                Spacer(Modifier.height(22.dp))
                Column(Modifier.expandStagger(expand, 2)) { infoBlock() }
                Column(Modifier.expandStagger(expand, 3)) { controlBlock() }
            }
        }
    }
    }

    if (showSleep) SleepTimerDialog { showSleep = false }
    if (showSpeed) SpeedDialog(vm) { showSpeed = false }
}

/** 앨범 아트를 좌우로 넘겨 곡을 바꾸는 캐러셀. 옆 곡의 아트가 살짝 보여서 흐름이 이어져요 */
@Composable
private fun ArtPager(vm: MainViewModel, modifier: Modifier, wide: Boolean = false) {
    val queue = vm.queue
    if (queue.isEmpty()) {
        Box(modifier)
        return
    }
    val curPos = queue.indexOfFirst { it.index == vm.currentIndex }
    val pagerState = rememberPagerState(initialPage = curPos.coerceAtLeast(0)) { vm.queue.size }
    val longTick = rememberLongTick()
    val latestQueue by rememberUpdatedState(queue)
    val latestCur by rememberUpdatedState(curPos)
    var userSwiping by remember { mutableStateOf(false) }
    val dragged by pagerState.interactionSource.collectIsDraggedAsState()

    LaunchedEffect(dragged) { if (dragged) userSwiping = true }

    // 곡이 다른 곳(버튼, 알림, 자동 넘김)에서 바뀌면 캐러셀도 따라 이동
    LaunchedEffect(curPos) {
        if (curPos >= 0 && curPos != pagerState.currentPage && !pagerState.isScrollInProgress) {
            if (abs(curPos - pagerState.currentPage) > 3) pagerState.scrollToPage(curPos)
            else pagerState.animateScrollToPage(curPos, animationSpec = spring(dampingRatio = 0.72f, stiffness = 220f))
        }
    }

    // 사용자가 넘겨서 멈춘 곳의 곡을 재생
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.settledPage }.collect { p ->
            if (userSwiping) {
                userSwiping = false
                val q = latestQueue
                if (p != latestCur && p in q.indices) {
                    longTick()
                    vm.navDir = if (p > latestCur) 1 else -1
                    vm.queuePlay(q[p].index)
                }
            }
        }
    }

    HorizontalPager(
        state = pagerState,
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = if (wide) 0.dp else 28.dp),
        pageSpacing = if (wide) 32.dp else 4.dp,
        key = { i -> latestQueue.getOrNull(i)?.index ?: i }
    ) { page ->
        val e = queue.getOrNull(page)
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val off = abs((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).coerceIn(0f, 1f)
                    val s = 1f - 0.16f * off
                    scaleX = s
                    scaleY = s
                    alpha = 1f - 0.6f * off
                    rotationY = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).coerceIn(-1f, 1f) * -8f
                },
            contentAlignment = Alignment.Center
        ) {
            // 아트 비율: 정사각형 앨범 아트면 1:1, 영상 썸네일이면 원래 비율(16:9)
            var ratio by remember(e?.art) { mutableFloatStateOf(1f) }
            val aRatio by animateFloatAsState(ratio, spring(dampingRatio = 0.8f, stiffness = 300f), label = "artRatio")
            val w = if (maxWidth / aRatio <= maxHeight) maxWidth else maxHeight * aRatio
            val h = w / aRatio
            // 멈추면 아트가 살짝 작아지고, 재생하면 다시 커져요 (Apple Music 느낌)
            val playScale by animateFloatAsState(
                if (vm.isPlaying || page != curPos) 1f else 0.86f,
                spring(dampingRatio = 0.62f, stiffness = 260f), label = "artPlay"
            )
            HiResImage(
                url = e?.art, contentDescription = e?.title,
                modifier = Modifier.size(w, h)
                    .onGloballyPositioned { if (page == curPos) ArtMorph.measureBig(it) }
                    .graphicsLayer {
                        scaleX = playScale; scaleY = playScale
                        alpha = if (page == curPos && ArtMorph.flying) 0f else 1f
                    }
                    .shadow(if (vm.isPlaying) 28.dp else 12.dp, RoundedCornerShape(14.dp), ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(RoundedCornerShape(14.dp)),
                onBitmap = { bmp -> ratio = artRatioOf(bmp) }
            )
            // 아트를 두 번 톡톡 → 좋아요 (하트가 톡 튀어나와요)
            if (page == curPos) {
                val heart = remember { Animatable(0f) }
                val scope = rememberCoroutineScope()
                val longTick = rememberLongTick()
                Box(
                    Modifier.size(w, h).pointerInput(Unit) {
                        detectTapGestures(onDoubleTap = {
                            longTick()
                            if (!vm.isFavorite(vm.playingUrl)) vm.toggleFavoriteCurrent()
                            scope.launch {
                                heart.snapTo(0f)
                                heart.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 380f))
                                kotlinx.coroutines.delay(350)
                                heart.animateTo(0f, tween(220))
                            }
                        })
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Favorite, null,
                        Modifier.size(96.dp).graphicsLayer {
                            val v = heart.value
                            scaleX = 0.4f + 0.6f * v
                            scaleY = 0.4f + 0.6f * v
                            alpha = v.coerceIn(0f, 1f)
                        },
                        tint = Color.White
                    )
                }
            }
        }
    }
}

/** 시크바: 진행 위치는 '그리기'에서만 계산해 매 프레임 흐르고, 끄는 동안 손잡이가 커지며 시간 풍선이 떠요 */
@Composable
private fun SeekBar(vm: MainViewModel) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val dragState = rememberUpdatedState(drag)
    var lastDrag by remember { mutableFloatStateOf(0f) }
    val clock = rememberFrameClock(vm.isPlaying && drag == null)
    val slow = rememberSlowClock(vm.isPlaying)
    val thumb = animateFloatAsState(
        if (drag != null) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 480f), label = "thumb"
    )
    val primary by androidx.compose.animation.animateColorAsState(AlbumAccent.color, tween(600), label = "seekAccent")
    val trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)

    Box(Modifier.fillMaxWidth().height(36.dp), contentAlignment = Alignment.BottomCenter) {
        if (thumb.value > 0.01f) {
            GlassSurface(
                modifier = Modifier.graphicsLayer {
                    alpha = thumb.value.coerceIn(0f, 1f)
                    scaleX = 0.8f + 0.2f * thumb.value
                    scaleY = 0.8f + 0.2f * thumb.value
                    translationY = (1f - thumb.value) * 12f
                },
                shape = CircleShape,
                tint = primary
            ) {
                Text(
                    "${fmtTime((lastDrag * vm.durationMs).toLong())} / ${fmtTime(vm.durationMs)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }
        }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(36.dp)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o ->
                    val f = (o.x / size.width).coerceIn(0f, 1f)
                    vm.seek((f * vm.durationMs).toLong())
                })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        val f = (o.x / size.width).coerceIn(0f, 1f)
                        drag = f
                        lastDrag = f
                    },
                    onDragEnd = {
                        drag?.let { vm.seek((it * vm.durationMs).toLong()) }
                        drag = null
                    },
                    onDragCancel = { drag = null }
                ) { change, _ ->
                    change.consume()
                    val f = (change.position.x / size.width).coerceIn(0f, 1f)
                    drag = f
                    lastDrag = f
                }
            }
            .drawBehind {
                clock.value
                val d = vm.durationMs
                val f = (dragState.value ?: if (d > 0) vm.livePosition().toFloat() / d else 0f).coerceIn(0f, 1f)
                val t = thumb.value
                val h = 4.dp.toPx() + 2.dp.toPx() * t
                val cy = size.height / 2f
                val r = CornerRadius(h / 2f)
                drawRoundRect(trackColor, topLeft = Offset(0f, cy - h / 2f), size = Size(size.width, h), cornerRadius = r)
                drawRoundRect(primary, topLeft = Offset(0f, cy - h / 2f), size = Size(size.width * f, h), cornerRadius = r)
                drawCircle(primary, radius = 6.dp.toPx() + 4.dp.toPx() * t, center = Offset(size.width * f, cy))
            }
    )
    val shownPos = drag?.let { (it * vm.durationMs).toLong() } ?: run {
        slow.value
        vm.livePosition()
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(fmtTime(shownPos), style = MaterialTheme.typography.bodySmall)
        Text("-" + fmtTime((vm.durationMs - shownPos).coerceAtLeast(0L)), style = MaterialTheme.typography.bodySmall)
    }
}

/** 가사: 싱크 가사면 지금 부르는 줄이 커지고 밝아지며 자동으로 따라 내려가요 */
@Composable
private fun LyricsView(vm: MainViewModel, modifier: Modifier) {
    val state = vm.lyrics
    Box(modifier, contentAlignment = Alignment.Center) {
        when (state) {
            LyricsState.Idle, LyricsState.Loading -> CircularProgressIndicator()
            LyricsState.NotFound -> Text(
                "이 곡의 가사를 찾지 못했어요",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            is LyricsState.Plain -> Text(
                state.text.ifBlank { "가사가 비어 있어요" },
                style = MaterialTheme.typography.titleLarge.copy(lineHeight = 32.sp),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 24.dp)
            )
            is LyricsState.Synced -> SyncedLyrics(vm, state.lines)
        }
    }
}

@Composable
private fun SyncedLyrics(vm: MainViewModel, lines: List<LyricLine>) {
    val slow = rememberSlowClock(vm.isPlaying)
    val pos = run {
        slow.value
        vm.positionMs // 멈춰 있을 때도 위치 반영
        vm.livePosition()
    }
    val cur = lines.indexOfLast { it.ms <= pos + 250 }
    val listState = rememberLazyListState()
    LaunchedEffect(cur) {
        if (cur >= 0) listState.animateScrollToItem((cur - 1).coerceAtLeast(0))
    }
    // Apple Music 가사: 크고 굵게, 지금 줄만 또렷하고 멀어질수록 흐리고 옅게
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 24.dp, bottom = 240.dp, start = 4.dp, end = 4.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        itemsIndexed(lines, key = { i, _ -> i }) { i, line ->
            val active = i == cur
            val dist = if (cur < 0) 3 else abs(i - cur).coerceAtMost(4)
            val weight by animateFloatAsState(if (active) 1f else 0f, spring(dampingRatio = 0.7f, stiffness = 260f), label = "lyric")
            val blurR by animateFloatAsState(if (active) 0f else dist * 1.1f, tween(400), label = "lyricBlur")
            Text(
                line.text.ifBlank { "♪" },
                style = MaterialTheme.typography.headlineSmall.copy(lineHeight = 34.sp),
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = 0.28f + 0.72f * weight
                        val sc = 0.96f + 0.04f * weight
                        scaleX = sc
                        scaleY = sc
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                    }
                    .blur(blurR.dp, androidx.compose.ui.draw.BlurredEdgeTreatment.Unbounded)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { vm.seek(line.ms) }
                    .padding(vertical = 2.dp)
            )
        }
    }
}

/** 다음에 나올 곡 미리보기 (누르면 바로 넘어가요) */
@Composable
private fun UpNext(vm: MainViewModel) {
    val q = vm.queue
    val cp = q.indexOfFirst { it.index == vm.currentIndex }
    val next = when {
        vm.repeatMode == Player.REPEAT_MODE_ONE -> null
        cp >= 0 && cp + 1 < q.size -> q[cp + 1]
        vm.repeatMode == Player.REPEAT_MODE_ALL && q.isNotEmpty() -> q[0]
        else -> null
    }
    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        strong = true,
        onClick = if (next != null) vm::next else null,
        pressScale = 0.98f
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            AnimatedContent(
                targetState = next,
                transitionSpec = {
                    (fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 2 }) togetherWith
                        (fadeOut(tween(150)) + slideOutVertically(tween(150)) { -it / 2 })
                },
                label = "upNext",
                modifier = Modifier.weight(1f)
            ) { e ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (e != null) {
                        AsyncImage(
                            model = e.art, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(Modifier.width(10.dp))
                    }
                    Column {
                        Text(
                            if (vm.repeatMode == Player.REPEAT_MODE_ONE) "한 곡 반복 중" else "다음 곡",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            e?.title ?: if (vm.repeatMode == Player.REPEAT_MODE_ONE) vm.nowTitle else "대기열의 마지막 곡이에요",
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            if (next != null) Icon(Icons.Default.SkipNext, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}


/** 판 없는 아이콘 버튼: 누르면 살짝 작아졌다 튕겨 돌아와요 */
@Composable
private fun PlainControl(size: androidx.compose.ui.unit.Dp, onClick: () -> Unit, content: @Composable () -> Unit) {
    val tick = rememberTick()
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.82f else 1f, spring(dampingRatio = 0.45f, stiffness = 700f), label = "ctl")
    Box(
        Modifier.size(size)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(CircleShape)
            .clickable(interactionSource = src, indication = null) { tick(); onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}


/**
 * 볼륨 바: 기기 음량(미디어)을 바로 조절해요.
 * 볼륨 버튼으로 바꿔도 따라 움직이고, 끄는 동안엔 바가 살짝 두꺼워져요.
 */
@Composable
private fun VolumeBar() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val am = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    val stream = android.media.AudioManager.STREAM_MUSIC
    val max = remember { am.getStreamMaxVolume(stream).coerceAtLeast(1) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(stream) / max.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    val draggingNow by rememberUpdatedState(dragging)

    DisposableEffect(Unit) {
        val obs = object : android.database.ContentObserver(android.os.Handler(android.os.Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                if (!draggingNow) vol = am.getStreamVolume(stream) / max.toFloat()
            }
        }
        ctx.contentResolver.registerContentObserver(android.provider.Settings.System.CONTENT_URI, true, obs)
        onDispose { ctx.contentResolver.unregisterContentObserver(obs) }
    }

    fun apply(f: Float) {
        vol = f.coerceIn(0f, 1f)
        val steps = (vol * max).roundToInt().coerceIn(0, max)
        if (steps != am.getStreamVolume(stream)) runCatching { am.setStreamVolume(stream, steps, 0) }
    }

    val thick by animateFloatAsState(if (dragging) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "volThick")
    val shown by animateFloatAsState(vol, spring(dampingRatio = 0.9f, stiffness = 800f), label = "vol")
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
    val fill = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.VolumeMute, "작게", Modifier.size(18.dp).clickable { apply(vol - 1f / max) }, tint = dim)
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .weight(1f)
                .height(28.dp)
                .pointerInput(Unit) {
                    detectTapGestures { o -> apply(o.x / size.width) }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> dragging = true; apply(o.x / size.width) },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false }
                    ) { change, _ ->
                        change.consume()
                        apply(change.position.x / size.width)
                    }
                }
                .drawBehind {
                    val h = (4.dp.toPx() + 4.dp.toPx() * thick)
                    val cy = size.height / 2f
                    val r = androidx.compose.ui.geometry.CornerRadius(h / 2f)
                    drawRoundRect(track, topLeft = Offset(0f, cy - h / 2f), size = Size(size.width, h), cornerRadius = r)
                    drawRoundRect(fill, topLeft = Offset(0f, cy - h / 2f), size = Size(size.width * shown, h), cornerRadius = r)
                }
        )
        Spacer(Modifier.width(10.dp))
        Icon(Icons.Default.VolumeUp, "크게", Modifier.size(18.dp).clickable { apply(vol + 1f / max) }, tint = dim)
    }
}


/**
 * 오디오 비주얼라이저: 소리에 맞춰 출렁이는 부드러운 파동 세 가닥.
 * 왼쪽은 낮은음, 오른쪽은 높은음의 세기를 따라 그 자리의 물결이 커져요. 멈추면 잔잔한 선으로.
 * 재생 화면이 펼쳐져 있을 때만 매 프레임 그려요.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
private fun AudioVisualizer(vm: MainViewModel, expand: Animatable<Float, AnimationVector1D>) {
    val n = Spectrum.BANDS
    val open by remember { derivedStateOf { expand.value > 0.3f } }
    val clock = rememberFrameClock(open)
    val target = remember { FloatArray(n) }
    val shown = remember { FloatArray(n) }
    val smooth = remember { FloatArray(n) }
    val accent by androidx.compose.animation.animateColorAsState(AlbumAccent.color, tween(600), label = "vizAccent")
    androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(56.dp)) {
        clock.value
        if (vm.isPlaying) Spectrum.current(target) else java.util.Arrays.fill(target, 0f)
        // 막대 값을 부드럽게 따라가고, 옆 칸끼리 섞어 매끈한 곡선으로
        for (i in 0 until n) {
            val tv = target[i]
            shown[i] = if (tv > shown[i]) shown[i] + (tv - shown[i]) * 0.35f else shown[i] * 0.92f + tv * 0.08f
        }
        for (i in 0 until n) {
            val a = shown[(i - 1).coerceAtLeast(0)]
            val b = shown[(i + 1).coerceAtMost(n - 1)]
            smooth[i] = (a + shown[i] * 2f + b) / 4f
        }
        val w = size.width
        val cy = size.height / 2f
        val maxH = size.height / 2f * 0.92f
        val time = System.nanoTime() / 1_000_000_000.0
        val step = 3f
        // 세 가닥: 굵고 진한 선 + 옅은 선 두 개가 서로 다른 박자로 흘러요
        val layers = arrayOf(
            floatArrayOf(1.00f, 2.2f, 1.6f, 1.0f, 2.2f),
            floatArrayOf(0.70f, 3.1f, -2.1f, 0.45f, 1.5f),
            floatArrayOf(0.45f, 1.6f, 2.7f, 0.25f, 1.2f)
        )
        for (L in layers) {
            val (scale, freq, speed, alpha, strokeDp) = L.toList()
            val path = androidx.compose.ui.graphics.Path()
            var x = 0f
            while (x <= w) {
                val u = x / w
                // 양 끝은 0으로 모이고 가운데가 가장 크게 (파동이 화면 안에서 숨 쉬듯)
                val env = kotlin.math.sin(Math.PI * u).toFloat().let { it * it }
                val fi = u * (n - 1)
                val i0 = fi.toInt().coerceIn(0, n - 1)
                val i1 = (i0 + 1).coerceAtMost(n - 1)
                val lv = smooth[i0] + (smooth[i1] - smooth[i0]) * (fi - i0)
                val amp = maxH * (0.03f + 0.97f * lv) * env * scale
                val y = cy + amp * kotlin.math.sin(u * freq * 2.0 * Math.PI + time * speed).toFloat()
                if (x == 0f) path.moveTo(x, y) else path.lineTo(x, y)
                x += step
            }
            drawPath(
                path, accent.copy(alpha = alpha),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeDp.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
        }
    }
}
