@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.example.ytplaylist

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.view.KeyEvent
import androidx.media3.session.MediaButtonReceiver

/** 알림창 빠른 설정 타일: 눌러서 재생/일시정지 (길게 누르면 앱이 열려요) */
class PlayTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val i = Intent(Intent.ACTION_MEDIA_BUTTON)
            .setComponent(ComponentName(this, MediaButtonReceiver::class.java))
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        sendBroadcast(i)
        // 재생 상태가 바뀌는 데 조금 걸려서 잠시 뒤 다시 그려요
        android.os.Handler(mainLooper).postDelayed({ refresh() }, 600L)
    }

    private fun refresh() {
        val t = qsTile ?: return
        val playing = PlaybackService.instance?.isPlayingNow() == true
        val title = getSharedPreferences("yt", Context.MODE_PRIVATE).getString("w_title", "") ?: ""
        t.state = if (playing) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = if (playing) "재생 중" else "Playlist"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = TitleClean.title(title).take(24).ifBlank { null }
        t.icon = Icon.createWithResource(this, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        t.updateTile()
    }
}
