package com.example.ytplaylist

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.C

/** 이퀄라이저 / 저음 강화 / 음량 키우기 (재생 중인 소리에 바로 적용) */
object AudioFx {
    var available by mutableStateOf(false)
    var fxOn by mutableStateOf(false)
    var minLevel by mutableIntStateOf(-1500)
    var maxLevel by mutableIntStateOf(1500)
    val freqs = mutableStateListOf<Int>()
    val levels = mutableStateListOf<Int>()
    var presets by mutableStateOf<List<String>>(emptyList())
    var bass by mutableIntStateOf(0)
    var boost by mutableIntStateOf(0)

    private var eq: Equalizer? = null
    private var bassFx: BassBoost? = null
    private var loudFx: LoudnessEnhancer? = null
    private var prefs: SharedPreferences? = null
    private var savedLevels: List<Int> = emptyList()

    fun load(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("yt", Context.MODE_PRIVATE)
        prefs = p
        fxOn = p.getBoolean("fx_enabled", false)
        bass = p.getInt("fx_bass", 0)
        boost = p.getInt("fx_boost", 0)
        savedLevels = (p.getString("fx_levels", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
    }

    fun attach(ctx: Context, sessionId: Int) {
        if (prefs == null) load(ctx)
        release()
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        try {
            val q = Equalizer(0, sessionId)
            val n = q.numberOfBands.toInt()
            val range = q.bandLevelRange
            minLevel = range[0].toInt()
            maxLevel = range[1].toInt()
            freqs.clear()
            levels.clear()
            for (b in 0 until n) {
                freqs.add(q.getCenterFreq(b.toShort()) / 1000)
                levels.add(savedLevels.getOrNull(b) ?: q.getBandLevel(b.toShort()).toInt())
            }
            presets = (0 until q.numberOfPresets.toInt()).map { q.getPresetName(it.toShort()) }
            eq = q
            available = true
        } catch (e: Throwable) {
            eq = null
        }
        try { bassFx = BassBoost(0, sessionId) } catch (e: Throwable) { bassFx = null }
        try { loudFx = LoudnessEnhancer(sessionId) } catch (e: Throwable) { loudFx = null }
        applyAll()
    }

    fun release() {
        try { eq?.release() } catch (e: Throwable) {}
        try { bassFx?.release() } catch (e: Throwable) {}
        try { loudFx?.release() } catch (e: Throwable) {}
        eq = null
        bassFx = null
        loudFx = null
        available = false
    }

    private fun applyAll() {
        try {
            eq?.let { q ->
                levels.forEachIndexed { b, v ->
                    q.setBandLevel(b.toShort(), v.coerceIn(minLevel, maxLevel).toShort())
                }
                q.setEnabled(fxOn)
            }
        } catch (e: Throwable) {}
        try {
            bassFx?.let { b ->
                if (b.strengthSupported) b.setStrength(bass.toShort())
                b.setEnabled(fxOn && bass > 0)
            }
        } catch (e: Throwable) {}
        try {
            loudFx?.let { l ->
                l.setTargetGain(boost)
                l.setEnabled(fxOn && boost > 0)
            }
        } catch (e: Throwable) {}
    }

    private fun save() {
        savedLevels = levels.toList()
        prefs?.edit()
            ?.putBoolean("fx_enabled", fxOn)
            ?.putInt("fx_bass", bass)
            ?.putInt("fx_boost", boost)
            ?.putString("fx_levels", levels.joinToString(","))
            ?.apply()
    }

    fun updateOn(v: Boolean) { fxOn = v; save(); applyAll() }

    fun updateLevel(band: Int, v: Int) {
        if (band !in levels.indices) return
        levels[band] = v
        save()
        applyAll()
    }

    fun usePreset(i: Int) {
        val q = eq ?: return
        try {
            q.usePreset(i.toShort())
            for (b in levels.indices) levels[b] = q.getBandLevel(b.toShort()).toInt()
            save()
            applyAll()
        } catch (e: Throwable) {}
    }

    fun resetLevels() {
        for (b in levels.indices) levels[b] = 0
        save()
        applyAll()
    }

    fun updateBass(v: Int) { bass = v; save(); applyAll() }
    fun updateBoost(v: Int) { boost = v; save(); applyAll() }
}
