package com.example.ytplaylist

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * 집중 모드 (뽀모도로): 공부 시간엔 음악, 쉬는 시간엔 음악을 멈추고 알려줘요.
 * 오늘 몇 세트 했는지 기록해요.
 */
object FocusMode {
    var running by mutableStateOf(false)
        private set
    var onBreak by mutableStateOf(false)
        private set
    var remainingMs by mutableLongStateOf(0L)
        private set
    var workMin by mutableIntStateOf(25)
    var breakMin by mutableIntStateOf(5)
    var instrumentalOnly by mutableStateOf(false)
    var doneToday by mutableIntStateOf(0)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("yt", Context.MODE_PRIVATE)
        workMin = p.getInt("focus_work", 25)
        breakMin = p.getInt("focus_break", 5)
        instrumentalOnly = p.getBoolean("focus_instr", false)
        doneToday = if (p.getString("focus_day", "") == Stats.dayKey(System.currentTimeMillis())) p.getInt("focus_done", 0) else 0
    }

    private fun save(ctx: Context) {
        ctx.getSharedPreferences("yt", Context.MODE_PRIVATE).edit()
            .putInt("focus_work", workMin).putInt("focus_break", breakMin)
            .putBoolean("focus_instr", instrumentalOnly)
            .putString("focus_day", Stats.dayKey(System.currentTimeMillis()))
            .putInt("focus_done", doneToday)
            .apply()
    }

    /** play/pause: 음악 재생/멈춤, notify: 화면에 알림 */
    fun start(ctx: Context, play: () -> Unit, pause: () -> Unit, notify: (String) -> Unit) {
        val app = ctx.applicationContext
        job?.cancel()
        running = true
        onBreak = false
        remainingMs = workMin * 60_000L
        save(app)
        play()
        job = scope.launch {
            while (isActive) {
                delay(1000L)
                remainingMs -= 1000L
                if (remainingMs > 0) continue
                if (!onBreak) {
                    doneToday++
                    onBreak = true
                    remainingMs = breakMin * 60_000L
                    pause()
                    notify("수고했어요! ${breakMin}분 쉬어요 (오늘 ${doneToday}세트)")
                } else {
                    onBreak = false
                    remainingMs = workMin * 60_000L
                    play()
                    notify("다시 집중할 시간이에요")
                }
                save(app)
            }
        }
    }

    fun stop(ctx: Context) {
        job?.cancel()
        job = null
        running = false
        onBreak = false
        remainingMs = 0L
        save(ctx.applicationContext)
    }

    fun persist(ctx: Context) = save(ctx.applicationContext)
}

/**
 * 배경 소리: 음악 밑에 깔리는 노이즈를 직접 만들어 틀어요 (파일 없이).
 * 백색(쏴-), 핑크(빗소리 느낌), 브라운(파도·바람 느낌)
 */
object NoisePlayer {
    val names = listOf("끄기", "백색 소음", "빗소리 (핑크)", "파도 (브라운)")
    var type by mutableIntStateOf(0)
        private set
    var volume by mutableFloatStateOf(0.35f)

    @Volatile private var track: AudioTrack? = null
    @Volatile private var playing = false
    private var thread: Thread? = null

    fun select(t: Int) {
        type = t
        if (t == 0) stop() else start()
    }

    fun updateVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        runCatching { track?.setVolume(volume) }
    }

    private fun start() {
        if (playing) return
        val rate = 44100
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(maxOf(min, 8192) * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        }.getOrNull() ?: return
        track = t
        playing = true
        t.setVolume(volume)
        t.play()
        thread = Thread {
            val buf = ShortArray(2048)
            val rnd = Random(System.nanoTime())
            // 핑크 노이즈 필터 상태 (Paul Kellet), 브라운 노이즈 누적값
            var b0 = 0.0; var b1 = 0.0; var b2 = 0.0; var b3 = 0.0; var b4 = 0.0; var b5 = 0.0; var b6 = 0.0
            var brown = 0.0
            var swell = 0.0
            while (playing) {
                for (i in buf.indices) {
                    val w = rnd.nextDouble() * 2 - 1
                    val v = when (type) {
                        2 -> {
                            b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759
                            b2 = 0.96900 * b2 + w * 0.1538520; b3 = 0.86650 * b3 + w * 0.3104856
                            b4 = 0.55000 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.0168980
                            val pink = b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362
                            b6 = w * 0.115926
                            pink * 0.11
                        }
                        3 -> {
                            brown = (brown + 0.02 * w) / 1.02
                            // 파도처럼 천천히 커졌다 작아졌다
                            swell += 1.0 / (44100 * 7)
                            brown * 3.2 * (0.55 + 0.45 * kotlin.math.sin(swell * 2 * Math.PI))
                        }
                        else -> w * 0.35
                    }
                    buf[i] = (v.coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
                }
                val tr = track ?: break
                val n = runCatching { tr.write(buf, 0, buf.size) }.getOrDefault(-1)
                if (n < 0) break
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun stop() {
        playing = false
        val t = track
        track = null
        runCatching { t?.pause(); t?.flush(); t?.release() }
    }
}
