@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ytplaylist

import android.os.SystemClock
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import kotlinx.coroutines.delay
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

fun mb(bytes: Long): String =
    if (bytes >= 1024L * 1024L * 1024L) "%.1f GB".format(bytes / 1073741824.0)
    else "%.0f MB".format(bytes / 1048576.0)

@Composable
fun GlassChip(label: String, selected: Boolean = false, icon: ImageVector? = null, onClick: () -> Unit) {
    GlassSurface(
        shape = CircleShape,
        tint = if (selected) MaterialTheme.colorScheme.primary else null,
        onClick = onClick
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(icon, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
            }
            Text(
                label, maxLines = 1,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun TrackRowContent(
    t: Track, selected: Boolean, playing: Boolean, cached: Boolean, pinned: Boolean, favorite: Boolean,
    isNew: Boolean = false
) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
            AsyncImage(
                model = t.thumb,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (selected) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)), contentAlignment = Alignment.Center) {
                    NowPlayingBars(playing, Color.White, Modifier.size(18.dp))
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.shownTitle, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isNew) {
                    Text(
                        "NEW",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.primary).padding(horizontal = 4.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                }
                if (favorite) {
                    Icon(Icons.Default.Favorite, "좋아요", Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    t.shownArtist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        when {
            pinned -> {
                Icon(Icons.Default.DownloadForOffline, "오프라인 저장됨", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
            }
            cached -> {
                Icon(Icons.Default.DownloadDone, "캐시됨", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
            }
        }
        Text(
            fmtTime(t.durationSec * 1000),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/**
 * 곡 한 줄: 누르면 재생, 길게 누르면 메뉴,
 * 오른쪽으로 밀면 '다음에 재생', 왼쪽으로 밀면 '대기열에 추가'
 */
@Composable
fun TrackRow(
    t: Track,
    selected: Boolean,
    playing: Boolean,
    cached: Boolean,
    pinned: Boolean,
    favorite: Boolean,
    dimmed: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onSwipeRight: () -> Unit,
    onSwipeLeft: () -> Unit,
    modifier: Modifier = Modifier,
    isNew: Boolean = false
) {
    val tick = rememberTick()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        if (pressed) 0.97f else 1f, spring(dampingRatio = 0.6f, stiffness = 700f), label = "rowPress"
    )
    val longTick = rememberLongTick()
    val offset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val threshold = with(density) { 90.dp.toPx() }
    val maxDrag = with(density) { 140.dp.toPx() }
    val right by rememberUpdatedState(onSwipeRight)
    val left by rememberUpdatedState(onSwipeLeft)
    val shape = RoundedCornerShape(16.dp)
    val primary = MaterialTheme.colorScheme.primary

    Box(
        modifier.fillMaxWidth().padding(vertical = 2.dp).graphicsLayer {
            scaleX = pressScale
            scaleY = pressScale
        }
    ) {
        val v = offset.value
        if (v != 0f) {
            Row(
                Modifier
                    .matchParentSize()
                    .clip(shape)
                    .background(primary.copy(alpha = if (abs(v) > threshold) 0.30f else 0.14f))
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (v > 0) Arrangement.Start else Arrangement.End
            ) {
                Icon(if (v > 0) Icons.Default.SkipNext else Icons.Default.QueueMusic, null, tint = primary)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (v > 0) "다음에 재생" else "대기열에 추가",
                    style = MaterialTheme.typography.labelLarge,
                    color = primary
                )
            }
        }

        val dragModifier = Modifier
            .fillMaxWidth()
            .offset { IntOffset(offset.value.roundToInt(), 0) }
            .pointerInput(t.url) {
                var acc = 0f
                var armed = false
                detectHorizontalDragGestures(
                    onDragStart = {
                        acc = 0f
                        armed = false
                    },
                    onDragEnd = {
                        val end = acc
                        scope.launch { offset.animateTo(0f) }
                        if (end > threshold) right() else if (end < -threshold) left()
                    },
                    onDragCancel = { scope.launch { offset.animateTo(0f) } }
                ) { change, amount ->
                    change.consume()
                    acc = (acc + amount).coerceIn(-maxDrag, maxDrag)
                    val over = abs(acc) > threshold
                    if (over && !armed) longTick()
                    armed = over
                    val target = acc
                    scope.launch { offset.snapTo(target) }
                }
            }
            .alpha(if (dimmed) 0.4f else 1f)

        val click = Modifier.combinedClickable(
            interactionSource = source,
            indication = LocalIndication.current,
            onClick = { tick(); onClick() },
            onLongClick = { longTick(); onLongClick() }
        )

        if (selected) {
            Box(dragModifier.clip(shape).background(Color.White.copy(alpha = 0.08f)).then(click)) {
                TrackRowContent(t, true, playing, cached, pinned, favorite, isNew)
            }
        } else {
            Box(dragModifier.clip(shape).then(click)) {
                TrackRowContent(t, false, playing, cached, pinned, favorite, isNew)
            }
        }
    }
}

/** 지금 재생 위치 (시계로 계산, 화면 재구성을 일으키지 않음) */
fun MainViewModel.livePosition(): Long {
    val p = if (isPlaying) positionMs + ((SystemClock.elapsedRealtime() - positionAt) * speed).toLong() else positionMs
    return if (durationMs > 0) p.coerceIn(0L, durationMs) else p.coerceAtLeast(0L)
}

/** 재생 중일 때만 매 프레임 바뀌는 값. '그리기' 단계에서만 읽어서 진행바만 다시 그려요 */
@Composable
fun rememberFrameClock(running: Boolean): State<Long> {
    val t = remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) {
        if (running) while (true) withFrameMillis { t.longValue = it }
    }
    return t
}

/** 1초에 4번 바뀌는 값 (시간 글자처럼 자주 안 바뀌어도 되는 곳) */
@Composable
fun rememberSlowClock(running: Boolean): State<Long> {
    val t = remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) {
        if (running) while (true) {
            t.longValue = SystemClock.elapsedRealtime()
            delay(250)
        }
    }
    return t
}

/** 재생/일시정지 아이콘이 서로 녹아들 듯 바뀌어요 */
@Composable
fun PlayPauseIcon(playing: Boolean, size: Dp) {
    AnimatedContent(
        targetState = playing,
        transitionSpec = {
            (scaleIn(initialScale = 0.5f, animationSpec = spring(0.6f, 600f)) + fadeIn(tween(160))) togetherWith
                (scaleOut(targetScale = 0.5f, animationSpec = tween(140)) + fadeOut(tween(140)))
        },
        label = "playPause"
    ) { p ->
        Icon(
            if (p) Icons.Default.Pause else Icons.Default.PlayArrow,
            if (p) "일시정지" else "재생",
            Modifier.size(size)
        )
    }
}

@Composable
private fun MiniProgress(vm: MainViewModel) {
    val clock = rememberFrameClock(vm.isPlaying)
    val trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    val barColor = MaterialTheme.colorScheme.primary
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .padding(bottom = 10.dp)
            .height(3.dp)
            .drawBehind {
                clock.value
                val d = vm.durationMs
                val f = if (d > 0) (vm.livePosition().toFloat() / d).coerceIn(0f, 1f) else 0f
                val r = CornerRadius(size.height / 2f)
                drawRoundRect(trackColor, cornerRadius = r)
                drawRoundRect(barColor, size = Size(size.width * f, size.height), cornerRadius = r)
            }
    )
}

/**
 * 하단 미니 플레이어
 * - 좌우로 밀면: 곡 정보가 손가락을 따라 밀려나고, 다음/이전 곡이 반대편에서 미끄러져 들어와요
 * - 위로 밀면: 전체 플레이어가 손가락을 따라 올라와요 (놓으면 속도에 맞춰 펼쳐지거나 돌아감)
 * - 누르면: 전체 플레이어 열기
 */
@Composable
fun MiniPlayer(
    vm: MainViewModel,
    onOpen: () -> Unit,
    onVerticalDrag: (Float) -> Unit,
    onVerticalEnd: (Float) -> Unit
) {
    val longTick = rememberLongTick()
    val dx = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val th = with(density) { 60.dp.toPx() }
    var widthPx by remember { mutableFloatStateOf(1f) }
    val vDrag by rememberUpdatedState(onVerticalDrag)
    val vEnd by rememberUpdatedState(onVerticalEnd)

    fun commit(ax: Float, vx: Float) {
        scope.launch {
            val goNext = ax < -th || vx < -900f
            val goPrev = ax > th || vx > 900f
            if (goNext || goPrev) {
                longTick()
                val w = widthPx
                dx.animateTo(if (goNext) -w else w, tween(150, easing = FastOutLinearInEasing))
                if (goNext) vm.next() else vm.previous()
                dx.snapTo(if (goNext) w * 0.6f else -w * 0.6f)
                dx.animateTo(0f, spring(dampingRatio = 0.68f, stiffness = 280f))
            } else {
                dx.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = 420f))
            }
        }
    }

    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                val tracker = VelocityTracker()
                var axis = 0 // 0 미정, 1 가로, 2 세로
                var ax = 0f
                var ay = 0f
                detectDragGestures(
                    onDragStart = {
                        axis = 0
                        ax = 0f
                        ay = 0f
                        tracker.resetTracking()
                    },
                    onDragEnd = {
                        val v = tracker.calculateVelocity()
                        when (axis) {
                            1 -> commit(ax, v.x)
                            2 -> vEnd(v.y)
                        }
                    },
                    onDragCancel = {
                        if (axis == 2) vEnd(0f)
                        scope.launch { dx.animateTo(0f) }
                    }
                ) { change, amount ->
                    change.consume()
                    tracker.addPosition(change.uptimeMillis, change.position)
                    ax += amount.x
                    ay += amount.y
                    if (axis == 0) axis = if (abs(ax) > abs(ay)) 1 else 2
                    if (axis == 1) {
                        val t = ax
                        scope.launch { dx.snapTo(t) }
                    } else {
                        vDrag(amount.y)
                    }
                }
            },
        shape = RoundedCornerShape(28.dp),
        strong = true,
        onClick = onOpen,
        pressScale = 0.98f
    ) {
        Column {
            Box(
                Modifier.padding(top = 6.dp).size(width = 32.dp, height = 4.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f))
                    .align(Alignment.CenterHorizontally)
            )
            Row(
                Modifier.padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 곡 정보만 좌우로 미끄러져요 (버튼은 제자리)
                Row(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .graphicsLayer {
                            translationX = dx.value
                            alpha = 1f - (abs(dx.value) / widthPx).coerceIn(0f, 1f) * 1.2f
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Crossfade(targetState = vm.nowArt, animationSpec = tween(350), label = "miniArt") { art ->
                        AsyncImage(
                            model = art, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.size(48.dp)
                                .onGloballyPositioned { ArtMorph.mini = it.boundsInRoot() }
                                .graphicsLayer { alpha = if (ArtMorph.flying) 0f else 1f }
                                .clip(RoundedCornerShape(10.dp))
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(TitleClean.title(vm.nowTitle, vm.nowArtist), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(
                            TitleClean.artist(vm.nowArtist), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Box(contentAlignment = Alignment.Center) {
                    IconButton(onClick = vm::togglePlay) { PlayPauseIcon(vm.isPlaying, 24.dp) }
                    if (vm.isBuffering) CircularProgressIndicator(Modifier.size(40.dp), strokeWidth = 2.dp)
                }
                IconButton(onClick = vm::next) { Icon(Icons.Default.SkipNext, "다음") }
            }
            MiniProgress(vm)
        }
    }
}

/** 목록을 불러오는 동안 보여줄 반짝이는 자리표시 줄 */
@Composable
fun SkeletonList(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "skeleton")
    val a by t.animateFloat(
        initialValue = 0.10f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "alpha"
    )
    val c = MaterialTheme.colorScheme.onSurface.copy(alpha = a)
    Column(modifier) {
        repeat(8) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(c))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Box(Modifier.fillMaxWidth(0.7f).height(14.dp).clip(CircleShape).background(c))
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth(0.4f).height(10.dp).clip(CircleShape).background(c))
                }
            }
        }
    }
}

/** 알아듣기 쉬운 오류 카드 + 다시 시도 */
@Composable
fun ErrorCard(message: String, onRetry: (() -> Unit)?, onDismiss: () -> Unit) {
    GlassSurface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        shape = RoundedCornerShape(18.dp),
        tint = MaterialTheme.colorScheme.error
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ErrorOutline, null, tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(10.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            if (onRetry != null) TextButton(onClick = onRetry) { Text("다시 시도") }
            IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "닫기", Modifier.size(18.dp)) }
        }
    }
}

/** 설정 화면의 스위치 한 줄 */
@Composable
fun SwitchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val tick = rememberTick()
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            if (desc != null) {
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = { tick(); onChange(it) })
    }
}

/** 아이콘 + 작은 글씨 버튼 (전체 플레이어 하단 도구) */
@Composable
fun ToolButton(icon: ImageVector, label: String, active: Boolean = false, onClick: () -> Unit) {
    val tick = rememberTick()
    val color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = { tick(); onClick() }) { Icon(icon, label, tint = color) }
        Text(label, style = MaterialTheme.typography.labelSmall, color = color, maxLines = 1)
    }
}


/** 유튜브 썸네일을 가장 높은 화질부터 시도 (없으면 원래 주소로) */
fun hiResCandidates(url: String?): List<String> {
    if (url.isNullOrBlank()) return emptyList()
    val yt = Regex("""i\.ytimg\.com/vi(?:_webp)?/([A-Za-z0-9_-]{6,})/""").find(url)
    if (yt != null) {
        val id = yt.groupValues[1]
        return listOf("https://i.ytimg.com/vi/$id/maxresdefault.jpg", url).distinct()
    }
    val g = Regex("""=w\d+-h\d+""")
    if (url.contains("googleusercontent") && g.containsMatchIn(url)) {
        return listOf(url.replace(g, "=w1200-h1200"), url)
    }
    return listOf(url)
}

@Composable
fun HiResImage(
    url: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: androidx.compose.ui.layout.ContentScale = androidx.compose.ui.layout.ContentScale.Crop,
    onBitmap: ((android.graphics.Bitmap) -> Unit)? = null
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val cands = remember(url) { hiResCandidates(url) }
    var i by remember(url) { mutableIntStateOf(0) }
    val req = remember(url, i) {
        coil.request.ImageRequest.Builder(ctx)
            .data(cands.getOrNull(i))
            .allowHardware(onBitmap == null) // 픽셀을 읽어야 할 때만 소프트웨어 비트맵
            .crossfade(250)
            .build()
    }
    coil.compose.AsyncImage(
        model = req,
        contentDescription = contentDescription,
        contentScale = contentScale,
        modifier = modifier,
        onError = { if (i < cands.size - 1) i++ },
        onSuccess = { st ->
            val d = st.result.drawable
            if (onBitmap != null && d is android.graphics.drawable.BitmapDrawable) onBitmap(d.bitmap)
        }
    )
}

/**
 * 썸네일이 '정사각형 앨범 아트 + 양옆 단색 띠'인지 보고 보여줄 비율을 정해요.
 * 띠가 있으면 1:1(가운데만), 아니면 원래 비율(보통 16:9) 그대로.
 */
fun artRatioOf(b: android.graphics.Bitmap): Float {
    val w = b.width
    val h = b.height
    if (w <= 0 || h <= 0) return 1f
    val r = w.toFloat() / h
    if (r < 1.2f) return 1f
    val m = (w - h) / 2
    if (m < 8) return 1f
    fun bandFlat(x0: Int, x1: Int): Boolean {
        var n = 0
        var sr = 0.0; var sg = 0.0; var sb = 0.0
        val px = ArrayList<Int>()
        for (yi in 1..7) for (xi in 0..2) {
            val x = (x0 + (x1 - x0) * (xi + 0.5f) / 3f).toInt().coerceIn(0, w - 1)
            val y = (h * yi / 8f).toInt().coerceIn(0, h - 1)
            val c = b.getPixel(x, y)
            px += c
            sr += (c shr 16 and 0xFF); sg += (c shr 8 and 0xFF); sb += (c and 0xFF); n++
        }
        sr /= n; sg /= n; sb /= n
        val maxDev = px.maxOf { c ->
            maxOf(kotlin.math.abs((c shr 16 and 0xFF) - sr), kotlin.math.abs((c shr 8 and 0xFF) - sg), kotlin.math.abs((c and 0xFF) - sb))
        }
        return maxDev < 26.0
    }
    val inset = (m * 0.15f).toInt()
    return if (bandFlat(inset, m - inset) && bandFlat(w - m + inset, w - inset)) 1f else r
}


/** 재생 중 표시: 막대 4개가 음악처럼 출렁여요 (멈추면 낮게 멈춤). 그리기 단계에서만 움직여요 */
@Composable
fun NowPlayingBars(playing: Boolean, color: Color, modifier: Modifier = Modifier) {
    val tr = androidx.compose.animation.core.rememberInfiniteTransition(label = "bars")
    val ph = tr.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        androidx.compose.animation.core.infiniteRepeatable(tween(1100, easing = androidx.compose.animation.core.LinearEasing)),
        label = "barsPhase"
    )
    val amp by animateFloatAsState(if (playing) 1f else 0f, tween(300), label = "barsAmp")
    Canvas(modifier) {
        val n = 4
        val gap = size.width * 0.12f
        val bw = (size.width - gap * (n - 1)) / n
        val speeds = floatArrayOf(1f, 2f, 1f, 3f)
        val offs = floatArrayOf(0f, 1.3f, 2.6f, 0.7f)
        for (i in 0 until n) {
            val wave = 0.5f + 0.5f * kotlin.math.sin(ph.value * speeds[i] + offs[i])
            val hFrac = 0.22f + amp * 0.78f * wave
            val h = size.height * hFrac
            drawRoundRect(
                color,
                topLeft = androidx.compose.ui.geometry.Offset(i * (bw + gap), size.height - h),
                size = androidx.compose.ui.geometry.Size(bw, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(bw / 2f)
            )
        }
    }
}
