@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ytplaylist

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

fun mb(bytes: Long): String =
    if (bytes >= 1024L * 1024L * 1024L) "%.1f GB".format(bytes / 1073741824.0)
    else "%.0f MB".format(bytes / 1048576.0)

@Composable
fun GlassChip(label: String, selected: Boolean = false, icon: ImageVector? = null, onClick: () -> Unit) {
    GlassSurface(
        shape = CircleShape,
        tint = if (selected) MaterialTheme.colorScheme.primary else null,
        onClick = onClick
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(icon, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
            }
            Text(
                label, maxLines = 1,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun TrackRowContent(
    t: Track, selected: Boolean, playing: Boolean, cached: Boolean, pinned: Boolean, favorite: Boolean
) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(
            model = t.thumb,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(52.dp).clip(RoundedCornerShape(10.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (favorite) {
                    Icon(Icons.Default.Favorite, "좋아요", Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        when {
            pinned -> {
                Icon(Icons.Default.DownloadForOffline, "오프라인 저장됨", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
            }
            cached -> {
                Icon(Icons.Default.DownloadDone, "캐시됨", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
            }
        }
        if (playing) {
            Icon(Icons.Default.GraphicEq, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
        }
        Text(
            fmtTime(t.durationSec * 1000),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/**
 * 곡 한 줄: 누르면 재생, 길게 누르면 메뉴,
 * 오른쪽으로 밀면 '다음에 재생', 왼쪽으로 밀면 '대기열에 추가'
 */
@Composable
fun TrackRow(
    t: Track,
    selected: Boolean,
    playing: Boolean,
    cached: Boolean,
    pinned: Boolean,
    favorite: Boolean,
    dimmed: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onSwipeRight: () -> Unit,
    onSwipeLeft: () -> Unit
) {
    val tick = rememberTick()
    val longTick = rememberLongTick()
    val offset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val threshold = with(density) { 90.dp.toPx() }
    val maxDrag = with(density) { 140.dp.toPx() }
    val right by rememberUpdatedState(onSwipeRight)
    val left by rememberUpdatedState(onSwipeLeft)
    val shape = RoundedCornerShape(16.dp)
    val primary = MaterialTheme.colorScheme.primary

    Box(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        val v = offset.value
        if (v != 0f) {
            Row(
                Modifier
                    .matchParentSize()
                    .clip(shape)
                    .background(primary.copy(alpha = if (abs(v) > threshold) 0.30f else 0.14f))
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (v > 0) Arrangement.Start else Arrangement.End
            ) {
                Icon(if (v > 0) Icons.Default.SkipNext else Icons.Default.QueueMusic, null, tint = primary)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (v > 0) "다음에 재생" else "대기열에 추가",
                    style = MaterialTheme.typography.labelLarge,
                    color = primary
                )
            }
        }

        val dragModifier = Modifier
            .fillMaxWidth()
            .offset { IntOffset(offset.value.roundToInt(), 0) }
            .pointerInput(t.url) {
                var acc = 0f
                var armed = false
                detectHorizontalDragGestures(
                    onDragStart = {
                        acc = 0f
                        armed = false
                    },
                    onDragEnd = {
                        val end = acc
                        scope.launch { offset.animateTo(0f) }
                        if (end > threshold) right() else if (end < -threshold) left()
                    },
                    onDragCancel = { scope.launch { offset.animateTo(0f) } }
                ) { change, amount ->
                    change.consume()
                    acc = (acc + amount).coerceIn(-maxDrag, maxDrag)
                    val over = abs(acc) > threshold
                    if (over && !armed) longTick()
                    armed = over
                    val target = acc
                    scope.launch { offset.snapTo(target) }
                }
            }
            .alpha(if (dimmed) 0.4f else 1f)

        val click = Modifier.combinedClickable(
            onClick = { tick(); onClick() },
            onLongClick = { longTick(); onLongClick() }
        )

        if (selected) {
            GlassSurface(modifier = dragModifier, shape = shape, tint = primary) {
                Box(click) { TrackRowContent(t, true, playing, cached, pinned, favorite) }
            }
        } else {
            Box(dragModifier.clip(shape).then(click)) {
                TrackRowContent(t, false, playing, cached, pinned, favorite)
            }
        }
    }
}

/** 하단 미니 플레이어: 좌우로 밀면 이전/다음 곡, 위로 밀거나 누르면 전체 플레이어 */
@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    val longTick = rememberLongTick()
    val dx = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val th = with(density) { 70.dp.toPx() }
    val open by rememberUpdatedState(onOpen)

    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { translationX = dx.value }
            .pointerInput(Unit) {
                var ax = 0f
                var ay = 0f
                detectDragGestures(
                    onDragStart = {
                        ax = 0f
                        ay = 0f
                    },
                    onDragEnd = {
                        if (abs(ax) > abs(ay)) {
                            if (ax < -th) { longTick(); vm.next() }
                            else if (ax > th) { longTick(); vm.previous() }
                        } else if (ay < -th) {
                            open()
                        }
                        scope.launch { dx.animateTo(0f) }
                    },
                    onDragCancel = { scope.launch { dx.animateTo(0f) } }
                ) { change, amount ->
                    change.consume()
                    ax += amount.x
                    ay += amount.y
                    if (abs(ax) > abs(ay)) {
                        val target = ax * 0.5f
                        scope.launch { dx.snapTo(target) }
                    }
                }
            },
        shape = RoundedCornerShape(28.dp),
        onClick = onOpen
    ) {
        Column {
            Box(
                Modifier.padding(top = 6.dp).size(width = 32.dp, height = 4.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f))
                    .align(Alignment.CenterHorizontally)
            )
            Row(
                Modifier.padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = vm.nowArt, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(vm.nowTitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(
                        vm.nowArtist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box(contentAlignment = Alignment.Center) {
                    IconButton(onClick = vm::togglePlay) {
                        Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "재생/일시정지")
                    }
                    if (vm.isBuffering) CircularProgressIndicator(Modifier.size(40.dp), strokeWidth = 2.dp)
                }
                IconButton(onClick = vm::next) { Icon(Icons.Default.SkipNext, "다음") }
            }
            LinearProgressIndicator(
                progress = {
                    if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
                },
                trackColor = Color.White.copy(alpha = 0.2f),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 10.dp)
                    .height(3.dp).clip(CircleShape)
            )
        }
    }
}

/** 목록을 불러오는 동안 보여줄 반짝이는 자리표시 줄 */
@Composable
fun SkeletonList(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "skeleton")
    val a by t.animateFloat(
        initialValue = 0.10f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "alpha"
    )
    val c = MaterialTheme.colorScheme.onSurface.copy(alpha = a)
    Column(modifier) {
        repeat(8) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(c))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Box(Modifier.fillMaxWidth(0.7f).height(14.dp).clip(CircleShape).background(c))
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth(0.4f).height(10.dp).clip(CircleShape).background(c))
                }
            }
        }
    }
}

/** 알아듣기 쉬운 오류 카드 + 다시 시도 */
@Composable
fun ErrorCard(message: String, onRetry: (() -> Unit)?, onDismiss: () -> Unit) {
    GlassSurface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        shape = RoundedCornerShape(18.dp),
        tint = MaterialTheme.colorScheme.error
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ErrorOutline, null, tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(10.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            if (onRetry != null) TextButton(onClick = onRetry) { Text("다시 시도") }
            IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "닫기", Modifier.size(18.dp)) }
        }
    }
}

/** 설정 화면의 스위치 한 줄 */
@Composable
fun SwitchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val tick = rememberTick()
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            if (desc != null) {
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = { tick(); onChange(it) })
    }
}

/** 아이콘 + 작은 글씨 버튼 (전체 플레이어 하단 도구) */
@Composable
fun ToolButton(icon: ImageVector, label: String, active: Boolean = false, onClick: () -> Unit) {
    val tick = rememberTick()
    val color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = { tick(); onClick() }) { Icon(icon, label, tint = color) }
        Text(label, style = MaterialTheme.typography.labelSmall, color = color, maxLines = 1)
    }
}
