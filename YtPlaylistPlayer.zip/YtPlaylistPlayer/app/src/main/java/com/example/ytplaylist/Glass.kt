package com.example.ytplaylist

import android.os.Build
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/** 리퀴드 글래스 효과 켜짐 여부 (설정에서 끌 수 있음) */
val LocalGlass = compositionLocalOf { true }

/** 햅틱(진동) 반응 켜짐 여부 */
val LocalHaptics = compositionLocalOf { true }

/** 가벼운 '톡' 진동 */
@Composable
fun rememberTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val on = LocalHaptics.current
    return remember(haptic, on) {
        val f: () -> Unit = { if (on) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
        f
    }
}

/** 조금 더 묵직한 진동 (길게 누르기, 스와이프 완료) */
@Composable
fun rememberLongTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val on = LocalHaptics.current
    return remember(haptic, on) {
        val f: () -> Unit = { if (on) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
        f
    }
}

/**
 * 반투명 유리 질감 패널: 위에서 아래로 옅어지는 흰빛 + 비스듬한 하이라이트 테두리.
 * tint를 주면 그 색이 유리에 물든 느낌으로 표시돼요 (선택된 항목 등).
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    tint: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val glass = LocalGlass.current
    val dark = cs.background.luminance() < 0.5f
    val tick = rememberTick()

    val fill: Brush
    val border: Brush
    if (glass) {
        val topA = when { tint != null -> 0.34f; dark -> 0.16f; else -> 0.62f }
        val botA = when { tint != null -> 0.14f; dark -> 0.06f; else -> 0.34f }
        val base = tint ?: Color.White
        fill = Brush.verticalGradient(listOf(base.copy(alpha = topA), base.copy(alpha = botA)))
        border = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = if (dark) 0.55f else 0.95f),
                Color.White.copy(alpha = 0.08f),
                Color.White.copy(alpha = if (dark) 0.25f else 0.6f)
            )
        )
    } else {
        fill = SolidColor(if (tint != null) cs.primaryContainer else cs.surfaceVariant)
        border = SolidColor(Color.Transparent)
    }

    Box(
        modifier = modifier
            .clip(shape)
            .background(fill)
            .then(if (glass) Modifier.border(1.dp, border, shape) else Modifier)
            .then(if (onClick != null) Modifier.clickable { tick(); onClick() } else Modifier),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** 화면 전체 배경: 테마색 빛 번짐 + 재생 중인 곡 앨범 아트를 흐리게 깔아 유리 뒤가 비치는 느낌 */
@Composable
fun GlassBackground(art: String?) {
    val cs = MaterialTheme.colorScheme
    val glass = LocalGlass.current
    Box(Modifier.fillMaxSize().background(cs.background)) {
        if (!glass) return@Box
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(cs.primary.copy(alpha = 0.40f), Color.Transparent),
                    center = Offset(180f, 260f), radius = 1000f
                )
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(cs.secondary.copy(alpha = 0.30f), Color.Transparent),
                    center = Offset(1000f, 2000f), radius = 1200f
                )
            )
        )
        if (Build.VERSION.SDK_INT >= 31) {
            Crossfade(targetState = art, animationSpec = tween(800), label = "bg") { a ->
                if (a != null) {
                    AsyncImage(
                        model = a,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().blur(56.dp).alpha(0.5f)
                    )
                }
            }
        }
        Box(Modifier.fillMaxSize().background(cs.background.copy(alpha = 0.45f)))
    }
}
