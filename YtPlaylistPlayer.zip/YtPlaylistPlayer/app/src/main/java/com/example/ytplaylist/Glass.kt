@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ytplaylist

import android.os.Build
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.draw.drawBehind
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/** 리퀴드 글래스 효과 켜짐 여부 (설정에서 끌 수 있음) */
val LocalGlass = compositionLocalOf { true }

/** 햅틱(진동) 반응 켜짐 여부 */
val LocalHaptics = compositionLocalOf { true }

/** 가벼운 '톡' 진동 */
@Composable
fun rememberTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val on = LocalHaptics.current
    return remember(haptic, on) {
        val f: () -> Unit = { if (on) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
        f
    }
}

/** 조금 더 묵직한 진동 (길게 누르기, 스와이프 완료) */
@Composable
fun rememberLongTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val on = LocalHaptics.current
    return remember(haptic, on) {
        val f: () -> Unit = { if (on) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
        f
    }
}

/**
 * 반투명 유리 질감 패널.
 * - tint: 그 색이 물든 유리 (선택된 항목 등)
 * - strong: 더 불투명한 판 (목록, 미니 플레이어처럼 배경과 확실히 구분돼야 하는 곳)
 * 색 변화와 눌림 효과는 '그리기' 단계에서만 읽어서, 애니메이션 중에도 화면 구성을 다시 하지 않아요 (프레임 드랍 방지).
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    tint: Color? = null,
    strong: Boolean = false,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    pressScale: Float = 0.95f,
    content: @Composable BoxScope.() -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val glass = LocalGlass.current
    val dark = cs.background.luminance() < 0.5f
    val tick = rememberTick()
    val longTick = rememberLongTick()

    val (top, bot) = when {
        !glass && tint != null -> cs.primaryContainer to cs.primaryContainer
        !glass && strong -> cs.surface to cs.surface
        !glass -> cs.surfaceVariant to cs.surfaceVariant
        tint != null -> tint.copy(alpha = 0.40f) to tint.copy(alpha = 0.22f)
        strong && dark -> cs.surface.copy(alpha = 0.78f) to cs.surface.copy(alpha = 0.66f)
        strong -> Color.White.copy(alpha = 0.86f) to Color.White.copy(alpha = 0.74f)
        dark -> Color.White.copy(alpha = 0.15f) to Color.White.copy(alpha = 0.07f)
        else -> Color.White.copy(alpha = 0.72f) to Color.White.copy(alpha = 0.48f)
    }
    val aTop = animateColorAsState(top, tween(360), label = "glassTop")
    val aBot = animateColorAsState(bot, tween(360), label = "glassBot")

    val border: Brush = remember(glass, dark) {
        if (glass) Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = if (dark) 0.45f else 0.95f),
                Color.White.copy(alpha = if (dark) 0.05f else 0.20f),
                Color.White.copy(alpha = if (dark) 0.20f else 0.60f)
            )
        ) else SolidColor(Color.Transparent)
    }

    val clickable = onClick != null || onLongClick != null
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale = animateFloatAsState(
        targetValue = if (pressed && clickable) pressScale else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 520f),
        label = "press"
    )

    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
            .clip(shape)
            .drawBehind { drawRect(Brush.verticalGradient(listOf(aTop.value, aBot.value))) }
            .then(if (glass) Modifier.border(1.dp, border, shape) else Modifier)
            .then(
                if (clickable) Modifier.combinedClickable(
                    interactionSource = source,
                    indication = LocalIndication.current,
                    onLongClick = onLongClick?.let { f -> { longTick(); f() } },
                    onClick = { tick(); onClick?.invoke() }
                ) else Modifier
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/**
 * 화면 전체 배경: 곡 커버에서 뽑은 색을 안개처럼 번지게 깐 몽환적인 그라데이션.
 * 기본은 검정 위주이고, 색 덩어리 몇 개가 아주 천천히 떠다녀요.
 * 모든 계산은 '그리기' 단계에서만 해서 화면 구성은 다시 하지 않아요.
 */
@Composable
fun GlassBackground(colors: List<Color>, modifier: Modifier = Modifier, deep: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val glass = LocalGlass.current
    val dark = cs.background.luminance() < 0.5f
    val base = if (dark) Color(0xFF050507) else cs.background
    val dream = Color(0xFF7B6CF6) // 살짝 보랏빛을 섞어 몽환적인 느낌
    val c0 = animateColorAsState(colors.getOrElse(0) { cs.primary }, tween(1800), label = "bg0")
    val c1 = animateColorAsState(colors.getOrElse(1) { cs.secondary }, tween(1800), label = "bg1")
    val c2 = animateColorAsState(colors.getOrElse(2) { cs.primary }, tween(1800), label = "bg2")
    val drift = rememberInfiniteTransition(label = "drift")
    val phase = drift.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(9_000, easing = LinearEasing)),
        label = "phase"
    )
    val k = when {
        deep && dark -> 1.35f
        dark -> 1f
        deep -> 0.7f
        else -> 0.55f
    }

    Box(
        modifier.fillMaxSize().drawBehind {
            drawRect(base)
            if (!glass) return@drawBehind
            val w = size.width
            val h = size.height
            val m = size.maxDimension
            val ph = phase.value
            val mono = colors.isNotEmpty() && colors.all { abs(it.red - it.green) < 0.02f && abs(it.green - it.blue) < 0.02f }

            fun blob(color: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
                val a = (alpha * k).coerceIn(0f, 1f)
                drawRect(
                    Brush.radialGradient(
                        0f to color.copy(alpha = a),
                        0.45f to color.copy(alpha = a * 0.38f),
                        1f to Color.Transparent,
                        center = Offset(cx, cy),
                        radius = r
                    )
                )
            }

            val main = c0.value
            val deepC = c1.value
            val soft = if (mono) c2.value else lerp(c2.value, dream, 0.35f)
            val haze = if (mono) lerp(main, Color.White, 0.3f) else lerp(main, Color.White, 0.25f)

            // 떠다니는 색 안개 (화면 위쪽에 모이고, 아래는 검정)
            blob(main, w * (0.22f + 0.14f * sin(ph)), h * (0.14f + 0.08f * cos(ph)), m * 0.62f, 0.42f)
            blob(soft, w * (0.80f + 0.12f * cos(ph * 2f)), h * (0.30f + 0.10f * sin(ph)), m * 0.48f, 0.30f)
            blob(deepC, w * (0.35f + 0.18f * sin(ph + 1f)), h * (0.52f + 0.09f * cos(ph * 2f)), m * 0.50f, 0.22f)
            blob(haze, w * (0.60f + 0.05f * cos(ph + 2f)), h * (0.08f + 0.03f * sin(ph * 2f)), m * 0.32f, 0.16f)

            // 아래로 갈수록 바탕색으로 가라앉아 검정 비중이 커져요
            drawRect(
                Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.45f to base.copy(alpha = 0.35f),
                    1f to base.copy(alpha = if (deep) 0.7f else if (dark) 0.92f else 0.6f)
                )
            )
        }
    )
}
