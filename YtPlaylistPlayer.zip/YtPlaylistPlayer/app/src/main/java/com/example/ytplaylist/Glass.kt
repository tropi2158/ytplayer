@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ytplaylist

import android.os.Build
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/** 리퀴드 글래스 효과 켜짐 여부 (설정에서 끌 수 있음) */
val LocalGlass = compositionLocalOf { true }

/** 햅틱(진동) 반응 켜짐 여부 */
val LocalHaptics = compositionLocalOf { true }

/** 가벼운 '톡' 진동 */
@Composable
fun rememberTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val on = LocalHaptics.current
    return remember(haptic, on) {
        val f: () -> Unit = { if (on) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
        f
    }
}

/** 조금 더 묵직한 진동 (길게 누르기, 스와이프 완료) */
@Composable
fun rememberLongTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val on = LocalHaptics.current
    return remember(haptic, on) {
        val f: () -> Unit = { if (on) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
        f
    }
}

/**
 * 반투명 유리 질감 패널.
 * - tint: 그 색이 물든 유리 (선택된 항목 등)
 * - strong: 더 불투명한 판 (목록, 미니 플레이어처럼 배경과 확실히 구분돼야 하는 곳)
 * 색 변화와 눌림 효과는 '그리기' 단계에서만 읽어서, 애니메이션 중에도 화면 구성을 다시 하지 않아요 (프레임 드랍 방지).
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    tint: Color? = null,
    strong: Boolean = false,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    pressScale: Float = 0.95f,
    content: @Composable BoxScope.() -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val glass = LocalGlass.current
    val dark = cs.background.luminance() < 0.5f
    val tick = rememberTick()
    val longTick = rememberLongTick()

    val (top, bot) = when {
        !glass && tint != null -> cs.primaryContainer to cs.primaryContainer
        !glass && strong -> cs.surface to cs.surface
        !glass -> cs.surfaceVariant to cs.surfaceVariant
        tint != null -> tint.copy(alpha = 0.40f) to tint.copy(alpha = 0.22f)
        strong && dark -> cs.surface.copy(alpha = 0.78f) to cs.surface.copy(alpha = 0.66f)
        strong -> Color.White.copy(alpha = 0.86f) to Color.White.copy(alpha = 0.74f)
        dark -> Color.White.copy(alpha = 0.15f) to Color.White.copy(alpha = 0.07f)
        else -> Color.White.copy(alpha = 0.72f) to Color.White.copy(alpha = 0.48f)
    }
    val aTop = animateColorAsState(top, tween(360), label = "glassTop")
    val aBot = animateColorAsState(bot, tween(360), label = "glassBot")

    val border: Brush = remember(glass, dark) {
        if (glass) Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = if (dark) 0.45f else 0.95f),
                Color.White.copy(alpha = if (dark) 0.05f else 0.20f),
                Color.White.copy(alpha = if (dark) 0.20f else 0.60f)
            )
        ) else SolidColor(Color.Transparent)
    }

    val clickable = onClick != null || onLongClick != null
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale = animateFloatAsState(
        targetValue = if (pressed && clickable) pressScale else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 520f),
        label = "press"
    )

    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
            .clip(shape)
            .drawBehind { drawRect(Brush.verticalGradient(listOf(aTop.value, aBot.value))) }
            .then(if (glass) Modifier.border(1.dp, border, shape) else Modifier)
            .then(
                if (clickable) Modifier.combinedClickable(
                    interactionSource = source,
                    indication = LocalIndication.current,
                    onLongClick = onLongClick?.let { f -> { longTick(); f() } },
                    onClick = { tick(); onClick?.invoke() }
                ) else Modifier
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/**
 * 화면 전체 배경: 재생 중인 곡 커버에서 뽑은 색으로 만든 그라데이션.
 * 이미지 블러를 쓰지 않아 가볍고, 곡이 바뀌면 색만 천천히 번져가요.
 */
@Composable
fun GlassBackground(colors: List<Color>, modifier: Modifier = Modifier, deep: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val glass = LocalGlass.current
    val dark = cs.background.luminance() < 0.5f
    val base = cs.background
    val c0 = animateColorAsState(colors.getOrElse(0) { cs.primary }, tween(1400), label = "bg0")
    val c1 = animateColorAsState(colors.getOrElse(1) { cs.secondary }, tween(1400), label = "bg1")
    val c2 = animateColorAsState(colors.getOrElse(2) { cs.primary }, tween(1400), label = "bg2")
    val k = when {
        deep && dark -> 0.85f
        deep -> 0.55f
        dark -> 0.62f
        else -> 0.42f
    }
    Box(
        modifier.fillMaxSize().drawBehind {
            drawRect(base)
            if (!glass) return@drawBehind
            // 위에서 아래로: 커버의 대표색 -> 어두운 색 -> 바탕
            drawRect(
                Brush.verticalGradient(
                    0f to c0.value.copy(alpha = k),
                    0.55f to c1.value.copy(alpha = k * 0.75f),
                    1f to base.copy(alpha = 0f)
                )
            )
            // 왼쪽 위, 오른쪽 아래에 은은한 빛 번짐
            drawRect(
                Brush.radialGradient(
                    listOf(c2.value.copy(alpha = k * 0.55f), Color.Transparent),
                    center = Offset(size.width * 0.15f, size.height * 0.12f),
                    radius = size.maxDimension * 0.55f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(c0.value.copy(alpha = k * 0.35f), Color.Transparent),
                    center = Offset(size.width * 0.95f, size.height * 0.85f),
                    radius = size.maxDimension * 0.6f
                )
            )
            // 글자가 잘 보이도록 얇은 막
            drawRect(base.copy(alpha = if (dark) 0.18f else 0.22f))
        }
    )
}
