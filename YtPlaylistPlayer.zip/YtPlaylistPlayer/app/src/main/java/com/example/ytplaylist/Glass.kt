@file:OptIn(ExperimentalFoundationApi::class)

package com.example.ytplaylist

import android.graphics.RuntimeShader
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.addOutline
import androidx.compose.ui.graphics.drawscope.clipPath
import android.graphics.Shader
import android.os.Build
import android.view.View
import androidx.annotation.RequiresApi
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntSize
import kotlin.math.ceil
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.draw.drawBehind
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/** 리퀴드 글래스 효과 켜짐 여부 (설정에서 끌 수 있음) */
val LocalGlass = compositionLocalOf { true }

/** 햅틱(진동) 반응 켜짐 여부 */
val LocalHaptics = compositionLocalOf { true }

/** 가벼운 '톡' 진동 */
@Composable
fun rememberTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val on = LocalHaptics.current
    return remember(haptic, on) {
        val f: () -> Unit = { if (on) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
        f
    }
}

/** 조금 더 묵직한 진동 (길게 누르기, 스와이프 완료) */
@Composable
fun rememberLongTick(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    val on = LocalHaptics.current
    return remember(haptic, on) {
        val f: () -> Unit = { if (on) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
        f
    }
}

// ======================= 리퀴드 글래스 엔진 =======================
//
// 1) 배경(또는 화면 내용)을 GraphicsLayer 에 기록해 두고 (backdropSource)
// 2) 각 유리 조각이 자기 뒤에 있는 부분만 가져와서
// 3) AGSL 셰이더로 가장자리 굴절(렌즈) + 색 번짐(분산) + 채도 강화 + 테두리 반사광을 입혀요.
// Android 13(API 33) 이상에서만 동작하고, 그 아래나 '글래스 끔'일 땐 예전 반투명 판으로 그려요.

/** 유리 조각들이 굴절시킬 '뒤 화면'. detailed = 글자/사진처럼 세밀한 내용이 있어 살짝 흐림이 필요한지 */
class Backdrop internal constructor(val layer: GraphicsLayer, val view: View, val detailed: Boolean) {
    var origin by mutableStateOf(Offset.Zero)
}

val LocalBackdrop = compositionLocalOf<Backdrop?> { null }

@Composable
fun rememberBackdrop(detailed: Boolean = false): Backdrop {
    val layer = rememberGraphicsLayer()
    val view = LocalView.current
    return remember(layer, view, detailed) { Backdrop(layer, view, detailed) }
}

/** 이 요소가 그리는 내용을 backdrop 으로 기록하면서 화면에도 그대로 그려요 */
fun Modifier.backdropSource(b: Backdrop): Modifier = this
    .onGloballyPositioned { b.origin = it.positionInWindow() }
    .drawWithContent {
        b.layer.record { this@drawWithContent.drawContent() }
        drawLayer(b.layer)
    }

private const val LIQUID_SRC = """
uniform shader content;
uniform float2 uSize;
uniform float2 uPad;
uniform float uRadius;
uniform float uRefH;
uniform float uRefAmt;
uniform float uDisp;
uniform float4 uTint;
uniform float uSat;
uniform float uBright;
uniform float uHl;
uniform float uRim;

float sdRR(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0))) - r;
}

half4 main(float2 fc) {
    float2 hs = uSize * 0.5;
    float2 p = fc - uPad - hs;
    float r = min(uRadius, min(hs.x, hs.y));
    float sd = sdRR(p, hs, r);
    if (sd > 1.0) return half4(0.0);

    float ex = 0.75;
    float2 g = float2(
        sdRR(p + float2(ex, 0.0), hs, r) - sdRR(p - float2(ex, 0.0), hs, r),
        sdRR(p + float2(0.0, ex), hs, r) - sdRR(p - float2(0.0, ex), hs, r));
    float gl = length(g);
    float2 n = gl > 0.0001 ? g / gl : float2(0.0);

    // 가장자리로 갈수록 둥근 유리처럼 급하게 휘어져요 (원형 단면)
    float refH = max(min(uRefH, min(hs.x, hs.y) * 0.5), 1.0);
    float t = 1.0 - clamp(-sd / refH, 0.0, 1.0);
    float bend = 1.0 - sqrt(max(1.0 - t * t, 0.0));
    float2 d = n * bend * uRefAmt;

    float4 cg = float4(content.eval(fc + d));
    float cr = float4(content.eval(fc + d * (1.0 + uDisp))).r;
    float cb = float4(content.eval(fc + d * (1.0 - uDisp))).b;
    float a0 = cg.a;
    float3 col = float3(cr, cg.g, cb);
    if (a0 > 0.001) col = col / a0;

    // 채도/밝기 살짝 올리기 (유리 너머가 더 선명해 보이게)
    float lum = dot(col, float3(0.2126, 0.7152, 0.0722));
    col = mix(float3(lum), col, uSat) * uBright;
    col = mix(col, uTint.rgb, uTint.a);

    // 빛 반사: 왼쪽 위와 오른쪽 아래 모서리에서 가장 밝게
    float2 L = normalize(float2(-1.0, -1.2));
    float facing = abs(dot(n, L));
    float spec = facing * facing;
    float edge = 1.0 - smoothstep(0.0, uRim, -sd);
    col += uHl * edge * (0.15 + 0.85 * spec);
    col += uHl * 0.12 * bend * bend * spec;

    float aa = clamp(0.5 - sd, 0.0, 1.0);
    float a = aa * max(a0, uTint.a);
    col = clamp(col, 0.0, 1.0);
    return half4(half3(col * a), half(a));
}
"""

/** 이 기기에서 셰이더가 정상적으로 만들어지는지 한 번만 확인 (실패하면 예전 유리로) */
private val liquidSupported: Boolean by lazy {
    Build.VERSION.SDK_INT >= 33 && runCatching { RuntimeShader(LIQUID_SRC) }.isSuccess
}

/** 셰이더 하나를 재사용하면서, 값이 바뀔 때만 효과를 다시 만들어요 */
@RequiresApi(33)
private class LiquidFx {
    private val shader = RuntimeShader(LIQUID_SRC)
    private var key: List<Float> = emptyList()
    private var effect: androidx.compose.ui.graphics.RenderEffect? = null

    fun get(
        w: Float, h: Float, pad: Float, radius: Float, refH: Float, refAmt: Float, disp: Float,
        tint: Color, tintA: Float, sat: Float, bright: Float, hl: Float, rim: Float, blur: Float
    ): androidx.compose.ui.graphics.RenderEffect {
        val k = listOf(w, h, pad, radius, refH, refAmt, disp, tint.red, tint.green, tint.blue, tintA, sat, bright, hl, rim, blur)
        effect?.let { if (k == key) return it }
        key = k
        shader.setFloatUniform("uSize", w, h)
        shader.setFloatUniform("uPad", pad, pad)
        shader.setFloatUniform("uRadius", radius)
        shader.setFloatUniform("uRefH", refH)
        shader.setFloatUniform("uRefAmt", refAmt)
        shader.setFloatUniform("uDisp", disp)
        shader.setFloatUniform("uTint", tint.red, tint.green, tint.blue, tintA)
        shader.setFloatUniform("uSat", sat)
        shader.setFloatUniform("uBright", bright)
        shader.setFloatUniform("uHl", hl)
        shader.setFloatUniform("uRim", rim)
        val lens = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "content")
        val e = if (blur > 0.5f) android.graphics.RenderEffect.createChainEffect(
            lens, android.graphics.RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP)
        ) else lens
        return e.asComposeRenderEffect().also { effect = it }
    }
}

/**
 * 리퀴드 글래스 패널.
 * - tint: 그 색이 물든 유리 (선택된 항목 등)
 * - strong: 더 불투명한 판 (목록, 미니 플레이어처럼 배경과 확실히 구분돼야 하는 곳)
 * 색 변화와 눌림 효과는 '그리기' 단계에서만 읽어서, 애니메이션 중에도 화면 구성을 다시 하지 않아요.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    tint: Color? = null,
    strong: Boolean = false,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    pressScale: Float = 0.95f,
    content: @Composable BoxScope.() -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val glass = LocalGlass.current
    val dark = cs.background.luminance() < 0.5f
    val tick = rememberTick()
    val longTick = rememberLongTick()
    val view = LocalView.current
    val density = LocalDensity.current
    val backdrop = LocalBackdrop.current
    val liquid = Build.VERSION.SDK_INT >= 33 && glass && liquidSupported && backdrop != null &&
        backdrop.view === view && shape is CornerBasedShape

    val clickable = onClick != null || onLongClick != null
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale = animateFloatAsState(
        targetValue = if (pressed && clickable) pressScale else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 520f),
        label = "press"
    )
    val clickMod = if (clickable) Modifier.combinedClickable(
        interactionSource = source,
        indication = LocalIndication.current,
        onLongClick = onLongClick?.let { f -> { longTick(); f() } },
        onClick = { tick(); onClick?.invoke() }
    ) else Modifier
    val pressMod = Modifier.graphicsLayer {
        scaleX = scale.value
        scaleY = scale.value
    }

    if (liquid && Build.VERSION.SDK_INT >= 33) {
        val bd = backdrop!!
        // 유리 색 (얼마나 물들지)
        val (tc, ta) = when {
            tint != null -> tint to (if (dark) 0.30f else 0.26f)
            strong && dark -> Color.Black to 0.38f
            strong -> Color.White to 0.55f
            dark -> Color.White to 0.07f
            else -> Color.White to 0.28f
        }
        val aTint = animateColorAsState(tc.copy(alpha = ta), tween(360), label = "glassTint")
        val selfLayer = rememberGraphicsLayer()
        val self = remember(selfLayer, view) { Backdrop(selfLayer, view, false) }
        val pos = remember { mutableStateOf(Offset.Zero) }
        val fx = remember { LiquidFx() }
        val refAmt = with(density) { (if (strong) 8.dp else 11.dp).toPx() }
        val refH = with(density) { (if (strong) 12.dp else 14.dp).toPx() }
        val blur = with(density) {
            when {
                !bd.detailed -> 0f
                strong -> 12.dp.toPx()
                else -> 4.dp.toPx()
            }
        }
        val pad = refAmt * 1.6f + blur * 2.5f + with(density) { 2.dp.toPx() }
        val rim = with(density) { 1.4.dp.toPx() }
        val hl = if (dark) (if (strong) 0.42f else 0.6f) else 0.7f
        val sat = if (strong) 1.12f else 1.25f
        val bright = if (dark) 1.05f else 1.06f

        Box(
            modifier = modifier
                .then(pressMod)
                .onGloballyPositioned {
                    val p = it.positionInWindow()
                    pos.value = p
                    self.origin = p - Offset(pad, pad)
                }
                .clip(shape)
                .drawBehind {
                    val w = size.width
                    val h = size.height
                    if (w < 1f || h < 1f) return@drawBehind
                    // 실제 모양(원, 둥근 사각형)을 그대로 따라가도록 윤곽선에서 반지름과 자르기 경로를 가져와요
                    val outline = shape.createOutline(size, layoutDirection, this)
                    val radius = when (outline) {
                        is Outline.Rounded -> outline.roundRect.topLeftCornerRadius.x
                        is Outline.Rectangle -> 0f
                        else -> minOf(w, h) / 2f
                    }
                    val clipShape = Path().apply { addOutline(outline) }
                    val o = bd.origin - pos.value
                    selfLayer.record(IntSize(ceil(w + pad * 2).toInt(), ceil(h + pad * 2).toInt())) {
                        translate(o.x + pad, o.y + pad) { drawLayer(bd.layer) }
                    }
                    val t = aTint.value
                    val eff = runCatching {
                        fx.get(
                            w, h, pad, radius, refH, refAmt, 0.06f,
                            t.copy(alpha = 1f), t.alpha, sat, bright, hl, rim, blur
                        )
                    }.getOrNull()
                    if (eff == null) {
                        drawRect(t.copy(alpha = (t.alpha + 0.12f).coerceAtMost(0.9f)))
                        return@drawBehind
                    }
                    selfLayer.renderEffect = eff
                    clipPath(clipShape) { translate(-pad, -pad) { drawLayer(selfLayer) } }
                }
                .then(clickMod),
            contentAlignment = Alignment.Center
        ) {
            val scope = this
            CompositionLocalProvider(LocalBackdrop provides self) { scope.content() }
        }
        return
    }

    // ----- 예전 방식 (Android 12 이하, 글래스 끔, 다른 창(시트) 안) -----
    val (top, bot) = when {
        !glass && tint != null -> cs.primaryContainer to cs.primaryContainer
        !glass && strong -> cs.surface to cs.surface
        !glass -> cs.surfaceVariant to cs.surfaceVariant
        tint != null -> tint.copy(alpha = 0.40f) to tint.copy(alpha = 0.22f)
        strong && dark -> cs.surface.copy(alpha = 0.78f) to cs.surface.copy(alpha = 0.66f)
        strong -> Color.White.copy(alpha = 0.86f) to Color.White.copy(alpha = 0.74f)
        dark -> Color.White.copy(alpha = 0.15f) to Color.White.copy(alpha = 0.07f)
        else -> Color.White.copy(alpha = 0.72f) to Color.White.copy(alpha = 0.48f)
    }
    val aTop = animateColorAsState(top, tween(360), label = "glassTop")
    val aBot = animateColorAsState(bot, tween(360), label = "glassBot")
    val border: Brush = remember(glass, dark) {
        if (glass) Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = if (dark) 0.16f else 0.55f),
                Color.White.copy(alpha = if (dark) 0.02f else 0.08f),
                Color.White.copy(alpha = 0f)
            )
        ) else SolidColor(Color.Transparent)
    }

    Box(
        modifier = modifier
            .then(pressMod)
            .clip(shape)
            .drawBehind { drawRect(Brush.verticalGradient(listOf(aTop.value, aBot.value))) }
            .then(if (glass) Modifier.border(0.7.dp, border, shape) else Modifier)
            .then(clickMod),
        contentAlignment = Alignment.Center
    ) {
        val scope = this
        CompositionLocalProvider(LocalBackdrop provides null) { scope.content() }
    }
}

/**
 * 화면 전체 배경: 곡 커버에서 뽑은 색을 안개처럼 번지게 깐 몽환적인 그라데이션.
 * 기본은 검정 위주이고, 색 덩어리 몇 개가 아주 천천히 떠다녀요.
 * 모든 계산은 '그리기' 단계에서만 해서 화면 구성은 다시 하지 않아요.
 */
@Composable
fun GlassBackground(colors: List<Color>, modifier: Modifier = Modifier, deep: Boolean = false, art: String? = null) {
    if (LocalGlass.current && art != null) {
        ArtBackground(art, modifier, deep)
        return
    }
    val cs = MaterialTheme.colorScheme
    val glass = LocalGlass.current
    val dark = cs.background.luminance() < 0.5f
    val base = if (dark) Color(0xFF050507) else cs.background
    val dream = Color(0xFF7B6CF6) // 살짝 보랏빛을 섞어 몽환적인 느낌
    val c0 = animateColorAsState(colors.getOrElse(0) { cs.primary }, tween(1800), label = "bg0")
    val c1 = animateColorAsState(colors.getOrElse(1) { cs.secondary }, tween(1800), label = "bg1")
    val c2 = animateColorAsState(colors.getOrElse(2) { cs.primary }, tween(1800), label = "bg2")
    val drift = rememberInfiniteTransition(label = "drift")
    val phase = drift.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(9_000, easing = LinearEasing)),
        label = "phase"
    )
    val k = when {
        deep && dark -> 0.95f
        dark -> 0.62f
        deep -> 0.55f
        else -> 0.42f
    }

    Box(
        modifier.fillMaxSize().drawBehind {
            drawRect(base)
            if (!glass) return@drawBehind
            val w = size.width
            val h = size.height
            val m = size.maxDimension
            val ph = phase.value
            val mono = colors.isNotEmpty() && colors.all { abs(it.red - it.green) < 0.02f && abs(it.green - it.blue) < 0.02f }

            fun blob(color: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
                val a = (alpha * k).coerceIn(0f, 1f)
                drawRect(
                    Brush.radialGradient(
                        0f to color.copy(alpha = a),
                        0.45f to color.copy(alpha = a * 0.38f),
                        1f to Color.Transparent,
                        center = Offset(cx, cy),
                        radius = r
                    )
                )
            }

            val main = c0.value
            val deepC = c1.value
            val soft = if (mono) c2.value else lerp(c2.value, dream, 0.35f)
            val haze = if (mono) lerp(main, Color.White, 0.3f) else lerp(main, Color.White, 0.25f)

            // 떠다니는 색 안개 (화면 위쪽에 모이고, 아래는 검정)
            blob(main, w * (0.22f + 0.14f * sin(ph)), h * (0.14f + 0.08f * cos(ph)), m * 0.62f, 0.42f)
            blob(soft, w * (0.80f + 0.12f * cos(ph * 2f)), h * (0.30f + 0.10f * sin(ph)), m * 0.48f, 0.30f)
            blob(deepC, w * (0.35f + 0.18f * sin(ph + 1f)), h * (0.52f + 0.09f * cos(ph * 2f)), m * 0.50f, 0.22f)
            blob(haze, w * (0.60f + 0.05f * cos(ph + 2f)), h * (0.08f + 0.03f * sin(ph * 2f)), m * 0.32f, 0.16f)

            // 아래로 갈수록 바탕색으로 가라앉아 검정 비중이 커져요
            drawRect(
                Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.4f to base.copy(alpha = if (dark) 0.5f else 0.35f),
                    1f to base.copy(alpha = if (deep) 0.82f else if (dark) 0.97f else 0.6f)
                )
            )
            // 전체를 한 번 더 살짝 눌러 어둡게
            if (dark) drawRect(Color.Black.copy(alpha = if (deep) 0.18f else 0.25f))
        }
    )
}


/**
 * 지금 재생 중인 곡의 썸네일을 화면 가득 깐 배경.
 * 아주 천천히 떠다니고(9초 주기), 곡이 바뀌면 부드럽게 겹쳐 바뀌어요.
 * 글자가 잘 보이도록 위는 살짝, 아래로 갈수록 진하게 어둡게 눌러요.
 */
@Composable
private fun ArtBackground(art: String, modifier: Modifier, deep: Boolean) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val base = if (dark) Color(0xFF050507) else cs.background
    val drift = rememberInfiniteTransition(label = "artDrift")
    val phase = drift.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(9_000, easing = LinearEasing)),
        label = "artPhase"
    )
    Box(modifier.fillMaxSize().drawBehind { drawRect(base) }) {
        Crossfade(targetState = art, animationSpec = tween(900), label = "artBg") { url ->
            val ctx = androidx.compose.ui.platform.LocalContext.current
            val req = remember(url) {
                // 일부러 작게 받아서 크게 늘리면 자연스럽게 흐려지고 가벼워요
                coil.request.ImageRequest.Builder(ctx).data(url).size(120).build()
            }
            AsyncImage(
                model = req,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                colorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                    androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(0.85f) }
                ),
                modifier = Modifier
                    .fillMaxSize()
                    .blur(48.dp, androidx.compose.ui.draw.BlurredEdgeTreatment.Rectangle)
                    .graphicsLayer {
                        // 유튜브 썸네일의 검은 띠가 안 보이게 넉넉히 확대 + 천천히 떠다니기
                        val ph = phase.value
                        val sc = 1.3f + 0.04f * sin(ph)
                        scaleX = sc
                        scaleY = sc
                        translationX = size.width * 0.035f * cos(ph)
                        translationY = size.height * 0.02f * sin(ph * 2f)
                    }
            )
        }
        Box(
            Modifier.fillMaxSize().drawBehind {
                if (dark) {
                    drawRect(
                        Brush.verticalGradient(
                            0f to Color.Black.copy(alpha = if (deep) 0.52f else 0.42f),
                            0.45f to Color.Black.copy(alpha = if (deep) 0.62f else 0.58f),
                            1f to Color.Black.copy(alpha = if (deep) 0.85f else 0.86f)
                        )
                    )
                } else {
                    drawRect(
                        Brush.verticalGradient(
                            0f to base.copy(alpha = 0.25f),
                            1f to base.copy(alpha = 0.6f)
                        )
                    )
                }
            }
        )
    }
}
