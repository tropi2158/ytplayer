package com.example.ytplaylist

import android.app.Application
import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("yt", Context.MODE_PRIVATE)

    var url by mutableStateOf(prefs.getString("url", "") ?: "")
    var title by mutableStateOf("")
    var tracks by mutableStateOf<List<Track>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    var currentIndex by mutableIntStateOf(-1)
    var isPlaying by mutableStateOf(false)
    var shuffle by mutableStateOf(false)
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_ALL)
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)

    private var controller: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            sync(c)
        }, ContextCompat.getMainExecutor(app))

        if (url.isNotBlank()) load()
    }

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        currentIndex = if (p.mediaItemCount > 0) p.currentMediaItemIndex else -1
        durationMs = p.duration.takeIf { it != C.TIME_UNSET } ?: 0L
    }

    fun refreshPosition() {
        controller?.let { positionMs = it.currentPosition }
    }

    fun load() {
        val u = url.trim()
        if (u.isEmpty()) return
        loading = true
        error = null
        viewModelScope.launch {
            try {
                val (name, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(u) }
                title = name
                tracks = list
                prefs.edit().putString("url", u).apply()
            } catch (e: Exception) {
                error = "불러오기 실패: ${e.message ?: e.javaClass.simpleName}"
            }
            loading = false
        }
    }

    /** 같은 큐가 이미 로드돼 있으면 이동만, 아니면 큐를 새로 세팅 */
    fun playFrom(index: Int) {
        val c = controller ?: return
        if (tracks.isEmpty()) return
        val sameQueue = c.mediaItemCount == tracks.size &&
            (0 until c.mediaItemCount).all { c.getMediaItemAt(it).mediaId == tracks[it].url }
        if (sameQueue) c.seekTo(index, 0L)
        else c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms) }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
