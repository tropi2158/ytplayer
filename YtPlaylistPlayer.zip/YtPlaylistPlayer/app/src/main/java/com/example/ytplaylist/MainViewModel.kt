package com.example.ytplaylist

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

/** 재생 대기열 한 줄 (index = 플레이어 안의 실제 위치) */
data class QueueEntry(
    val index: Int,
    val mediaId: String,
    val title: String,
    val artist: String,
    val art: String?
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("yt", Context.MODE_PRIVATE)

    // ================= 플레이리스트 =================
    var playlists by mutableStateOf(withFav(Store.load(prefs)))
        private set
    var selectedId by mutableStateOf(prefs.getString("selected", "") ?: "")
        private set
    val current: Playlist?
        get() = playlists.firstOrNull { it.id == selectedId }
            ?: playlists.firstOrNull { it.id != FAV_ID }
            ?: playlists.firstOrNull()
    val tracks: List<Track> get() = current?.tracks ?: emptyList()
    val hasUserPlaylists: Boolean get() = playlists.any { it.id != FAV_ID }

    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var retry by mutableStateOf<(() -> Unit)?>(null)
        private set

    private val _toasts = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toasts = _toasts.asSharedFlow()
    private fun toast(m: String) { _toasts.tryEmit(m) }

    // ================= 재생 상태 =================
    var currentIndex by mutableIntStateOf(-1)
        private set
    var playingPid by mutableStateOf("")
        private set
    var playingUrl by mutableStateOf("")
        private set
    var nowTitle by mutableStateOf("")
        private set
    var nowArtist by mutableStateOf("")
        private set
    var nowArt by mutableStateOf<String?>(null)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var isBuffering by mutableStateOf(false)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_ALL)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    var speed by mutableFloatStateOf(prefs.getFloat("speed", 1f))
        private set
    var queue by mutableStateOf<List<QueueEntry>>(emptyList())
        private set
    var artColor by mutableStateOf<Color?>(null)
        private set

    // ================= 저장 공간 =================
    var cachedUrls by mutableStateOf<Set<String>>(emptySet())
        private set
    var pinnedUrls by mutableStateOf<Set<String>>(emptySet())
        private set
    var cacheBytes by mutableLongStateOf(0L)
        private set
    var pinnedBytes by mutableLongStateOf(0L)
        private set

    // ================= 네트워크 =================
    var online by mutableStateOf(true)
        private set
    private val cm = app.getSystemService(ConnectivityManager::class.java)
    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            viewModelScope.launch { online = true }
        }

        override fun onLost(network: Network) {
            viewModelScope.launch { online = checkOnline() }
        }
    }

    // ================= 설정 =================
    var themeMode by mutableIntStateOf(prefs.getInt("theme_mode", 0)) // 0 시스템 1 라이트 2 다크 3 시간 예약
        private set
    var nightStart by mutableIntStateOf(prefs.getInt("night_start", 21))
        private set
    var nightEnd by mutableIntStateOf(prefs.getInt("night_end", 7))
        private set
    var accent by mutableIntStateOf(prefs.getInt("accent", 0))
        private set
    var dynamicColor by mutableStateOf(prefs.getBoolean("dynamic", false))
        private set
    var glass by mutableStateOf(prefs.getBoolean("glass", true))
        private set
    var useArtColor by mutableStateOf(prefs.getBoolean("art_color", true))
        private set
    var haptics by mutableStateOf(prefs.getBoolean("haptics", true))
        private set
    var fontScale by mutableFloatStateOf(prefs.getFloat("font_scale", 1f))
        private set
    var oneHand by mutableStateOf(prefs.getBoolean("one_hand", false))
        private set
    var resumeEnabled by mutableStateOf(prefs.getBoolean("resume", true))
        private set
    var prefetch by mutableStateOf(prefs.getBoolean("prefetch", true))
        private set
    var prefetchWifi by mutableStateOf(prefs.getBoolean("prefetch_wifi", false))
        private set
    var cacheMb by mutableIntStateOf(prefs.getInt("cache_mb", CacheProvider.DEFAULT_MB))
        private set
    var onboarded by mutableStateOf(prefs.getBoolean("onboarded", false))
        private set

    private var controller: MediaController? = null
    private var colorJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player, events)
    }

    init {
        if (playlists.none { it.id == selectedId }) {
            selectedId = (playlists.firstOrNull { it.id != FAV_ID } ?: playlists.first()).id
        }
        persist()

        online = checkOnline()
        runCatching { cm?.registerDefaultNetworkCallback(netCb) }

        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(listener)
            if (c.mediaItemCount == 0) {
                if (speed != 1f) c.setPlaybackSpeed(speed)
                if (resumeEnabled) restoreSession(c)
            }
            sync(c, null)
        }, ContextCompat.getMainExecutor(app))

        current?.let { if (it.url.isNotBlank() && online) refreshPlaylist(it.id, quiet = true) }
    }

    private fun withFav(list: List<Playlist>): List<Playlist> =
        if (list.any { it.id == FAV_ID }) list
        else listOf(Playlist(FAV_ID, "좋아요", "", emptyList())) + list

    private fun checkOnline(): Boolean {
        val c = cm ?: return true
        val n = c.activeNetwork ?: return false
        val caps = c.getNetworkCapabilities(n) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun sync(p: Player, events: Player.Events?) {
        isPlaying = p.isPlaying
        isBuffering = p.playbackState == Player.STATE_BUFFERING
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        currentIndex = if (p.mediaItemCount > 0) p.currentMediaItemIndex else -1
        durationMs = p.duration.takeIf { it != C.TIME_UNSET } ?: 0L
        speed = p.playbackParameters.speed
        val id = p.currentMediaItem?.mediaId ?: ""
        playingPid = pidOf(id)
        playingUrl = if (id.isEmpty()) "" else urlOf(id)
        val md = p.mediaMetadata
        nowTitle = md.title?.toString() ?: ""
        nowArtist = md.artist?.toString() ?: ""
        val art = md.artworkUri?.toString()
        if (art != nowArt) {
            nowArt = art
            extractColor(art)
        }
        if (events == null ||
            events.contains(Player.EVENT_TIMELINE_CHANGED) ||
            events.contains(Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED)
        ) rebuildQueue(p)
    }

    private fun rebuildQueue(p: Player) {
        val n = p.mediaItemCount
        val order = ArrayList<Int>(n)
        val tl = p.currentTimeline
        if (p.shuffleModeEnabled && n > 0 && tl.windowCount == n) {
            var i = tl.getFirstWindowIndex(true)
            while (i != C.INDEX_UNSET && order.size < n) {
                order.add(i)
                i = tl.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, true)
            }
        }
        if (order.size != n) {
            order.clear()
            for (i in 0 until n) order.add(i)
        }
        queue = order.map { i ->
            val item = p.getMediaItemAt(i)
            QueueEntry(
                index = i,
                mediaId = item.mediaId,
                title = item.mediaMetadata.title?.toString() ?: "",
                artist = item.mediaMetadata.artist?.toString() ?: "",
                art = item.mediaMetadata.artworkUri?.toString()
            )
        }
    }

    /** 앨범 아트에서 대표 색을 뽑아 테마에 반영 */
    private fun extractColor(url: String?) {
        colorJob?.cancel()
        if (url == null) {
            artColor = null
            return
        }
        val ctx = getApplication<Application>()
        colorJob = viewModelScope.launch {
            val rgb: Int? = withContext(Dispatchers.IO) {
                try {
                    val req = ImageRequest.Builder(ctx).data(url).allowHardware(false).size(128).build()
                    val bmp = (ctx.imageLoader.execute(req).drawable as? BitmapDrawable)?.bitmap
                    if (bmp == null) null
                    else {
                        val pal = Palette.from(bmp).generate()
                        (pal.vibrantSwatch ?: pal.dominantSwatch)?.rgb
                    }
                } catch (e: Exception) {
                    null
                }
            }
            artColor = rgb?.let { Color(it) }
        }
    }

    fun refreshPosition() {
        controller?.let { positionMs = it.currentPosition }
    }

    private fun restoreSession(c: MediaController) {
        val pid = prefs.getString("resume_pid", null) ?: return
        val url = prefs.getString("resume_url", null)
        val pos = prefs.getLong("resume_pos", 0L)
        val pl = playlists.firstOrNull { it.id == pid } ?: return
        if (pl.tracks.isEmpty()) return
        val idx = pl.tracks.indexOfFirst { it.url == url }
        c.setMediaItems(pl.tracks.map { it.toMediaItem(pl.id) }, idx.coerceAtLeast(0), if (idx >= 0) pos else 0L)
        c.prepare()
    }

    // ================= 오류 =================
    private fun showError(msg: String, r: (() -> Unit)? = null) {
        error = msg
        retry = r
    }

    fun clearError() {
        error = null
        retry = null
    }

    // ================= 플레이리스트 관리 =================
    private fun persist() {
        Store.save(prefs, playlists)
        prefs.edit().putString("selected", selectedId).apply()
    }

    private fun updatePlaylists(list: List<Playlist>) {
        playlists = withFav(list)
        persist()
    }

    fun select(id: String) {
        selectedId = id
        clearError()
        persist()
    }

    fun isFavorite(url: String): Boolean =
        url.isNotEmpty() && playlists.firstOrNull { it.id == FAV_ID }?.tracks?.any { it.url == url } == true

    fun handleSharedText(text: String) {
        val u = extractUrl(text)
        if (u != null && listIdOf(u) != null) addPlaylist(u)
        else toast("유튜브 플레이리스트 링크만 추가할 수 있어요")
    }

    fun addPlaylist(raw: String) {
        val found = extractUrl(raw) ?: raw.trim()
        if (found.isEmpty()) return
        val lid = listIdOf(found)
        val u = if (lid != null) "https://www.youtube.com/playlist?list=$lid" else found
        playlists.firstOrNull { it.url.isNotBlank() && (it.url == u || (lid != null && listIdOf(it.url) == lid)) }
            ?.let {
                select(it.id)
                toast("이미 추가된 플레이리스트예요")
                return
            }
        loading = true
        clearError()
        viewModelScope.launch {
            try {
                val (name, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(u) }
                val p = Playlist(
                    id = Store.newId(),
                    name = name.ifBlank { "플레이리스트 ${playlists.size}" },
                    url = u,
                    tracks = list
                )
                updatePlaylists(playlists + p)
                select(p.id)
                toast("'${p.name}'을(를) 추가했어요")
            } catch (e: Exception) {
                showError("추가하지 못했어요. " + friendlyError(e)) { addPlaylist(u) }
            }
            loading = false
        }
    }

    fun createLocalPlaylist(name: String, first: Track? = null): String {
        val p = Playlist(Store.newId(), name.trim().ifBlank { "새 플레이리스트" }, "", listOfNotNull(first))
        updatePlaylists(playlists + p)
        return p.id
    }

    fun refreshPlaylist(id: String = selectedId, quiet: Boolean = false) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        if (p.url.isBlank()) return
        loading = true
        if (!quiet) clearError()
        viewModelScope.launch {
            try {
                val (_, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(p.url) }
                updatePlaylists(playlists.map { if (it.id == id) it.copy(tracks = list) else it })
                if (!quiet) toast("목록을 새로 불러왔어요")
            } catch (e: Exception) {
                if (!(quiet && p.tracks.isNotEmpty())) {
                    showError(friendlyError(e)) { refreshPlaylist(id) }
                }
            }
            loading = false
        }
    }

    fun renamePlaylist(id: String, name: String) {
        updatePlaylists(playlists.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it })
    }

    fun deletePlaylist(id: String) {
        if (id == FAV_ID) return
        PinnedDownloader.cancel(id)
        updatePlaylists(playlists.filterNot { it.id == id })
        if (selectedId == id) select((playlists.firstOrNull { it.id != FAV_ID } ?: playlists.first()).id)
    }

    /** 재생 중인 곡이나 목록의 곡을 Track으로 찾기 */
    private fun findTrack(url: String): Track? {
        for (p in playlists) p.tracks.firstOrNull { it.url == url }?.let { return it }
        return null
    }

    fun toggleFavorite(t: Track) {
        val fav = playlists.first { it.id == FAV_ID }
        val on = fav.tracks.any { it.url == t.url }
        val newTracks = if (on) fav.tracks.filterNot { it.url == t.url } else listOf(t) + fav.tracks
        updatePlaylists(playlists.map { if (it.id == FAV_ID) it.copy(tracks = newTracks) else it })
        toast(if (on) "좋아요를 취소했어요" else "좋아요에 추가했어요")
    }

    fun toggleFavoriteCurrent() {
        if (playingUrl.isEmpty()) return
        val t = findTrack(playingUrl)
            ?: Track(playingUrl, nowTitle, nowArtist, nowArt, durationMs / 1000)
        toggleFavorite(t)
    }

    fun copyTo(t: Track, targetId: String) {
        val target = playlists.firstOrNull { it.id == targetId } ?: return
        if (target.tracks.any { it.url == t.url }) {
            toast("'${target.name}'에 이미 있는 곡이에요")
            return
        }
        updatePlaylists(playlists.map { if (it.id == targetId) it.copy(tracks = it.tracks + t) else it })
        toast("'${target.name}'에 추가했어요")
    }

    fun removeFromPlaylist(pid: String, index: Int) {
        updatePlaylists(playlists.map {
            if (it.id == pid && index in it.tracks.indices) it.copy(tracks = it.tracks.filterIndexed { i, _ -> i != index })
            else it
        })
    }

    // ================= 오프라인 저장 =================
    fun startOffline(id: String) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        val app = getApplication<Application>()
        toast("'${p.name}' 오프라인 저장을 시작해요. 앱을 열어둔 동안 받아져요")
        PinnedDownloader.start(app, p) { failed ->
            toast(if (failed == 0) "'${p.name}' 저장 완료" else "'${p.name}' 저장 완료 (${failed}곡 실패)")
            viewModelScope.launch { refreshCacheInfo() }
        }
    }

    fun cancelOffline(id: String) {
        PinnedDownloader.cancel(id)
        toast("오프라인 저장을 멈췄어요")
    }

    fun removeOffline(id: String) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        PinnedDownloader.cancel(id)
        val app = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CacheProvider.removePinned(app, p.tracks.map { it.url }) }
            refreshCacheInfo()
            toast("저장된 곡을 지웠어요")
        }
    }

    // ================= 재생 제어 =================
    fun playFrom(index: Int) {
        val c = controller ?: return
        val pl = current ?: return
        val list = pl.tracks
        if (list.isEmpty() || index !in list.indices) return
        val sameQueue = c.mediaItemCount == list.size &&
            (0 until c.mediaItemCount).all { c.getMediaItemAt(it).mediaId == mediaIdOf(pl.id, list[it].url) }
        if (sameQueue) c.seekTo(index, 0L)
        else c.setMediaItems(list.map { it.toMediaItem(pl.id) }, index, 0L)
        c.prepare()
        c.play()
    }

    fun playAll() = playFrom(0)

    fun playShuffled() {
        if (tracks.isEmpty()) return
        controller?.shuffleModeEnabled = true
        playFrom(tracks.indices.random())
    }

    fun playNext(t: Track, pid: String) {
        val c = controller ?: return
        val item = t.toMediaItem(pid)
        if (c.mediaItemCount == 0) {
            c.setMediaItem(item)
            c.prepare()
            c.play()
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, item)
        }
        toast(if (c.shuffleModeEnabled) "대기열에 추가했어요 (셔플 중이라 순서는 섞여요)" else "다음 곡으로 넣었어요")
    }

    fun addToQueue(t: Track, pid: String) {
        val c = controller ?: return
        val item = t.toMediaItem(pid)
        if (c.mediaItemCount == 0) {
            c.setMediaItem(item)
            c.prepare()
            c.play()
        } else {
            c.addMediaItem(item)
        }
        toast("대기열 맨 뒤에 추가했어요")
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
            return
        }
        if (c.mediaItemCount == 0) {
            if (tracks.isNotEmpty()) playFrom(0)
            return
        }
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
        if (c.playbackState == Player.STATE_ENDED) c.seekTo(c.currentMediaItemIndex, 0L)
        c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms) }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun updateSpeed(v: Float) {
        controller?.setPlaybackSpeed(v)
        speed = v
        prefs.edit().putFloat("speed", v).apply()
    }

    fun queuePlay(index: Int) {
        val c = controller ?: return
        if (index !in 0 until c.mediaItemCount) return
        c.seekTo(index, 0L)
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
        c.play()
    }

    fun queueRemove(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) c.removeMediaItem(index)
    }

    fun queueMove(from: Int, to: Int) {
        val c = controller ?: return
        val n = c.mediaItemCount
        if (from in 0 until n && to in 0 until n) c.moveMediaItem(from, to)
    }

    // ================= 캐시 =================
    suspend fun refreshCacheInfo() {
        val app = getApplication<Application>()
        val list = tracks
        val r = withContext(Dispatchers.Default) {
            val auto = CacheProvider.get(app)
            val pin = CacheProvider.getPinned(app)
            val a = list.filter { CacheProvider.isFullyCached(auto, it.url) }.map { it.url }.toSet()
            val b = list.filter { CacheProvider.isFullyCached(pin, it.url) }.map { it.url }.toSet()
            listOf(a, b, auto.cacheSpace, pin.cacheSpace)
        }
        @Suppress("UNCHECKED_CAST")
        cachedUrls = r[0] as Set<String>
        @Suppress("UNCHECKED_CAST")
        pinnedUrls = r[1] as Set<String>
        cacheBytes = r[2] as Long
        pinnedBytes = r[3] as Long
    }

    fun clearCache() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CacheProvider.clear(app) }
            refreshCacheInfo()
            toast("자동 캐시를 비웠어요")
        }
    }

    fun clearPinned() {
        val app = getApplication<Application>()
        PinnedDownloader.progress.keys.toList().forEach { PinnedDownloader.cancel(it) }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CacheProvider.clearPinned(app) }
            refreshCacheInfo()
            toast("오프라인 저장 곡을 모두 지웠어요")
        }
    }

    // ================= 백업 =================
    fun exportTo(uri: Uri) {
        val app = getApplication<Application>()
        val text = Store.exportJson(playlists)
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val out = app.contentResolver.openOutputStream(uri) ?: throw IOException("파일 열기 실패")
                    out.use { it.write(text.toByteArray()) }
                }
                toast("백업 파일을 저장했어요")
            } catch (e: Exception) {
                toast("백업하지 못했어요")
            }
        }
    }

    fun importFrom(uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val input = app.contentResolver.openInputStream(uri) ?: throw IOException("파일 열기 실패")
                    input.use { it.readBytes().toString(Charsets.UTF_8) }
                }
                val incoming = Store.parseExport(text)
                var list = playlists
                var added = 0
                for (p in incoming) {
                    if (p.id == FAV_ID) {
                        val fav = list.first { it.id == FAV_ID }
                        val merged = fav.tracks + p.tracks.filter { t -> fav.tracks.none { it.url == t.url } }
                        list = list.map { if (it.id == FAV_ID) it.copy(tracks = merged) else it }
                        continue
                    }
                    val lid = listIdOf(p.url)
                    if (lid != null && list.any { listIdOf(it.url) == lid }) continue
                    list = list + p.copy(id = Store.newId())
                    added++
                }
                updatePlaylists(list)
                toast("플레이리스트 ${added}개를 가져왔어요")
            } catch (e: Exception) {
                toast("백업 파일을 읽지 못했어요")
            }
        }
    }

    // ================= 설정 =================
    private fun putBool(k: String, v: Boolean) = prefs.edit().putBoolean(k, v).apply()

    fun updateThemeMode(v: Int) { themeMode = v; prefs.edit().putInt("theme_mode", v).apply() }

    fun updateNight(start: Int, end: Int) {
        nightStart = (start + 24) % 24
        nightEnd = (end + 24) % 24
        prefs.edit().putInt("night_start", nightStart).putInt("night_end", nightEnd).apply()
    }

    fun updateAccent(v: Int) {
        accent = v
        prefs.edit().putInt("accent", v).apply()
        if (dynamicColor) updateDynamic(false) // 색을 직접 고르면 배경화면 색상은 끔
    }

    fun updateDynamic(v: Boolean) { dynamicColor = v; putBool("dynamic", v) }
    fun updateGlass(v: Boolean) { glass = v; putBool("glass", v) }
    fun updateArtColor(v: Boolean) { useArtColor = v; putBool("art_color", v) }
    fun updateHaptics(v: Boolean) { haptics = v; putBool("haptics", v) }
    fun updateOneHand(v: Boolean) { oneHand = v; putBool("one_hand", v) }
    fun updateResume(v: Boolean) { resumeEnabled = v; putBool("resume", v) }
    fun updatePrefetch(v: Boolean) { prefetch = v; putBool("prefetch", v) }
    fun updatePrefetchWifi(v: Boolean) { prefetchWifi = v; putBool("prefetch_wifi", v) }

    fun updateFontScale(v: Float) { fontScale = v; prefs.edit().putFloat("font_scale", v).apply() }

    fun updateCacheMb(v: Int) {
        cacheMb = v
        prefs.edit().putInt("cache_mb", v).apply()
        toast("앱을 완전히 껐다 켜면 적용돼요")
    }

    fun finishOnboarding() { onboarded = true; putBool("onboarded", true) }
    fun showOnboardingAgain() { onboarded = false; putBool("onboarded", false) }

    override fun onCleared() {
        runCatching { cm?.unregisterNetworkCallback(netCb) }
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
