package com.example.ytplaylist

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import kotlin.random.Random
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.PlaybackParameters
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import java.io.IOException

/** 재생 대기열 한 줄 (index = 플레이어 안의 실제 위치) */
data class QueueEntry(
    val index: Int,
    val mediaId: String,
    val title: String,
    val artist: String,
    val art: String?
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("yt", Context.MODE_PRIVATE)

    // ================= 플레이리스트 =================
    var playlists by mutableStateOf(withFav(Store.load(prefs)))
        private set
    var selectedId by mutableStateOf(prefs.getString("selected", "") ?: "")
        private set
    /** 자동 플레이리스트 (많이 들은 곡 / 새로 들어온 곡 / 한동안 안 들은 곡) */
    var autoLists by mutableStateOf<List<Playlist>>(emptyList())
        private set
    val current: Playlist?
        get() = playlists.firstOrNull { it.id == selectedId }
            ?: autoLists.firstOrNull { it.id == selectedId }
            ?: playlists.firstOrNull { it.id != FAV_ID }
            ?: playlists.firstOrNull()
    val tracks: List<Track> get() = current?.tracks ?: emptyList()
    val hasUserPlaylists: Boolean get() = playlists.any { it.id != FAV_ID }

    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var retry by mutableStateOf<(() -> Unit)?>(null)
        private set

    private val _toasts = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toasts = _toasts.asSharedFlow()
    private fun toast(m: String) { _toasts.tryEmit(m) }

    // ================= 재생 상태 =================
    var currentIndex by mutableIntStateOf(-1)
        private set
    var playingPid by mutableStateOf("")
        private set
    var playingUrl by mutableStateOf("")
        private set
    var nowTitle by mutableStateOf("")
        private set
    var nowArtist by mutableStateOf("")
        private set
    var nowArt by mutableStateOf<String?>(null)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var isBuffering by mutableStateOf(false)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_ALL)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    /** positionMs를 읽은 시각 (화면에서 진행 위치를 매 프레임 부드럽게 계산하는 데 씀) */
    var positionAt by mutableLongStateOf(0L)
        private set
    var speed by mutableFloatStateOf(prefs.getFloat("speed", 1f))
        private set
    var queue by mutableStateOf<List<QueueEntry>>(emptyList())
        private set
    var artColor by mutableStateOf<Color?>(null)
        private set
    /** 커버에서 뽑은 색 3가지 (배경 그라데이션용) */
    var artColors by mutableStateOf<List<Color>>(emptyList())
        private set
    /**
     * 배경에 쓸 색
     * - '앨범 아트 색 따라가기'가 켜져 있으면 (흑백 테마여도) 커버 색
     * - 꺼져 있으면: 흑백 테마는 회색 안개, 그 외는 테마 기본색
     */
    val bgColors: List<Color>
        get() {
            val mono = ACCENTS.getOrNull(accent)?.second == MONO
            val gray = listOf(Color(0xFF8C8C8C), Color(0xFF3A3A3A), Color(0xFFCFCFCF))
            return when {
                useArtColor && artColors.isNotEmpty() && !(dynamicColor && !mono) -> artColors
                mono -> gray
                else -> emptyList()
            }
        }
    var favUrls by mutableStateOf<Set<String>>(emptySet())
        private set
    var recent by mutableStateOf(Store.loadRecent(prefs))
        private set

    // ================= 저장 공간 =================
    var cachedUrls by mutableStateOf<Set<String>>(emptySet())
        private set
    var pinnedUrls by mutableStateOf<Set<String>>(emptySet())
        private set
    var cacheBytes by mutableLongStateOf(0L)
        private set
    var pinnedBytes by mutableLongStateOf(0L)
        private set

    // ================= 네트워크 =================
    var online by mutableStateOf(true)
        private set
    private val cm = app.getSystemService(ConnectivityManager::class.java)
    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            viewModelScope.launch {
                online = true
                if (favSavePending) { kotlinx.coroutines.delay(3000); maybeSaveFavs() }
            }
        }

        override fun onLost(network: Network) {
            viewModelScope.launch { online = checkOnline() }
        }
    }

    // ================= 소리 / 순서 설정 =================
    var smartShuffle by mutableStateOf(prefs.getBoolean("smart_shuffle", true))
        private set
    var moodShuffle by mutableStateOf(prefs.getBoolean("mood_shuffle", false))
        private set
    var bassHaptic by mutableStateOf(prefs.getBoolean("bass_haptic", false))
        private set
    var lockLyrics by mutableStateOf(prefs.getBoolean("lock_lyrics", false))
        private set
    var autoStandby by mutableStateOf(prefs.getBoolean("auto_standby", false))
        private set
    fun updateAutoStandby(v: Boolean) { autoStandby = v; putBool("auto_standby", v) }
    fun updateSmartShuffle(v: Boolean) { smartShuffle = v; putBool("smart_shuffle", v) }
    fun updateMoodShuffle(v: Boolean) { moodShuffle = v; putBool("mood_shuffle", v) }
    fun updateBassHaptic(v: Boolean) { bassHaptic = v; putBool("bass_haptic", v) }
    fun updateLockLyrics(v: Boolean) { lockLyrics = v; putBool("lock_lyrics", v); if (v) loadLyrics() }

    fun updatePitch(semis: Int) {
        SoundFx.updatePitch(semis)
        controller?.setPlaybackParameters(PlaybackParameters(speed, SoundFx.pitchFactor))
    }

    /** 지금 위치를 이 곡의 시작 지점으로 (긴 전주 건너뛰기) */
    fun setStartHere() {
        if (playingUrl.isEmpty()) return
        val pos = controller?.currentPosition ?: positionMs
        SongPrefs.setStart(playingUrl, pos)
        toast("다음부터 ${fmtTime(pos)}부터 재생해요")
    }

    fun clearStart() {
        SongPrefs.setStart(playingUrl, 0L)
        toast("시작 지점을 지웠어요")
    }

    // ================= 자동 플레이리스트 =================
    fun refreshAutoLists() {
        viewModelScope.launch {
            val snap = withContext(Dispatchers.IO) { Stats.snapshot(prefs) }
            val lib = playlists.filter { it.id != FAV_ID }.flatMap { it.tracks }.distinctBy { it.url }
            val libByUrl = lib.associateBy { it.url }
            fun trackOf(s: Stats.TrackStat) = libByUrl[s.url] ?: Track(s.url, s.title, s.artist, s.thumb, 0L)
            val now = System.currentTimeMillis()
            val top = snap.tracks.filter { it.count >= 2 }.sortedByDescending { it.count }.take(50).map(::trackOf)
            val statByUrl = snap.tracks.associateBy { it.url }
            val old = lib.filter { t -> statByUrl[t.url]?.let { now - it.last > 21L * 86_400_000L } ?: false }
                .sortedBy { statByUrl[it.url]?.last ?: 0L }.take(50)
            val fresh = lib.filter { now - SongPrefs.addedTime(it.url) < 14L * 86_400_000L }
                .sortedByDescending { SongPrefs.addedTime(it.url) }.take(50)
            autoLists = listOfNotNull(
                Playlist(AUTO_TOP, "많이 들은 곡", "", top).takeIf { top.size >= 3 },
                Playlist(AUTO_NEW, "새로 들어온 곡", "", fresh).takeIf { fresh.isNotEmpty() },
                Playlist(AUTO_OLD, "한동안 안 들은 곡", "", old).takeIf { old.size >= 3 }
            )
        }
    }

    fun setCover(id: String, cover: String) {
        updatePlaylists(playlists.map { if (it.id == id) it.copy(cover = cover) else it })
    }

    /** 갤러리에서 고른 사진을 커버로 (작게 줄여서 앱 안에 복사) */
    fun setCoverImage(id: String, uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                runCatching {
                    val src = app.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) } ?: return@runCatching null
                    val side = minOf(src.width, src.height)
                    val sq = android.graphics.Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
                    val small = android.graphics.Bitmap.createScaledBitmap(sq, 600, 600, true)
                    val dir = java.io.File(app.filesDir, "covers").apply { mkdirs() }
                    val f = java.io.File(dir, "$id-${System.currentTimeMillis()}.jpg")
                    f.outputStream().use { small.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }
                    f.absolutePath
                }.getOrNull()
            }
            if (path != null) { setCover(id, "img:$path"); toast("커버를 바꿨어요") } else toast("사진을 불러오지 못했어요")
        }
    }

    /** 검색 창을 열어 달라고 화면에 알리기 */
    fun requestSearchSheet() { openSearchRequest++ }

    fun saveTracksAsPlaylist(name: String, tracks: List<Track>) {
        if (tracks.isEmpty()) return
        updatePlaylists(playlists + Playlist(Store.newId(), name, "", tracks))
        toast("'$name'을(를) 내 플레이리스트로 저장했어요")
    }

    /** 지금 대기열을 그대로 새 플레이리스트로 */
    fun saveQueueAsPlaylist(name: String) {
        val tracks = queue.map { e ->
            val u = urlOf(e.mediaId)
            findTrack(u) ?: Track(u, e.title, e.artist, e.art, 0L)
        }.distinctBy { it.url }
        if (tracks.isEmpty()) { toast("대기열이 비어 있어요"); return }
        updatePlaylists(playlists + Playlist(Store.newId(), name.ifBlank { "대기열" }, "", tracks))
        toast("'${name.ifBlank { "대기열" }}' 플레이리스트로 저장했어요 (${tracks.size}곡)")
    }

    // ================= 설정 =================
    var themeMode by mutableIntStateOf(prefs.getInt("theme_mode", 0)) // 0 시스템 1 라이트 2 다크 3 시간 예약
        private set
    var nightStart by mutableIntStateOf(prefs.getInt("night_start", 21))
        private set
    var nightEnd by mutableIntStateOf(prefs.getInt("night_end", 7))
        private set
    var accent by mutableIntStateOf(prefs.getInt("accent", 0))
        private set
    var dynamicColor by mutableStateOf(prefs.getBoolean("dynamic", false))
        private set
    var glass by mutableStateOf(prefs.getBoolean("glass", true))
        private set
    var useArtColor by mutableStateOf(prefs.getBoolean("art_color", true))
        private set
    var haptics by mutableStateOf(prefs.getBoolean("haptics", true))
        private set
    var fontScale by mutableFloatStateOf(prefs.getFloat("font_scale", 1f))
        private set
    var oneHand by mutableStateOf(prefs.getBoolean("one_hand", false))
        private set
    var resumeEnabled by mutableStateOf(prefs.getBoolean("resume", true))
        private set
    var prefetch by mutableStateOf(prefs.getBoolean("prefetch", true))
        private set
    var prefetchWifi by mutableStateOf(prefs.getBoolean("prefetch_wifi", false))
        private set
    var cacheMb by mutableIntStateOf(prefs.getInt("cache_mb", CacheProvider.DEFAULT_MB))
        private set
    var onboarded by mutableStateOf(prefs.getBoolean("onboarded", false))
        private set
    var lowQuality by mutableStateOf(prefs.getBoolean("low_quality", false))
        private set
    var skipOfftopic by mutableStateOf(prefs.getBoolean("skip_offtopic", true))
        private set
    var fadeMs by mutableIntStateOf(prefs.getInt("fade_ms", 0))
        private set
    var autoPlayConnect by mutableStateOf(prefs.getBoolean("auto_play_connect", false))
        private set
    var checkUpdates by mutableStateOf(prefs.getBoolean("check_updates", true))
        private set
    var alarmOn by mutableStateOf(prefs.getBoolean("alarm_on", false))
        private set
    var alarmHour by mutableIntStateOf(prefs.getInt("alarm_h", 7))
        private set
    var alarmMinute by mutableIntStateOf(prefs.getInt("alarm_m", 0))
        private set
    var alarmPid by mutableStateOf(prefs.getString("alarm_pid", "") ?: "")
        private set
    var longResume by mutableStateOf(prefs.getBoolean("long_resume", true))
        private set
    var shakeSkip by mutableStateOf(prefs.getBoolean("shake_skip", false))
        private set
    var autoplayRelated by mutableStateOf(prefs.getBoolean("autoplay_related", true))
    var cleanTitles by mutableStateOf(prefs.getBoolean("clean_titles", true).also { TitleClean.on = it })
        private set
    /** 곡 정보 시트 내용 (null = 불러오는 중) */
    var info by mutableStateOf<TrackInfo?>(null)
        private set
    var infoError by mutableStateOf<String?>(null)
        private set
    /** 바로가기(앱 아이콘 길게 누르기)로 검색 화면을 열어달라는 요청 */
    var openSearchRequest by mutableIntStateOf(0)
        private set
    private var pendingShortcut: String? = null

    // ================= 가사 / 검색 / 새 곡 =================
    var lyrics by mutableStateOf<LyricsState>(LyricsState.Idle)
        private set
    private var lyricsUrl = ""
    var searchResults by mutableStateOf<List<Track>>(emptyList())
        private set
    var searching by mutableStateOf(false)
        private set
    var searchError by mutableStateOf<String?>(null)
        private set
    var lastQuery by mutableStateOf("")
        private set
    /** 이번에 열었을 때 새로 생긴 곡 */
    var newUrls by mutableStateOf<Set<String>>(emptySet())
        private set
    val tags: List<String> get() = playlists.map { it.tag }.filter { it.isNotBlank() }.distinct()

    private var controller: MediaController? = null
    private var colorJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player, events)
    }

    init {
        SongPrefs.init(app)
        SoundFx.load(app)
        if (!prefs.getBoolean("added_seeded", false)) {
            SongPrefs.seedOld(playlists.flatMap { it.tracks }.map { it.url })
            prefs.edit().putBoolean("added_seeded", true).apply()
        }
        favUrls = playlists.firstOrNull { it.id == FAV_ID }?.tracks?.map { it.url }?.toSet() ?: emptySet()
        if (playlists.none { it.id == selectedId }) {
            selectedId = (playlists.firstOrNull { it.id != FAV_ID } ?: playlists.first()).id
        }
        persist()

        online = checkOnline()
        runCatching { cm?.registerDefaultNetworkCallback(netCb) }

        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(listener)
            if (c.mediaItemCount == 0) {
                if (speed != 1f || SoundFx.pitchSemis != 0) c.setPlaybackParameters(PlaybackParameters(speed, SoundFx.pitchFactor))
                if (resumeEnabled) restoreSession(c)
            }
            sync(c, null)
            pendingShortcut?.let { k ->
                pendingShortcut = null
                runShortcut(k)
            }
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch { PlaybackEvents.messages.collect { toast(it) } }
        viewModelScope.launch {
            PlaybackEvents.favChangedByService.collect {
                playlists = withFav(Store.load(prefs))
                favUrls = playlists.first { it.id == FAV_ID }.tracks.map { it.url }.toSet()
            }
        }
        if (alarmOn) runCatching { AlarmScheduler.schedule(app) }

        if (online) {
            if (checkUpdates) checkAllPlaylists()
            else current?.let { if (it.url.isNotBlank()) refreshPlaylist(it.id, quiet = true) }
        }
    }

    /** 앱을 열 때 유튜브 플레이리스트들을 확인해서 새 곡을 알려줘요 */
    private fun checkAllPlaylists() {
        viewModelScope.launch {
            val msgs = mutableListOf<String>()
            val added = mutableSetOf<String>()
            for (p in playlists.filter { it.url.isNotBlank() }) {
                try {
                    val (_, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(p.url) }
                    val old = playlists.firstOrNull { it.id == p.id }?.tracks?.map { it.url }?.toSet() ?: continue
                    val fresh = list.filter { it.url !in old }
                    if (old.isNotEmpty() && fresh.isNotEmpty()) {
                        msgs += "'${p.name}' ${fresh.size}곡"
                        added += fresh.map { it.url }
                    }
                    updatePlaylists(playlists.map { if (it.id == p.id) it.copy(tracks = list) else it })
                } catch (e: Exception) {
                    // 조용히 넘어감 (오프라인 등)
                }
            }
            if (added.isNotEmpty()) {
                newUrls = newUrls + added
                toast("새 곡이 추가됐어요: " + msgs.joinToString(", "))
            }
        }
    }

    // ================= 가사 =================
    fun loadLyrics() {
        val url = playingUrl
        if (url.isEmpty() || url == lyricsUrl) return
        lyricsUrl = url
        lyrics = LyricsState.Loading
        val t = findTrack(url)
        val title = t?.title ?: nowTitle
        val artist = t?.artist ?: nowArtist
        val dur = t?.durationSec ?: (durationMs / 1000)
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { Lyrics.fetch(url, title, artist, dur) }
            if (lyricsUrl == url) lyrics = r
            if (r is LyricsState.Synced) { LyricsBridge.url = url; LyricsBridge.lines = r.lines }
            // 집중 모드 '가사 없는 곡만': 가사가 있으면 넘겨요
            if (FocusMode.running && FocusMode.instrumentalOnly && playingUrl == url &&
                (r is LyricsState.Synced || r is LyricsState.Plain)
            ) {
                toast("가사가 있는 곡이라 넘겼어요 (집중 모드)")
                next()
            }
        }
    }

    // ================= 검색 =================
    fun search(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        lastQuery = query
        searching = true
        searchError = null
        viewModelScope.launch {
            try {
                searchResults = withContext(Dispatchers.IO) { YtRepo.search(query) }
                if (searchResults.isEmpty()) searchError = "검색 결과가 없어요"
            } catch (e: Exception) {
                searchError = friendlyError(e)
            }
            searching = false
        }
    }

    /** 곡 목록을 통째로 대기열에 넣고 index부터 재생 */
    fun playList(list: List<Track>, pid: String, index: Int) {
        val c = controller ?: return
        if (list.isEmpty() || index !in list.indices) return
        c.setMediaItems(list.map { it.toMediaItem(pid) }, index, 0L)
        c.prepare()
        c.play()
    }

    // ================= 섞어 듣기 / 태그 / 추천 / 통계 =================
    fun playMix(ids: Collection<String>) {
        val c = controller ?: return
        val items = playlists.filter { it.id in ids }
            .flatMap { p -> p.tracks.map { p.id to it } }
            .distinctBy { it.second.url }
            .shuffled()
        if (items.isEmpty()) return
        c.shuffleModeEnabled = false
        c.setMediaItems(items.map { (pid, t) -> t.toMediaItem(pid) }, 0, 0L)
        c.prepare()
        c.play()
        toast("${ids.size}개 플레이리스트, ${items.size}곡을 섞어서 재생해요")
    }

    fun updateTag(id: String, tag: String) {
        updatePlaylists(playlists.map { if (it.id == id) it.copy(tag = tag.trim()) else it })
    }

    data class Pick(val pid: String, val track: Track, val reason: String)

    /** 오늘의 추천: 하루 동안 같은 곡이 유지돼요 */
    fun todayPick(): Pick? {
        val snap = Stats.snapshot(prefs)
        val now = System.currentTimeMillis()
        val rnd = Random(now / 86_400_000L)
        val pool = playlists.flatMap { p -> p.tracks.map { p.id to it } }.distinctBy { it.second.url }
        if (pool.isEmpty()) return null
        val stat = snap.tracks.associateBy { it.url }
        val weekAgo = now - 7L * 86_400_000L
        val forgotten = pool.filter { (_, t) -> stat[t.url]?.let { it.last < weekAgo } == true }
        val loved = snap.tracks.sortedByDescending { it.count }.take(10)
            .mapNotNull { s -> pool.firstOrNull { it.second.url == s.url } }
        val choice = when (rnd.nextInt(3)) {
            0 -> forgotten.randomOrNull(rnd)?.let { Pick(it.first, it.second, "한동안 안 들은 곡") }
            1 -> loved.randomOrNull(rnd)?.let { Pick(it.first, it.second, "요즘 자주 듣는 곡") }
            else -> null
        }
        return choice ?: pool.random(rnd).let { Pick(it.first, it.second, "오늘의 랜덤 곡") }
    }

    fun statsSnapshot(): Stats.Snapshot = Stats.snapshot(prefs)

    fun clearStats() {
        Stats.clear(prefs)
        toast("청취 기록을 지웠어요")
    }

    // ================= 알람 =================
    fun updateAlarm(on: Boolean = alarmOn, h: Int = alarmHour, m: Int = alarmMinute, pid: String = alarmPid) {
        alarmOn = on
        alarmHour = (h + 24) % 24
        alarmMinute = (m + 60) % 60
        alarmPid = pid
        prefs.edit().putBoolean("alarm_on", on).putInt("alarm_h", alarmHour).putInt("alarm_m", alarmMinute)
            .putString("alarm_pid", pid).commit()
        val app = getApplication<Application>()
        val ok = AlarmScheduler.schedule(app)
        if (on && !ok) {
            toast("정확한 알람 권한을 허용해주세요")
            if (Build.VERSION.SDK_INT >= 31) {
                runCatching {
                    app.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + app.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
        }
    }

    fun alarmLabel(): String {
        val t = AlarmScheduler.nextTrigger(alarmHour, alarmMinute)
        val today = Stats.dayKey(System.currentTimeMillis()) == Stats.dayKey(t)
        return "${if (today) "오늘" else "내일"} %02d:%02d".format(alarmHour, alarmMinute)
    }

    private fun withFav(list: List<Playlist>): List<Playlist> =
        if (list.any { it.id == FAV_ID }) list
        else listOf(Playlist(FAV_ID, "좋아요", "", emptyList())) + list

    private fun checkOnline(): Boolean {
        val c = cm ?: return true
        val n = c.activeNetwork ?: return false
        val caps = c.getNetworkCapabilities(n) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun sync(p: Player, events: Player.Events?) {
        positionMs = p.currentPosition
        positionAt = SystemClock.elapsedRealtime()
        isPlaying = p.isPlaying
        isBuffering = p.playbackState == Player.STATE_BUFFERING
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        currentIndex = if (p.mediaItemCount > 0) p.currentMediaItemIndex else -1
        durationMs = p.duration.takeIf { it != C.TIME_UNSET } ?: 0L
        speed = p.playbackParameters.speed
        val id = p.currentMediaItem?.mediaId ?: ""
        val newUrl = if (id.isEmpty()) "" else urlOf(id)
        val changed = newUrl != playingUrl
        playingPid = pidOf(id)
        playingUrl = newUrl
        val md = p.mediaMetadata
        nowTitle = md.title?.toString() ?: ""
        nowArtist = md.artist?.toString() ?: ""
        val art = md.artworkUri?.toString()
        if (art != nowArt) {
            nowArt = art
            extractColor(art)
        }
        if (changed && newUrl.isNotEmpty() && events != null) pushRecent(playingPid, newUrl)
        if (changed && newUrl.isNotEmpty() && (lockLyrics || (FocusMode.running && FocusMode.instrumentalOnly))) loadLyrics()
        if (events == null ||
            events.contains(Player.EVENT_TIMELINE_CHANGED) ||
            events.contains(Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED)
        ) rebuildQueue(p)
    }

    private fun rebuildQueue(p: Player) {
        val n = p.mediaItemCount
        val order = ArrayList<Int>(n)
        val tl = p.currentTimeline
        if (p.shuffleModeEnabled && n > 0 && tl.windowCount == n) {
            var i = tl.getFirstWindowIndex(true)
            while (i != C.INDEX_UNSET && order.size < n) {
                order.add(i)
                i = tl.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, true)
            }
        }
        if (order.size != n) {
            order.clear()
            for (i in 0 until n) order.add(i)
        }
        queue = order.map { i ->
            val item = p.getMediaItemAt(i)
            QueueEntry(
                index = i,
                mediaId = item.mediaId,
                title = item.mediaMetadata.title?.toString() ?: "",
                artist = item.mediaMetadata.artist?.toString() ?: "",
                art = item.mediaMetadata.artworkUri?.toString()
            )
        }
    }

    /** 앨범 아트에서 색을 뽑아 테마와 배경 그라데이션에 반영 */
    private fun extractColor(url: String?) {
        colorJob?.cancel()
        if (url == null) {
            artColor = null
            artColors = emptyList()
            return
        }
        val ctx = getApplication<Application>()
        colorJob = viewModelScope.launch {
            val cols: List<Int>? = withContext(Dispatchers.IO) {
                try {
                    val req = ImageRequest.Builder(ctx).data(url).allowHardware(false).size(96).build()
                    val bmp = (ctx.imageLoader.execute(req).drawable as? BitmapDrawable)?.bitmap
                    if (bmp == null) null
                    else {
                        val pal = Palette.from(bmp).maximumColorCount(16).generate()
                        val main = (pal.vibrantSwatch ?: pal.dominantSwatch)?.rgb
                        val deep = (pal.darkVibrantSwatch ?: pal.darkMutedSwatch ?: pal.dominantSwatch)?.rgb
                        val soft = (pal.lightVibrantSwatch ?: pal.mutedSwatch ?: pal.vibrantSwatch)?.rgb
                        if (main == null) null else listOf(main, deep ?: main, soft ?: main)
                    }
                } catch (e: Exception) {
                    null
                }
            }
            artColor = cols?.firstOrNull()?.let { Color(it) }
            artColors = cols?.map { Color(it) } ?: emptyList()
        }
    }

    private fun pushRecent(pid: String, url: String) {
        val t = findTrack(url) ?: Track(url, nowTitle, nowArtist, nowArt, durationMs / 1000)
        recent = (listOf(RecentItem(pid, t)) + recent.filterNot { it.track.url == url }).take(20)
        Store.saveRecent(prefs, recent)
    }

    /** 특정 플레이리스트 안의 곡을 그 목록 흐름 그대로 재생 */
    fun playTrackIn(pid: String, url: String) {
        val pl = playlists.firstOrNull { it.id == pid }
        val idx = pl?.tracks?.indexOfFirst { it.url == url } ?: -1
        if (pl != null && idx >= 0) {
            select(pl.id)
            playFrom(idx)
        } else {
            val t = recent.firstOrNull { it.track.url == url }?.track ?: return
            playNext(t, pid)
            next()
        }
    }

    fun movePlaylistToFront(id: String) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        if (id == FAV_ID) return
        val others = playlists.filterNot { it.id == id || it.id == FAV_ID }
        updatePlaylists(listOf(playlists.first { it.id == FAV_ID }, p) + others)
        toast("'${p.name}'을(를) 맨 앞으로 옮겼어요")
    }

    fun clearRecent() {
        recent = emptyList()
        Store.saveRecent(prefs, recent)
    }

    fun refreshPosition() {
        controller?.let {
            positionMs = it.currentPosition
            positionAt = SystemClock.elapsedRealtime()
        }
    }

    private fun restoreSession(c: MediaController) {
        val pid = prefs.getString("resume_pid", null) ?: return
        val url = prefs.getString("resume_url", null)
        val pos = prefs.getLong("resume_pos", 0L)
        val pl = playlists.firstOrNull { it.id == pid } ?: return
        if (pl.tracks.isEmpty()) return
        val idx = pl.tracks.indexOfFirst { it.url == url }
        c.setMediaItems(pl.tracks.map { it.toMediaItem(pl.id) }, idx.coerceAtLeast(0), if (idx >= 0) pos else 0L)
        c.prepare()
    }

    // ================= 오류 =================
    private fun showError(msg: String, r: (() -> Unit)? = null) {
        error = msg
        retry = r
    }

    fun clearError() {
        error = null
        retry = null
    }

    // ================= 플레이리스트 관리 =================
    private fun persist() {
        // 새로 들어온 곡 기록 (자동 플레이리스트 '새로 들어온 곡')
        SongPrefs.markAdded(playlists.filter { it.id != FAV_ID }.flatMap { it.tracks }.map { it.url })
        Store.save(prefs, playlists)
        prefs.edit().putString("selected", selectedId).apply()
    }

    private fun updatePlaylists(list: List<Playlist>) {
        playlists = withFav(list)
        favUrls = playlists.first { it.id == FAV_ID }.tracks.map { it.url }.toSet()
        persist()
        // 홈 화면의 플레이리스트 위젯도 새로 (위젯이 있을 때만, 잠깐 모아서)
        widgetJob?.cancel()
        widgetJob = viewModelScope.launch {
            kotlinx.coroutines.delay(1500)
            PlaylistWidgetUpdater.requestUpdate(getApplication())
        }
    }
    private var widgetJob: kotlinx.coroutines.Job? = null

    fun select(id: String) {
        selectedId = id
        clearError()
        persist()
    }

    fun isFavorite(url: String): Boolean = url.isNotEmpty() && url in favUrls

    /** 위젯에서 고른 플레이리스트 (playlist://play/<id>) */
    var pendingPlayPid: String? = null

    /** 앱 아이콘 바로가기: shuffle / resume / search */
    fun handleShortcut(kind: String) {
        if (controller == null && kind != "search") {
            pendingShortcut = kind
            return
        }
        runShortcut(kind)
    }

    private fun runShortcut(kind: String) {
        when (kind) {
            "search" -> openSearchRequest++
            "resume" -> togglePlayIfPaused()
            "play" -> {
                val pid = pendingPlayPid ?: return
                pendingPlayPid = null
                if (playlists.any { it.id == pid && it.tracks.isNotEmpty() }) shuffleIn(pid) else toast("플레이리스트를 찾지 못했어요")
            }
            "shuffle" -> {
                val ids = playlists.filter { it.tracks.isNotEmpty() && it.id != FAV_ID }.map { it.id }
                if (ids.isNotEmpty()) playMix(ids) else toast("아직 플레이리스트가 없어요")
            }
        }
    }

    private fun togglePlayIfPaused() {
        val c = controller ?: return
        if (!c.isPlaying) togglePlay()
    }

    /** 가수 이름으로 유튜브 검색 */
    fun findArtist(artist: String) {
        val a = artist.replace(Regex("(?i)\\s*-\\s*topic$|vevo$"), "").trim()
        if (a.isNotEmpty()) search(a)
    }

    /** 많이 들은 곡 25개를 모아서 재생 */
    fun playTopTracks() {
        val c = controller ?: return
        val top = Stats.snapshot(prefs).tracks.filter { it.count > 0 }
            .sortedWith(compareByDescending<Stats.TrackStat> { it.count }.thenByDescending { it.ms })
            .take(25)
        if (top.isEmpty()) {
            toast("아직 들은 기록이 없어요")
            return
        }
        c.shuffleModeEnabled = false
        c.setMediaItems(top.map { Track(it.url, it.title, it.artist, it.thumb, 0).toMediaItem(it.pid) }, 0, 0L)
        c.prepare()
        c.play()
        toast("많이 들은 곡 ${top.size}개를 재생해요")
    }

    /** 이 곡으로 라디오 시작: 이 곡을 틀고 비슷한 곡을 계속 이어 붙여요 */
    // ----- 추천 곡: 지금(또는 마지막) 곡과 비슷한 곡 -----
    var recs by mutableStateOf<List<Track>>(emptyList())
        private set
    var recsLoading by mutableStateOf(false)
        private set
    private var recsFor = ""

    fun loadRecs(force: Boolean = false) {
        val seed = playingUrl.ifEmpty { recent.firstOrNull()?.track?.url ?: "" }
        if (seed.isEmpty() || !online || recsLoading) return
        if (!force && seed == recsFor && recs.isNotEmpty()) return
        recsFor = seed
        recsLoading = true
        viewModelScope.launch {
            val list = runCatching { withContext(Dispatchers.IO) { YtRepo.related(seed) } }.getOrNull()
            if (list != null) {
                val mine = playlists.flatMap { it.tracks }.map { it.url }.toSet()
                // 아직 내 목록에 없는 곡을 먼저
                recs = (list.filter { it.url !in mine } + list.filter { it.url in mine })
                    .distinctBy { it.url }.filter { it.url != seed }.take(15)
            }
            recsLoading = false
        }
    }

    fun startRadio(t: Track) {
        val c = controller ?: return
        prefs.edit().putBoolean("radio_force", true).apply()
        c.shuffleModeEnabled = false
        c.setMediaItems(listOf(t.toMediaItem(RADIO_PID)), 0, 0L)
        c.prepare()
        c.play()
        toast("'${t.title.take(20)}' 라디오를 시작해요")
    }

    fun loadInfo(url: String) {
        info = null
        infoError = null
        viewModelScope.launch {
            try {
                info = withContext(Dispatchers.IO) { YtRepo.info(url) }
            } catch (e: Exception) {
                infoError = friendlyError(e)
            }
        }
    }

    fun playCountOf(url: String): Pair<Int, Long> {
        val st = Stats.snapshot(prefs).tracks.firstOrNull { it.url == url } ?: return 0 to 0L
        return st.count to st.ms
    }

    fun duplicateCount(id: String): Int {
        val p = playlists.firstOrNull { it.id == id } ?: return 0
        return p.tracks.size - p.tracks.distinctBy { it.url }.size
    }

    fun removeDuplicates(id: String) {
        val n = duplicateCount(id)
        if (n == 0) {
            toast("중복된 곡이 없어요")
            return
        }
        updatePlaylists(playlists.map { if (it.id == id) it.copy(tracks = it.tracks.distinctBy { t -> t.url }) else it })
        if (id == FAV_ID) PlaybackEvents.favChangedByUi.tryEmit(Unit)
        toast("중복된 곡 ${n}개를 정리했어요")
    }

    fun updateAutoplayRelated(v: Boolean) { autoplayRelated = v; putBool("autoplay_related", v) }
    fun updateCleanTitles(v: Boolean) { cleanTitles = v; TitleClean.on = v; putBool("clean_titles", v) }

    fun abStep() {
        toast(AbLoop.step(playingUrl, controller?.currentPosition ?: positionMs))
    }

    fun handleSharedText(text: String) {
        if (text.contains("playlist://import")) { importShared(text); return }
        val u = extractUrl(text)
        when {
            u != null && listIdOf(u) != null -> addPlaylist(u)
            u != null && videoIdOf(u) != null -> openVideo(u)
            else -> toast("유튜브 플레이리스트나 영상 링크를 보내 주세요")
        }
    }

    // ================= 링크로 이어 듣기 / 목록 공유 =================

    /** 영상 링크를 그 위치(t=)부터 바로 재생 (PC에서 넘긴 '이어 듣기' 링크도 이걸로) */
    fun openVideo(link: String) {
        val id = videoIdOf(link) ?: return
        val startMs = startTimeOf(link)
        toast("링크의 곡을 불러오는 중…")
        viewModelScope.launch {
            val t = withContext(Dispatchers.IO) {
                runCatching { YtRepo.trackOf("https://www.youtube.com/watch?v=$id") }.getOrNull()
            }
            val c = controller
            if (t == null || c == null) { toast("영상을 불러오지 못했어요"); return@launch }
            c.setMediaItem(t.toMediaItem(SEARCH_PID), startMs)
            c.prepare()
            c.play()
            if (startMs > 0) toast("${fmtTime(startMs)}부터 이어서 들어요")
        }
    }

    /** 지금 곡을 지금 위치부터 여는 링크 (PC나 다른 기기에서 이어 듣기) */
    fun handoffLink(): String? {
        val id = videoIdOf(playingUrl) ?: return null
        val sec = ((controller?.currentPosition ?: positionMs) / 1000).coerceAtLeast(0)
        return "https://www.youtube.com/watch?v=$id&t=${sec}s"
    }

    /** 목록 공유 링크: 유튜브 목록은 원래 주소, 직접 만든 목록은 곡 아이디를 담은 링크 */
    fun shareLinkOf(p: Playlist): String {
        if (p.url.isNotBlank()) return p.url
        val ids = p.tracks.mapNotNull { videoIdOf(it.url) }.distinct().take(200)
        return "playlist://import?n=" + Uri.encode(p.name) + "&v=" + ids.joinToString(",")
    }

    /** 공유받은 목록 가져오기: 먼저 빈 칸으로 만들고, 곡 정보를 차례로 채워요 */
    fun importShared(text: String) {
        val link = Regex("""playlist://import\?\S+""").find(text)?.value ?: return
        val uri = Uri.parse(link)
        val name = uri.getQueryParameter("n")?.ifBlank { null } ?: "공유받은 플레이리스트"
        val ids = uri.getQueryParameter("v")?.split(",")?.filter { it.length == 11 }.orEmpty()
        if (ids.isEmpty()) { toast("링크에 곡이 없어요"); return }
        val id = Store.newId()
        val placeholders = ids.map { Track("https://www.youtube.com/watch?v=$it", "불러오는 중…", "", "https://i.ytimg.com/vi/$it/hqdefault.jpg", 0L) }
        updatePlaylists(playlists + Playlist(id, name, "", placeholders))
        toast("'$name' (${ids.size}곡)을 가져오는 중이에요")
        viewModelScope.launch {
            val filled = withContext(Dispatchers.IO) {
                placeholders.chunked(4).flatMap { chunk ->
                    chunk.map { t -> async { runCatching { YtRepo.trackOf(t.url) }.getOrNull() ?: t } }.awaitAll()
                }
            }
            updatePlaylists(playlists.map { if (it.id == id) it.copy(tracks = filled) else it })
            toast("'$name'을(를) 다 가져왔어요")
        }
    }

    fun addPlaylist(raw: String) {
        val found = extractUrl(raw) ?: raw.trim()
        if (found.isEmpty()) return
        val lid = listIdOf(found)
        val u = if (lid != null) "https://www.youtube.com/playlist?list=$lid" else found
        playlists.firstOrNull { it.url.isNotBlank() && (it.url == u || (lid != null && listIdOf(it.url) == lid)) }
            ?.let {
                select(it.id)
                toast("이미 추가된 플레이리스트예요")
                return
            }
        loading = true
        clearError()
        viewModelScope.launch {
            try {
                val (name, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(u) }
                val p = Playlist(
                    id = Store.newId(),
                    name = name.ifBlank { "플레이리스트 ${playlists.size}" },
                    url = u,
                    tracks = list
                )
                updatePlaylists(playlists + p)
                select(p.id)
                toast("'${p.name}'을(를) 추가했어요")
            } catch (e: Exception) {
                showError("추가하지 못했어요. " + friendlyError(e)) { addPlaylist(u) }
            }
            loading = false
        }
    }

    fun createLocalPlaylist(name: String, first: Track? = null): String {
        val p = Playlist(Store.newId(), name.trim().ifBlank { "새 플레이리스트" }, "", listOfNotNull(first))
        updatePlaylists(playlists + p)
        return p.id
    }

    fun refreshPlaylist(id: String = selectedId, quiet: Boolean = false) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        if (p.url.isBlank()) return
        loading = true
        if (!quiet) clearError()
        viewModelScope.launch {
            try {
                val (_, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(p.url) }
                // 유튜브 원본 + 내가 넣은 곡 - 내가 뺀 곡
                updatePlaylists(playlists.map {
                    if (it.id == id) {
                        val urls = list.map { t -> t.url }.toSet()
                        it.copy(tracks = list.filter { t -> t.url !in it.hidden } + it.added.filter { t -> t.url !in urls })
                    } else it
                })
                if (!quiet) toast("목록을 새로 불러왔어요")
            } catch (e: Exception) {
                if (!(quiet && p.tracks.isNotEmpty())) {
                    showError(friendlyError(e)) { refreshPlaylist(id) }
                }
            }
            loading = false
        }
    }

    fun renamePlaylist(id: String, name: String) {
        updatePlaylists(playlists.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it })
    }

    fun deletePlaylist(id: String) {
        if (id == FAV_ID) return
        PinnedDownloader.cancel(id)
        updatePlaylists(playlists.filterNot { it.id == id })
        if (selectedId == id) select((playlists.firstOrNull { it.id != FAV_ID } ?: playlists.first()).id)
    }

    /** 재생 중인 곡이나 목록의 곡을 Track으로 찾기 */
    private fun findTrack(url: String): Track? {
        for (p in playlists) p.tracks.firstOrNull { it.url == url }?.let { return it }
        return null
    }

    fun toggleFavorite(t: Track) {
        val fav = playlists.first { it.id == FAV_ID }
        val on = fav.tracks.any { it.url == t.url }
        val newTracks = if (on) fav.tracks.filterNot { it.url == t.url } else listOf(t) + fav.tracks
        updatePlaylists(playlists.map { if (it.id == FAV_ID) it.copy(tracks = newTracks) else it })
        PlaybackEvents.favChangedByUi.tryEmit(Unit)
        toast(if (on) "좋아요를 취소했어요" else "좋아요에 추가했어요")
        if (!on) maybeSaveFavs()
    }


    fun toggleFavoriteCurrent() {
        if (playingUrl.isEmpty()) return
        val t = findTrack(playingUrl)
            ?: Track(playingUrl, nowTitle, nowArtist, nowArt, durationMs / 1000)
        toggleFavorite(t)
    }

    fun copyTo(t: Track, targetId: String) {
        val target = playlists.firstOrNull { it.id == targetId } ?: return
        if (target.tracks.any { it.url == t.url }) {
            toast("'${target.name}'에 이미 있는 곡이에요")
            return
        }
        updatePlaylists(playlists.map {
            if (it.id != targetId) it
            else if (it.url.isBlank()) it.copy(tracks = it.tracks + t)
            else it.copy(tracks = it.tracks + t, added = (it.added + t).distinctBy { a -> a.url }, hidden = it.hidden - t.url)
        })
        toast("'${if (targetId == FAV_ID) "좋아요" else target.name}'에 추가했어요")
    }

    fun removeFromPlaylist(pid: String, index: Int) {
        updatePlaylists(playlists.map {
            if (it.id == pid && index in it.tracks.indices) {
                val gone = it.tracks[index].url
                val rest = it.tracks.filterIndexed { i, _ -> i != index }
                if (it.url.isBlank()) it.copy(tracks = rest)
                else it.copy(tracks = rest, added = it.added.filter { a -> a.url != gone }, hidden = it.hidden + gone)
            } else it
        })
    }

    // ================= 오프라인 저장 =================
    fun startOffline(id: String) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        val app = getApplication<Application>()
        toast("'${if (p.id == FAV_ID) "좋아요" else p.name}' 오프라인 저장을 시작해요. 앱을 닫아도 계속 받아요")
        PinnedDownloader.start(app, p) { failed ->
            toast(if (failed == 0) "'${p.name}' 저장 완료" else "'${p.name}' 저장 완료 (${failed}곡 실패)")
            viewModelScope.launch { refreshCacheInfo() }
        }
        // 앱을 닫아도 계속 받도록 (알림에 진행률)
        DownloadService.kick(app)
    }

    // ---------- 좋아요 곡 자동 저장 (Wi-Fi일 때) ----------
    var autoSaveFav by mutableStateOf(prefs.getBoolean("auto_save_fav", false))
        private set
    private var favSavePending = false
    fun updateAutoSaveFav(v: Boolean) {
        autoSaveFav = v
        putBool("auto_save_fav", v)
        if (v) maybeSaveFavs()
    }

    private fun isUnmetered(): Boolean {
        val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    /** 좋아요에 새로 담긴 곡을 Wi-Fi에서 조용히 받아둬요 (지금 모바일 데이터면 Wi-Fi 연결될 때) */
    fun maybeSaveFavs() {
        if (!autoSaveFav) return
        val fav = playlists.firstOrNull { it.id == FAV_ID } ?: return
        if (fav.tracks.isEmpty() || fav.tracks.all { it.url in pinnedUrls }) return
        if (!isUnmetered()) { favSavePending = true; return }
        favSavePending = false
        if (PinnedDownloader.progress.containsKey(FAV_ID)) return
        val app = getApplication<Application>()
        PinnedDownloader.start(app, fav) { viewModelScope.launch { refreshCacheInfo() } }
        DownloadService.kick(app)
    }

    fun cancelOffline(id: String) {
        PinnedDownloader.cancel(id)
        toast("오프라인 저장을 멈췄어요")
    }

    fun removeOffline(id: String) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        PinnedDownloader.cancel(id)
        val app = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CacheProvider.removePinned(app, p.tracks.map { it.url }) }
            refreshCacheInfo()
            toast("저장된 곡을 지웠어요")
        }
    }

    // ================= 재생 제어 =================
    fun playFrom(index: Int) {
        navDir = 1
        val c = controller ?: return
        val pl = current ?: return
        val list = pl.tracks
        if (list.isEmpty() || index !in list.indices) return
        val sameQueue = c.mediaItemCount == list.size &&
            (0 until c.mediaItemCount).all { c.getMediaItemAt(it).mediaId == mediaIdOf(pl.id, list[it].url) }
        if (sameQueue) c.seekTo(index, 0L)
        else c.setMediaItems(list.map { it.toMediaItem(pl.id) }, index, 0L)
        c.prepare()
        c.play()
    }

    fun playAll() = playFrom(0)

    fun playIn(pid: String, index: Int) {
        if (selectedId != pid) select(pid)
        playFrom(index)
    }

    fun playAllIn(pid: String) = playIn(pid, 0)

    fun shuffleIn(pid: String) {
        if (selectedId != pid) select(pid)
        playShuffled()
    }

    /** 누를 때마다 완전히 새로운 무작위 순서 (서비스가 셔플을 켜는 순간 새로 섞어요) */
    fun playShuffled() {
        if (tracks.isEmpty()) return
        val c = controller ?: return
        c.shuffleModeEnabled = false
        playFrom(tracks.indices.random())
        c.shuffleModeEnabled = true
    }

    fun playNext(t: Track, pid: String) {
        val c = controller ?: return
        val item = t.toMediaItem(pid)
        if (c.mediaItemCount == 0) {
            c.setMediaItem(item)
            c.prepare()
            c.play()
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, item)
        }
        toast(if (c.shuffleModeEnabled) "대기열에 추가했어요 (셔플 중이라 순서는 섞여요)" else "다음 곡으로 넣었어요")
    }

    fun addToQueue(t: Track, pid: String) {
        val c = controller ?: return
        val item = t.toMediaItem(pid)
        if (c.mediaItemCount == 0) {
            c.setMediaItem(item)
            c.prepare()
            c.play()
        } else {
            c.addMediaItem(item)
        }
        toast("대기열 맨 뒤에 추가했어요")
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
            return
        }
        if (c.mediaItemCount == 0) {
            if (tracks.isNotEmpty()) playFrom(0)
            return
        }
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
        if (c.playbackState == Player.STATE_ENDED) c.seekTo(c.currentMediaItemIndex, 0L)
        c.play()
    }

    /** 곡이 바뀐 방향 (1 다음, -1 이전): 제목이 아트와 같은 방향으로 밀려 들어오게 */
    var navDir by mutableIntStateOf(1)
    fun next() { navDir = 1; controller?.seekToNextMediaItem() }
    fun previous() { navDir = -1; controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) {
        controller?.seekTo(ms)
        positionMs = ms
        positionAt = SystemClock.elapsedRealtime()
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun updateSpeed(v: Float) {
        controller?.setPlaybackParameters(PlaybackParameters(v, SoundFx.pitchFactor))
        speed = v
        prefs.edit().putFloat("speed", v).apply()
    }

    fun queuePlay(index: Int) {
        val c = controller ?: return
        if (index !in 0 until c.mediaItemCount) return
        c.seekTo(index, 0L)
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
        c.play()
    }

    fun queueRemove(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) c.removeMediaItem(index)
    }

    fun queueMove(from: Int, to: Int) {
        val c = controller ?: return
        val n = c.mediaItemCount
        if (from in 0 until n && to in 0 until n) c.moveMediaItem(from, to)
    }

    // ================= 캐시 =================
    suspend fun refreshCacheInfo() {
        val app = getApplication<Application>()
        val list = tracks
        val r = withContext(Dispatchers.Default) {
            val auto = CacheProvider.get(app)
            val pin = CacheProvider.getPinned(app)
            val a = list.filter { CacheProvider.isFullyCached(auto, it.url) }.map { it.url }.toSet()
            val b = list.filter { CacheProvider.isFullyCached(pin, it.url) }.map { it.url }.toSet()
            listOf(a, b, auto.cacheSpace, pin.cacheSpace)
        }
        @Suppress("UNCHECKED_CAST")
        cachedUrls = r[0] as Set<String>
        @Suppress("UNCHECKED_CAST")
        pinnedUrls = r[1] as Set<String>
        cacheBytes = r[2] as Long
        pinnedBytes = r[3] as Long
    }

    fun clearCache() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CacheProvider.clear(app) }
            refreshCacheInfo()
            toast("자동 캐시를 비웠어요")
        }
    }

    fun clearPinned() {
        val app = getApplication<Application>()
        PinnedDownloader.progress.keys.toList().forEach { PinnedDownloader.cancel(it) }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CacheProvider.clearPinned(app) }
            refreshCacheInfo()
            toast("오프라인 저장 곡을 모두 지웠어요")
        }
    }

    // ================= 백업 =================
    fun exportTo(uri: Uri) {
        val app = getApplication<Application>()
        val text = Store.exportJson(playlists)
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val out = app.contentResolver.openOutputStream(uri) ?: throw IOException("파일 열기 실패")
                    out.use { it.write(text.toByteArray()) }
                }
                toast("백업 파일을 저장했어요")
            } catch (e: Exception) {
                toast("백업하지 못했어요")
            }
        }
    }

    fun importFrom(uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val input = app.contentResolver.openInputStream(uri) ?: throw IOException("파일 열기 실패")
                    input.use { it.readBytes().toString(Charsets.UTF_8) }
                }
                val incoming = Store.parseExport(text)
                var list = playlists
                var added = 0
                for (p in incoming) {
                    if (p.id == FAV_ID) {
                        val fav = list.first { it.id == FAV_ID }
                        val merged = fav.tracks + p.tracks.filter { t -> fav.tracks.none { it.url == t.url } }
                        list = list.map { if (it.id == FAV_ID) it.copy(tracks = merged) else it }
                        continue
                    }
                    val lid = listIdOf(p.url)
                    if (lid != null && list.any { listIdOf(it.url) == lid }) continue
                    list = list + p.copy(id = Store.newId())
                    added++
                }
                updatePlaylists(list)
                toast("플레이리스트 ${added}개를 가져왔어요")
            } catch (e: Exception) {
                toast("백업 파일을 읽지 못했어요")
            }
        }
    }

    // ================= 설정 =================
    private fun putBool(k: String, v: Boolean) = prefs.edit().putBoolean(k, v).apply()

    fun updateThemeMode(v: Int) { themeMode = v; prefs.edit().putInt("theme_mode", v).apply() }

    fun updateNight(start: Int, end: Int) {
        nightStart = (start + 24) % 24
        nightEnd = (end + 24) % 24
        prefs.edit().putInt("night_start", nightStart).putInt("night_end", nightEnd).apply()
    }

    fun updateAccent(v: Int) {
        accent = v
        prefs.edit().putInt("accent", v).apply()
        if (dynamicColor) updateDynamic(false) // 색을 직접 고르면 배경화면 색상은 끔
    }

    fun updateDynamic(v: Boolean) { dynamicColor = v; putBool("dynamic", v) }
    fun updateGlass(v: Boolean) { glass = v; putBool("glass", v) }
    fun updateArtColor(v: Boolean) { useArtColor = v; putBool("art_color", v) }
    fun updateHaptics(v: Boolean) { haptics = v; putBool("haptics", v) }
    fun updateOneHand(v: Boolean) { oneHand = v; putBool("one_hand", v) }
    fun updateResume(v: Boolean) { resumeEnabled = v; putBool("resume", v) }
    fun updatePrefetch(v: Boolean) { prefetch = v; putBool("prefetch", v) }
    fun updatePrefetchWifi(v: Boolean) { prefetchWifi = v; putBool("prefetch_wifi", v) }

    fun updateFontScale(v: Float) { fontScale = v; prefs.edit().putFloat("font_scale", v).apply() }

    fun updateCacheMb(v: Int) {
        cacheMb = v
        prefs.edit().putInt("cache_mb", v).apply()
        toast("앱을 완전히 껐다 켜면 적용돼요")
    }

    fun updateLowQuality(v: Boolean) { lowQuality = v; putBool("low_quality", v) }
    fun updateSkipOfftopic(v: Boolean) { skipOfftopic = v; putBool("skip_offtopic", v) }
    fun updateAutoPlayConnect(v: Boolean) { autoPlayConnect = v; putBool("auto_play_connect", v) }
    fun updateCheckUpdates(v: Boolean) { checkUpdates = v; putBool("check_updates", v) }
    fun updateLongResume(v: Boolean) { longResume = v; putBool("long_resume", v) }
    fun updateShakeSkip(v: Boolean) { shakeSkip = v; putBool("shake_skip", v) }
    fun updateFadeMs(v: Int) { fadeMs = v; prefs.edit().putInt("fade_ms", v).apply() }

    fun finishOnboarding() { onboarded = true; putBool("onboarded", true) }
    fun showOnboardingAgain() { onboarded = false; putBool("onboarded", false) }

    override fun onCleared() {
        runCatching { cm?.unregisterNetworkCallback(netCb) }
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
