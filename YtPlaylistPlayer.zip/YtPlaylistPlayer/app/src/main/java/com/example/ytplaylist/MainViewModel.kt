package com.example.ytplaylist

import android.app.Application
import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("yt", Context.MODE_PRIVATE)

    // ----- 플레이리스트 여러 개 (목록은 저장해 두어 오프라인에서도 표시) -----
    var playlists by mutableStateOf(loadPlaylists())
    var selectedId by mutableStateOf(prefs.getString("selected", "") ?: "")
    val current: Playlist? get() = playlists.firstOrNull { it.id == selectedId } ?: playlists.firstOrNull()
    val tracks: List<Track> get() = current?.tracks ?: emptyList()
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    // ----- 재생 상태 (재생 중인 곡 정보는 플레이어에서 직접 읽음) -----
    var currentIndex by mutableIntStateOf(-1)
    var playingPid by mutableStateOf("")
    var nowTitle by mutableStateOf("")
    var nowArtist by mutableStateOf("")
    var nowArt by mutableStateOf<String?>(null)
    var isPlaying by mutableStateOf(false)
    var shuffle by mutableStateOf(false)
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_ALL)
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)

    // ----- 캐시 -----
    var cachedUrls by mutableStateOf<Set<String>>(emptySet())
    var cacheBytes by mutableLongStateOf(0L)

    // ----- 설정 -----
    var themeMode by mutableIntStateOf(prefs.getInt("theme_mode", 0)) // 0 시스템, 1 라이트, 2 다크
    var accent by mutableIntStateOf(prefs.getInt("accent", 0))
    var dynamicColor by mutableStateOf(prefs.getBoolean("dynamic", false))
    var glass by mutableStateOf(prefs.getBoolean("glass", true))

    private var controller: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    init {
        selectedId = current?.id ?: ""
        persist()

        val app2 = getApplication<Application>()
        val token = SessionToken(app2, ComponentName(app2, PlaybackService::class.java))
        val future = MediaController.Builder(app2, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            sync(c)
        }, ContextCompat.getMainExecutor(app2))

        if (playlists.isNotEmpty()) refreshPlaylist()
    }

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        currentIndex = if (p.mediaItemCount > 0) p.currentMediaItemIndex else -1
        durationMs = p.duration.takeIf { it != C.TIME_UNSET } ?: 0L
        val md = p.mediaMetadata
        nowTitle = md.title?.toString() ?: ""
        nowArtist = md.artist?.toString() ?: ""
        nowArt = md.artworkUri?.toString()
        playingPid = p.currentMediaItem?.mediaMetadata?.extras?.getString("pid") ?: ""
    }

    fun refreshPosition() {
        controller?.let { positionMs = it.currentPosition }
    }

    // ---------------- 플레이리스트 관리 ----------------
    fun select(id: String) {
        selectedId = id
        persist()
    }

    fun addPlaylist(raw: String) {
        val u = raw.trim()
        if (u.isEmpty()) return
        playlists.firstOrNull { it.url == u }?.let {
            select(it.id)
            refreshPlaylist(it.id)
            return
        }
        loading = true
        error = null
        viewModelScope.launch {
            try {
                val (name, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(u) }
                val p = Playlist(
                    id = newId(),
                    name = name.ifBlank { "플레이리스트 ${playlists.size + 1}" },
                    url = u,
                    tracks = list
                )
                playlists = playlists + p
                selectedId = p.id
                persist()
            } catch (e: Exception) {
                error = "추가 실패: ${e.message ?: e.javaClass.simpleName}"
            }
            loading = false
        }
    }

    fun refreshPlaylist(id: String = selectedId) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        loading = true
        error = null
        viewModelScope.launch {
            try {
                val (_, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(p.url) }
                playlists = playlists.map { if (it.id == id) it.copy(tracks = list) else it }
                persist()
            } catch (e: Exception) {
                error = if (p.tracks.isNotEmpty()) "오프라인이거나 불러오지 못해 저장된 목록을 보여주고 있어요"
                else "불러오기 실패: ${e.message ?: e.javaClass.simpleName}"
            }
            loading = false
        }
    }

    fun renamePlaylist(id: String, name: String) {
        playlists = playlists.map {
            if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it
        }
        persist()
    }

    fun deletePlaylist(id: String) {
        playlists = playlists.filterNot { it.id == id }
        if (selectedId == id) selectedId = playlists.firstOrNull()?.id ?: ""
        persist()
    }

    private fun newId(): String = UUID.randomUUID().toString().take(8)

    private fun persist() {
        val arr = JSONArray()
        playlists.forEach { p ->
            val ta = JSONArray()
            p.tracks.forEach { ta.put(trackToJson(it)) }
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("url", p.url).put("tracks", ta))
        }
        prefs.edit().putString("playlists_v2", arr.toString()).putString("selected", selectedId).apply()
    }

    private fun trackToJson(t: Track): JSONObject =
        JSONObject().put("u", t.url).put("t", t.title).put("a", t.artist)
            .put("i", t.thumb ?: "").put("d", t.durationSec)

    private fun parseTracks(arr: JSONArray): List<Track> = List(arr.length()) {
        val o = arr.getJSONObject(it)
        Track(
            url = o.getString("u"),
            title = o.getString("t"),
            artist = o.optString("a"),
            thumb = o.optString("i").ifBlank { null },
            durationSec = o.optLong("d")
        )
    }

    private fun loadPlaylists(): List<Playlist> {
        val raw = prefs.getString("playlists_v2", null)
        if (raw != null) {
            return runCatching {
                val arr = JSONArray(raw)
                List(arr.length()) {
                    val o = arr.getJSONObject(it)
                    Playlist(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        url = o.getString("url"),
                        tracks = parseTracks(o.getJSONArray("tracks"))
                    )
                }
            }.getOrDefault(emptyList())
        }
        // 이전 버전(플레이리스트 1개)에서 옮겨오기
        val oldUrl = prefs.getString("url", "") ?: ""
        if (oldUrl.isBlank()) return emptyList()
        val oldTracks = runCatching { parseTracks(JSONArray(prefs.getString("tracks", "[]"))) }
            .getOrDefault(emptyList())
        val oldName = (prefs.getString("title", "") ?: "").ifBlank { "내 플레이리스트" }
        return listOf(Playlist(newId(), oldName, oldUrl, oldTracks))
    }

    // ---------------- 재생 제어 ----------------
    fun playFrom(index: Int) {
        val c = controller ?: return
        val pl = current ?: return
        val list = pl.tracks
        if (list.isEmpty()) return
        val sameQueue = c.mediaItemCount == list.size &&
            c.getMediaItemAt(0).mediaMetadata.extras?.getString("pid") == pl.id &&
            (0 until c.mediaItemCount).all { c.getMediaItemAt(it).mediaId == list[it].url }
        if (sameQueue) c.seekTo(index, 0L)
        else c.setMediaItems(list.map { it.toMediaItem(pl.id) }, index, 0L)
        c.prepare()
        c.play()
    }

    fun playShuffled() {
        if (tracks.isEmpty()) return
        controller?.shuffleModeEnabled = true
        playFrom(tracks.indices.random())
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms) }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    // ---------------- 캐시 ----------------
    suspend fun refreshCacheInfo() {
        val app = getApplication<Application>()
        val list = tracks
        val (set, bytes) = withContext(Dispatchers.Default) {
            val c = CacheProvider.get(app)
            list.filter { CacheProvider.isFullyCached(c, it.url) }.map { it.url }.toSet() to c.cacheSpace
        }
        cachedUrls = set
        cacheBytes = bytes
    }

    fun clearCache() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CacheProvider.clear(app) }
            refreshCacheInfo()
        }
    }

    // ---------------- 설정 ----------------
    fun updateThemeMode(v: Int) { themeMode = v; prefs.edit().putInt("theme_mode", v).apply() }

    fun updateAccent(v: Int) {
        accent = v
        prefs.edit().putInt("accent", v).apply()
        if (dynamicColor) updateDynamic(false) // 색을 직접 고르면 배경화면 색상은 끔
    }

    fun updateDynamic(v: Boolean) { dynamicColor = v; prefs.edit().putBoolean("dynamic", v).apply() }
    fun updateGlass(v: Boolean) { glass = v; prefs.edit().putBoolean("glass", v).apply() }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
