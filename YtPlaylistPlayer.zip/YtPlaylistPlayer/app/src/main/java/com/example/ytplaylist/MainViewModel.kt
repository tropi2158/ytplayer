package com.example.ytplaylist

import android.app.Application
import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("yt", Context.MODE_PRIVATE)

    // ----- 플레이리스트 (마지막 목록은 저장해두어 오프라인에서도 표시) -----
    var url by mutableStateOf(prefs.getString("url", "") ?: "")
    var title by mutableStateOf(prefs.getString("title", "") ?: "")
    var tracks by mutableStateOf(loadSavedTracks())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    // ----- 재생 상태 -----
    var currentIndex by mutableIntStateOf(-1)
    var isPlaying by mutableStateOf(false)
    var shuffle by mutableStateOf(false)
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_ALL)
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)

    // ----- 캐시 -----
    var cachedUrls by mutableStateOf<Set<String>>(emptySet())
    var cacheBytes by mutableLongStateOf(0L)

    // ----- 설정 -----
    var themeMode by mutableIntStateOf(prefs.getInt("theme_mode", 0)) // 0 시스템, 1 라이트, 2 다크
    var accent by mutableIntStateOf(prefs.getInt("accent", 0))
    var dynamicColor by mutableStateOf(prefs.getBoolean("dynamic", false))

    private var controller: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    init {
        val app2 = getApplication<Application>()
        val token = SessionToken(app2, ComponentName(app2, PlaybackService::class.java))
        val future = MediaController.Builder(app2, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            sync(c)
        }, ContextCompat.getMainExecutor(app2))

        if (url.isNotBlank()) load()
    }

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        currentIndex = if (p.mediaItemCount > 0) p.currentMediaItemIndex else -1
        durationMs = p.duration.takeIf { it != C.TIME_UNSET } ?: 0L
    }

    fun refreshPosition() {
        controller?.let { positionMs = it.currentPosition }
    }

    // ---------------- 플레이리스트 ----------------
    fun load() {
        val u = url.trim()
        if (u.isEmpty()) return
        loading = true
        error = null
        viewModelScope.launch {
            try {
                val (name, list) = withContext(Dispatchers.IO) { YtRepo.loadPlaylist(u) }
                title = name
                tracks = list
                saveTracks(u)
            } catch (e: Exception) {
                val hasSaved = tracks.isNotEmpty() && prefs.getString("tracks_url", "") == u
                error = if (hasSaved) "오프라인이거나 불러오지 못해 저장된 목록을 보여주고 있어요"
                else "불러오기 실패: ${e.message ?: e.javaClass.simpleName}"
            }
            loading = false
        }
    }

    private fun saveTracks(u: String) {
        val arr = JSONArray()
        tracks.forEach {
            arr.put(
                JSONObject()
                    .put("u", it.url).put("t", it.title).put("a", it.artist)
                    .put("i", it.thumb ?: "").put("d", it.durationSec)
            )
        }
        prefs.edit()
            .putString("url", u).putString("title", title)
            .putString("tracks", arr.toString()).putString("tracks_url", u)
            .apply()
    }

    private fun loadSavedTracks(): List<Track> = runCatching {
        val arr = JSONArray(prefs.getString("tracks", "[]"))
        List(arr.length()) {
            val o = arr.getJSONObject(it)
            Track(
                url = o.getString("u"),
                title = o.getString("t"),
                artist = o.optString("a"),
                thumb = o.optString("i").ifBlank { null },
                durationSec = o.optLong("d")
            )
        }
    }.getOrDefault(emptyList())

    // ---------------- 재생 제어 ----------------
    fun playFrom(index: Int) {
        val c = controller ?: return
        if (tracks.isEmpty()) return
        val sameQueue = c.mediaItemCount == tracks.size &&
            (0 until c.mediaItemCount).all { c.getMediaItemAt(it).mediaId == tracks[it].url }
        if (sameQueue) c.seekTo(index, 0L)
        else c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun playShuffled() {
        if (tracks.isEmpty()) return
        controller?.shuffleModeEnabled = true
        playFrom(tracks.indices.random())
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms) }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    // ---------------- 캐시 ----------------
    suspend fun refreshCacheInfo() {
        val app = getApplication<Application>()
        val list = tracks
        val (set, bytes) = withContext(Dispatchers.Default) {
            val c = CacheProvider.get(app)
            list.filter { CacheProvider.isFullyCached(c, it.url) }.map { it.url }.toSet() to c.cacheSpace
        }
        cachedUrls = set
        cacheBytes = bytes
    }

    fun clearCache() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CacheProvider.clear(app) }
            refreshCacheInfo()
        }
    }

    // ---------------- 설정 ----------------
    fun updateThemeMode(v: Int) { themeMode = v; prefs.edit().putInt("theme_mode", v).apply() }
    fun updateAccent(v: Int) { accent = v; prefs.edit().putInt("accent", v).apply() }
    fun updateDynamic(v: Boolean) { dynamicColor = v; prefs.edit().putBoolean("dynamic", v).apply() }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
