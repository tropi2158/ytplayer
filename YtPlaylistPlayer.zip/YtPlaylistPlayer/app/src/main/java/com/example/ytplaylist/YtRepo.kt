package com.example.ytplaylist

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.io.IOException

data class Track(
    val url: String,
    val title: String,
    val artist: String,
    val thumb: String?,
    val durationSec: Long
) {
    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(url)
        .setUri(url) // 실제 재생 시 PlaybackService의 Resolver가 오디오 스트림 URL로 교체
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setArtworkUri(thumb?.let { android.net.Uri.parse(it) })
                .build()
        )
        .build()
}

object YtRepo {
    private const val MAX_TRACKS = 500

    /** 플레이리스트 URL -> (제목, 트랙 목록). 네트워크 작업이므로 IO 스레드에서 호출. */
    fun loadPlaylist(url: String): Pair<String, List<Track>> {
        val service = ServiceList.YouTube
        val info = PlaylistInfo.getInfo(service, url)
        val items = info.relatedItems.toMutableList()
        var page = info.nextPage
        while (page != null && items.size < MAX_TRACKS) {
            val more = PlaylistInfo.getMoreItems(service, url, page)
            items += more.items
            page = more.nextPage
        }
        val tracks = items
            .filter { it.url.isNotBlank() }
            .map {
                Track(
                    url = it.url,
                    title = it.name,
                    artist = it.uploaderName ?: "",
                    thumb = it.thumbnails.lastOrNull()?.url,
                    durationSec = it.duration
                )
            }
        return info.name to tracks
    }

    /** 영상 URL -> 재생 가능한 오디오 스트림 URL (몇 시간 뒤 만료됨). */
    fun resolveAudioUrl(videoUrl: String): String {
        val info = StreamInfo.getInfo(ServiceList.YouTube, videoUrl)
        val candidates = info.audioStreams.filter {
            it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl
        }
        val best = candidates.filter { it.format == MediaFormat.M4A }.maxByOrNull { it.averageBitrate }
            ?: candidates.maxByOrNull { it.averageBitrate }
            ?: throw IOException("사용 가능한 오디오 스트림이 없습니다")
        return best.content
    }
}
