package com.example.ytplaylist

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException

data class Track(
    val url: String,
    val title: String,
    val artist: String,
    val thumb: String?,
    val durationSec: Long
) {
    /** pid = 이 곡이 속한 플레이리스트 id. mediaId에 "pid|url" 형태로 담아요 */
    fun toMediaItem(pid: String): MediaItem = MediaItem.Builder()
        .setMediaId(mediaIdOf(pid, url))
        .setUri(url) // 실제 재생 시 Resolver가 오디오 스트림 URL로 교체
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setArtworkUri(thumb?.let { android.net.Uri.parse(it) })
                .build()
        )
        .build()
}

data class Playlist(
    val id: String,
    val name: String,
    val url: String, // 비어 있으면 앱 안에서 만든 플레이리스트
    val tracks: List<Track>,
    val tag: String = "",
    /** 유튜브에서 가져온 목록에 내가 직접 넣은 곡 (새로고침해도 유지) */
    val added: List<Track> = emptyList(),
    /** 유튜브에서 가져온 목록에서 내가 뺀 곡 (새로고침해도 다시 안 나타남) */
    val hidden: Set<String> = emptySet()
)

/** 검색 결과로 재생할 때 쓰는 가상 플레이리스트 id */
const val SEARCH_PID = "__search__"

/** 비슷한 곡 라디오로 이어 붙인 곡의 가상 플레이리스트 id */
const val RADIO_PID = "__radio__"
const val AUTO_TOP = "__auto_top__"
const val AUTO_NEW = "__auto_new__"
const val AUTO_OLD = "__auto_old__"
fun isAutoId(id: String) = id.startsWith("__auto_")

/** 곡 정보 */
data class TrackInfo(
    val uploader: String,
    val views: Long,
    val likes: Long,
    val uploaded: String,
    val category: String,
    val description: String
)

fun mediaIdOf(pid: String, url: String): String = "$pid|$url"
fun pidOf(mediaId: String): String = if ('|' in mediaId) mediaId.substringBefore('|') else ""
fun urlOf(mediaId: String): String = mediaId.substringAfter('|')

/** 텍스트에서 링크 찾기 (플레이리스트 링크 우선) */
fun extractUrl(text: String): String? {
    val all = Regex("https?://\\S+").findAll(text).map { it.value.trimEnd('.', ',', ')') }.toList()
    return all.firstOrNull { it.contains("list=") } ?: all.firstOrNull()
}

fun listIdOf(url: String): String? =
    Regex("[?&]list=([A-Za-z0-9_-]+)").find(url)?.groupValues?.get(1)

object YtRepo {
    private const val MAX_TRACKS = 500

    /** 플레이리스트 URL -> (제목, 트랙 목록). 네트워크 작업이므로 IO 스레드에서 호출. */
    fun loadPlaylist(url: String): Pair<String, List<Track>> {
        val service = ServiceList.YouTube
        val info = PlaylistInfo.getInfo(service, url)
        val items = info.relatedItems.toMutableList()
        var page = info.nextPage
        while (page != null && items.size < MAX_TRACKS) {
            val more = PlaylistInfo.getMoreItems(service, url, page)
            items += more.items
            page = more.nextPage
        }
        val tracks = items
            .filter { it.url.isNotBlank() }
            .map {
                Track(
                    url = it.url,
                    title = it.name,
                    artist = it.uploaderName ?: "",
                    thumb = it.thumbnails.lastOrNull()?.url,
                    durationSec = it.duration
                )
            }
        return info.name to tracks
    }

    /** 이 곡과 비슷한 곡 (유튜브 추천 영상 중 1~15분 길이) */
    fun related(videoUrl: String): List<Track> {
        val info = StreamInfo.getInfo(ServiceList.YouTube, videoUrl)
        return info.relatedItems.filterIsInstance<StreamInfoItem>()
            .filter { it.url.isNotBlank() && it.duration in 60..900 }
            .map {
                Track(
                    url = it.url,
                    title = it.name,
                    artist = it.uploaderName ?: "",
                    thumb = it.thumbnails.lastOrNull()?.url,
                    durationSec = it.duration
                )
            }
    }

    fun info(videoUrl: String): TrackInfo {
        val i = StreamInfo.getInfo(ServiceList.YouTube, videoUrl)
        return TrackInfo(
            uploader = i.uploaderName ?: "",
            views = i.viewCount,
            likes = i.likeCount,
            uploaded = i.textualUploadDate ?: "",
            category = i.category ?: "",
            description = i.description?.content?.replace(Regex("<[^>]+>"), " ")?.replace(Regex("\\s+"), " ")?.trim()?.take(700) ?: ""
        )
    }

    /** 유튜브에서 영상 검색 */
    fun search(query: String): List<Track> {
        val svc = ServiceList.YouTube
        val handler = svc.searchQHFactory.fromQuery(query, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
        val info = SearchInfo.getInfo(svc, handler)
        return info.relatedItems.filterIsInstance<StreamInfoItem>()
            .filter { it.url.isNotBlank() }
            .map {
                Track(
                    url = it.url,
                    title = it.name,
                    artist = it.uploaderName ?: "",
                    thumb = it.thumbnails.lastOrNull()?.url,
                    durationSec = it.duration
                )
            }
    }

    /** 영상 URL -> 재생 가능한 오디오 스트림 URL (몇 시간 뒤 만료됨). */
    fun resolveAudioUrl(videoUrl: String, low: Boolean = false): String {
        val info = StreamInfo.getInfo(ServiceList.YouTube, videoUrl)
        val candidates = info.audioStreams.filter {
            it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl
        }
        val m4a = candidates.filter { it.format == MediaFormat.M4A }
        val best = if (low) {
            m4a.minByOrNull { it.averageBitrate } ?: candidates.minByOrNull { it.averageBitrate }
        } else {
            m4a.maxByOrNull { it.averageBitrate } ?: candidates.maxByOrNull { it.averageBitrate }
        }
            ?: throw IOException("사용 가능한 오디오 스트림이 없습니다")
        return best.content
    }
}
