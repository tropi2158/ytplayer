@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ytplaylist

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            YtTheme(vm) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    PlayerScreen(vm)
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(vm: MainViewModel) {
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { while (true) { vm.refreshPosition(); delay(500) } }
    LaunchedEffect(vm.tracks, vm.currentIndex) { vm.refreshCacheInfo() }
    LaunchedEffect(Unit) { while (true) { delay(5000); vm.refreshCacheInfo() } }

    var showPlayer by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val hasCurrent = vm.currentIndex in vm.tracks.indices

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { if (hasCurrent) MiniPlayer(vm) { showPlayer = true } }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LibraryMusic, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(
                    "YT Playlist",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "설정") }
            }

            OutlinedTextField(
                value = vm.url,
                onValueChange = { vm.url = it },
                label = { Text("유튜브 플레이리스트 URL") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                trailingIcon = {
                    if (vm.loading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                    else IconButton(onClick = vm::load) { Icon(Icons.Default.Refresh, "불러오기") }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )

            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { vm.playFrom(0) },
                    enabled = vm.tracks.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("전체 재생")
                }
                FilledTonalButton(
                    onClick = vm::playShuffled,
                    enabled = vm.tracks.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Shuffle, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("셔플 재생")
                }
            }

            vm.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
            }

            if (vm.tracks.isNotEmpty()) {
                if (vm.title.isNotBlank()) {
                    Text(
                        "${vm.title} · ${vm.tracks.size}곡",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("곡 검색") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "지우기") }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                )

                val shown = remember(vm.tracks, query) {
                    vm.tracks.withIndex().filter {
                        query.isBlank() ||
                            it.value.title.contains(query, ignoreCase = true) ||
                            it.value.artist.contains(query, ignoreCase = true)
                    }.toList()
                }
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 8.dp)) {
                    items(shown, key = { it.index }) { (i, t) ->
                        TrackRow(
                            t = t,
                            selected = i == vm.currentIndex,
                            playing = i == vm.currentIndex && vm.isPlaying,
                            cached = t.url in vm.cachedUrls
                        ) { vm.playFrom(i) }
                    }
                }
            } else if (!vm.loading) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        "플레이리스트 URL을 입력하고\n불러오기를 눌러주세요",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }

    if (showPlayer && hasCurrent) FullPlayerSheet(vm) { showPlayer = false }
    if (showSettings) SettingsSheet(vm) { showSettings = false }
}

@Composable
fun TrackRow(t: Track, selected: Boolean, playing: Boolean, cached: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = t.thumb,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
            )
            Text(
                t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (cached) {
            Icon(Icons.Default.DownloadDone, "캐시됨", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
        }
        if (playing) {
            Icon(Icons.Default.GraphicEq, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
        }
        Text(fmt(t.durationSec * 1000), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    val t = vm.tracks.getOrNull(vm.currentIndex) ?: return
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen)
    ) {
        Column(Modifier.navigationBarsPadding()) {
            LinearProgressIndicator(
                progress = {
                    if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
                },
                modifier = Modifier.fillMaxWidth().height(3.dp)
            )
            Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = t.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp))
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = vm::togglePlay) {
                    Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "재생/일시정지")
                }
                IconButton(onClick = vm::next) { Icon(Icons.Default.SkipNext, "다음") }
            }
        }
    }
}

@Composable
fun FullPlayerSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val t = vm.tracks.getOrNull(vm.currentIndex) ?: return
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var drag by remember { mutableStateOf<Float?>(null) }
    val max = maxOf(vm.durationMs, 1L).toFloat()

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AsyncImage(
                model = t.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.widthIn(max = 320.dp).fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(24.dp))
            )
            Spacer(Modifier.height(20.dp))
            Text(
                t.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Text(
                t.artist, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Slider(
                value = (drag ?: vm.positionMs.toFloat()).coerceIn(0f, max),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { vm.seek(it.toLong()) }; drag = null },
                valueRange = 0f..max
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt((drag ?: vm.positionMs.toFloat()).toLong()), style = MaterialTheme.typography.bodySmall)
                Text(fmt(vm.durationMs), style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::toggleShuffle) {
                    Icon(
                        Icons.Default.Shuffle, "셔플",
                        tint = if (vm.shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = vm::previous, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "이전", Modifier.size(32.dp))
                }
                FilledIconButton(onClick = vm::togglePlay, modifier = Modifier.size(72.dp)) {
                    Icon(
                        if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "재생/일시정지", Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = vm::next, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "다음", Modifier.size(32.dp))
                }
                IconButton(onClick = vm::cycleRepeat) {
                    Icon(
                        if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "반복",
                        tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val dynamicAvailable = Build.VERSION.SDK_INT >= 31
    val dynamicOn = vm.dynamicColor && dynamicAvailable

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier.fillMaxWidth().verticalScrollPadding(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("설정", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(8.dp))
            Text("테마", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("시스템", "라이트", "다크").forEachIndexed { i, label ->
                    FilterChip(
                        selected = vm.themeMode == i,
                        onClick = { vm.setThemeMode(i) },
                        label = { Text(label) }
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Text("강조 색상", style = MaterialTheme.typography.titleSmall)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ACCENTS.forEachIndexed { i, (_, color) ->
                    val selected = vm.accent == i
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (dynamicOn) color.copy(alpha = 0.35f) else color)
                            .then(
                                if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                else Modifier
                            )
                            .clickable { vm.setAccent(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) Icon(Icons.Default.Check, null, tint = Color.White)
                    }
                }
            }

            if (dynamicAvailable) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("배경화면 색상 사용", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "켜면 폰 배경화면에서 색을 가져와요 (강조 색상은 무시)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = vm.dynamicColor, onCheckedChange = vm::setDynamic)
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("오디오 캐시", style = MaterialTheme.typography.titleSmall)
            Text(
                "${mb(vm.cacheBytes)} / ${mb(CacheProvider.MAX_BYTES)} 사용 중 · 한 번 끝까지 들은 곡은 인터넷 없이 재생돼요",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = vm::clearCache) {
                Icon(Icons.Default.DeleteSweep, null, Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("캐시 비우기")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun Modifier.verticalScrollPadding(): Modifier = this.padding(horizontal = 24.dp)

private fun mb(bytes: Long): String = "%.0f MB".format(bytes / 1048576.0)

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
