@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ytplaylist

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            YtTheme(vm) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    PlayerScreen(vm)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** 유튜브 앱 '공유' 또는 링크 열기로 들어온 플레이리스트 추가 */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val text = when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i.dataString
            else -> null
        } ?: return
        vm.handleSharedText(text)
    }
}

private data class MenuTarget(val track: Track, val pid: String, val index: Int)

@Composable
fun PlayerScreen(vm: MainViewModel) {
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val askNotif: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { if (vm.onboarded) askNotif() }
    LaunchedEffect(Unit) { while (true) { vm.refreshPosition(); delay(500) } }
    LaunchedEffect(vm.selectedId, vm.playingUrl, vm.tracks.size) { vm.refreshCacheInfo() }
    LaunchedEffect(Unit) { while (true) { delay(5000); vm.refreshCacheInfo() } }

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.toasts.collect { snackbar.showSnackbar(it) } }

    var showQueue by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var showNewEmpty by remember { mutableStateOf(false) }
    var newWithTrack by remember { mutableStateOf<Track?>(null) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var menuTarget by remember { mutableStateOf<MenuTarget?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(vm.selectedId) { query = "" }

    val hasCurrent = vm.currentIndex >= 0
    val cur = vm.current

    val controls: @Composable () -> Unit = {
        PlaylistControls(
            vm,
            onAdd = { showAdd = true },
            onRename = { showRename = true },
            onDelete = { showDelete = true }
        )
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val expand = remember { Animatable(0f) }
        val scope = rememberCoroutineScope()
        val panelSpring = spring<Float>(dampingRatio = 0.86f, stiffness = 320f)

        // 손을 뗀 순간의 속도와 위치를 이어받아 펼치거나 접기
        val settle: (Float) -> Unit = { v ->
            scope.launch {
                val target = when {
                    v < -1200f -> 1f
                    v > 1200f -> 0f
                    expand.value > 0.5f -> 1f
                    else -> 0f
                }
                expand.animateTo(target, panelSpring, initialVelocity = -v / heightPx)
            }
        }
        val openPlayer: () -> Unit = { scope.launch { expand.animateTo(1f, panelSpring) } }
        val closePlayer: () -> Unit = { scope.launch { expand.animateTo(0f, panelSpring) } }
        LaunchedEffect(hasCurrent) { if (!hasCurrent) expand.snapTo(0f) }

        GlassBackground(vm.nowArt)

        Scaffold(
            // 플레이어가 펼쳐질수록 뒤 화면이 살짝 작아지고 흐려져요
            modifier = Modifier.graphicsLayer {
                val e = expand.value
                val sc = 1f - 0.06f * e
                scaleX = sc
                scaleY = sc
                alpha = 1f - 0.35f * e
            },
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                AnimatedVisibility(
                    visible = hasCurrent,
                    enter = slideInVertically(spring(dampingRatio = 0.8f, stiffness = 380f)) { it } + fadeIn(),
                    exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(180))
                ) {
                    Box(
                        Modifier
                            .navigationBarsPadding()
                            .padding(start = 12.dp, end = 12.dp, bottom = 8.dp)
                            .graphicsLayer {
                                val e = expand.value
                                alpha = (1f - e * 3f).coerceIn(0f, 1f)
                                translationY = -e * heightPx * 0.25f
                            }
                    ) {
                        MiniPlayer(
                            vm,
                            onOpen = openPlayer,
                            onVerticalDrag = { dy ->
                                scope.launch { expand.snapTo((expand.value - dy / heightPx).coerceIn(0f, 1f)) }
                            },
                            onVerticalEnd = settle
                        )
                    }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {
                // ----- 머리글 -----
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "YT Playlist",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    AnimatedVisibility(visible = !vm.online, enter = fadeIn(), exit = fadeOut()) {
                        GlassSurface(shape = CircleShape, tint = MaterialTheme.colorScheme.error) {
                            Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudOff, null, Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("오프라인", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                    if (hasCurrent) IconButton(onClick = { showQueue = true }) { Icon(Icons.Default.QueueMusic, "대기열") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "설정") }
                }

                if (!vm.oneHand) controls()

                // ----- 플레이리스트를 바꾸면 목록이 옆으로 미끄러지며 바뀌어요 -----
                AnimatedContent(
                    targetState = cur?.id ?: "",
                    modifier = Modifier.weight(1f),
                    transitionSpec = {
                        val from = vm.playlists.indexOfFirst { it.id == initialState }
                        val to = vm.playlists.indexOfFirst { it.id == targetState }
                        val dir = if (to >= from) 1 else -1
                        (slideInHorizontally(tween(360, easing = FastOutSlowInEasing)) { w -> w / 4 * dir } +
                            fadeIn(tween(300, delayMillis = 60))) togetherWith
                            (slideOutHorizontally(tween(300, easing = FastOutSlowInEasing)) { w -> -w / 4 * dir } +
                                fadeOut(tween(180)))
                    },
                    label = "playlist"
                ) { id ->
                    val pl = vm.playlists.firstOrNull { it.id == id }
                    Column(Modifier.fillMaxSize()) {
                        PlaylistBody(
                            vm = vm,
                            cur = pl,
                            query = query,
                            onQuery = { query = it },
                            onAdd = { showAdd = true },
                            onMenu = { t, pid, i -> menuTarget = MenuTarget(t, pid, i) }
                        )
                    }
                }

                if (vm.oneHand) controls()
            }
        }

        PlayerOverlay(
            vm = vm,
            expand = expand,
            heightPx = heightPx,
            onSettle = settle,
            onCollapse = closePlayer,
            onOpenQueue = { showQueue = true },
            onOpenEq = { showEq = true }
        )

        if (!vm.onboarded) {
            Onboarding {
                vm.finishOnboarding()
                askNotif()
            }
        }
    }

    // ----- 시트와 대화상자 -----
    if (showQueue) QueueSheet(vm) { showQueue = false }
    if (showEq) EqualizerSheet { showEq = false }
    if (showSettings) SettingsSheet(vm) { showSettings = false }
    menuTarget?.let { m ->
        TrackMenuSheet(
            vm, m.track, m.pid, m.index,
            onDismiss = { menuTarget = null },
            onNewPlaylist = { newWithTrack = it }
        )
    }
    if (showAdd) {
        AddPlaylistDialog(
            onDismiss = { showAdd = false },
            onAdd = vm::addPlaylist,
            onCreateEmpty = { showNewEmpty = true }
        )
    }
    if (showNewEmpty) {
        NameDialog("새 플레이리스트", "", "만들기", onDismiss = { showNewEmpty = false }) {
            vm.select(vm.createLocalPlaylist(it))
        }
    }
    newWithTrack?.let { t ->
        NameDialog("새 플레이리스트", "", "만들고 곡 넣기", onDismiss = { newWithTrack = null }) {
            vm.createLocalPlaylist(it, t)
        }
    }
    if (showRename && cur != null) {
        NameDialog("이름 바꾸기", cur.name, "확인", onDismiss = { showRename = false }) { vm.renamePlaylist(cur.id, it) }
    }
    if (showDelete && cur != null) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("플레이리스트 삭제") },
            text = { Text("'${cur.name}'을(를) 목록에서 삭제할까요? (유튜브의 원본은 그대로예요)") },
            confirmButton = {
                TextButton(onClick = { vm.deletePlaylist(cur.id); showDelete = false }) { Text("삭제") }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("취소") } }
        )
    }
}

/** 플레이리스트 칩 + 재생 버튼 줄 (한 손 모드에서는 화면 아래로 이동) */
@Composable
fun PlaylistControls(vm: MainViewModel, onAdd: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    val cur = vm.current
    var menuOpen by remember { mutableStateOf(false) }

    LazyRow(
        Modifier.padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(vm.playlists, key = { it.id }) { p ->
            Box(Modifier.animateItem()) {
                GlassChip(
                    if (p.id == FAV_ID) "좋아요" else p.name,
                    selected = p.id == cur?.id,
                    icon = if (p.id == FAV_ID) Icons.Default.Favorite else null
                ) { vm.select(p.id) }
            }
        }
        item(key = "__add__") { Box(Modifier.animateItem()) { GlassChip("추가", icon = Icons.Default.Add, onClick = onAdd) } }
    }

    if (cur == null) return
    val downloading = PinnedDownloader.progress.containsKey(cur.id)

    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlassSurface(
            modifier = Modifier.weight(1f).height(48.dp),
            shape = RoundedCornerShape(24.dp),
            tint = MaterialTheme.colorScheme.primary,
            onClick = vm::playAll
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayArrow, null, Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("전체 재생", fontWeight = FontWeight.SemiBold)
            }
        }
        GlassSurface(
            modifier = Modifier.weight(1f).height(48.dp),
            shape = RoundedCornerShape(24.dp),
            onClick = vm::playShuffled
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shuffle, null, Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("셔플 재생", fontWeight = FontWeight.SemiBold)
            }
        }
        Box {
            GlassSurface(
                modifier = Modifier.size(48.dp),
                shape = CircleShape,
                onClick = { menuOpen = true }
            ) { Icon(Icons.Default.MoreVert, "메뉴") }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                if (cur.url.isNotBlank()) {
                    DropdownMenuItem(
                        text = { Text("새로고침") },
                        leadingIcon = { Icon(Icons.Default.Refresh, null) },
                        onClick = { menuOpen = false; vm.refreshPlaylist() }
                    )
                }
                if (cur.tracks.isNotEmpty()) {
                    if (downloading) {
                        DropdownMenuItem(
                            text = { Text("오프라인 저장 멈추기") },
                            leadingIcon = { Icon(Icons.Default.Close, null) },
                            onClick = { menuOpen = false; vm.cancelOffline(cur.id) }
                        )
                    } else {
                        DropdownMenuItem(
                            text = { Text("오프라인에 저장") },
                            leadingIcon = { Icon(Icons.Default.Download, null) },
                            onClick = { menuOpen = false; vm.startOffline(cur.id) }
                        )
                        DropdownMenuItem(
                            text = { Text("저장한 곡 지우기") },
                            leadingIcon = { Icon(Icons.Default.DeleteSweep, null) },
                            onClick = { menuOpen = false; vm.removeOffline(cur.id) }
                        )
                    }
                }
                if (cur.id != FAV_ID) {
                    DropdownMenuItem(
                        text = { Text("이름 바꾸기") },
                        leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = { menuOpen = false; onRename() }
                    )
                    DropdownMenuItem(
                        text = { Text("삭제") },
                        leadingIcon = { Icon(Icons.Default.Delete, null) },
                        onClick = { menuOpen = false; onDelete() }
                    )
                }
            }
        }
    }
}

/** 곡 목록 영역 (제목, 진행 상태, 오류, 검색, 목록) */
@Composable
fun ColumnScope.PlaylistBody(
    vm: MainViewModel,
    cur: Playlist?,
    query: String,
    onQuery: (String) -> Unit,
    onAdd: () -> Unit,
    onMenu: (Track, String, Int) -> Unit
) {
    val scope = rememberCoroutineScope()

    // 아직 아무 플레이리스트도 없을 때
    if (cur == null || (!vm.hasUserPlaylists && cur.tracks.isEmpty())) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.LibraryMusic, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp))
                Text("플레이리스트가 없어요", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "유튜브 앱에서 플레이리스트를 공유하거나\n링크를 붙여넣어 추가해보세요",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
                GlassChip("플레이리스트 추가", icon = Icons.Default.Add, onClick = onAdd)
                vm.error?.let { ErrorCard(it, vm.retry, vm::clearError) }
                if (vm.loading) {
                    Spacer(Modifier.height(16.dp))
                    CircularProgressIndicator()
                }
            }
        }
        return
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            "${if (cur.id == FAV_ID) "좋아요" else cur.name} · ${cur.tracks.size}곡",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        if (vm.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
    }

    PinnedDownloader.progress[cur.id]?.let { (done, total) ->
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(
                progress = { if (total > 0) done / total.toFloat() else 0f },
                modifier = Modifier.weight(1f).height(4.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text("오프라인 저장 $done/$total", style = MaterialTheme.typography.labelSmall)
            TextButton(onClick = { vm.cancelOffline(cur.id) }) { Text("멈추기") }
        }
    }

    vm.error?.let { ErrorCard(it, vm.retry, vm::clearError) }

    when {
        cur.tracks.isEmpty() && vm.loading -> SkeletonList(Modifier.weight(1f))

        cur.tracks.isEmpty() -> {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        cur.id == FAV_ID -> "좋아요한 곡이 없어요.\n곡을 길게 누르거나 플레이어의 ♥를 눌러 담아보세요"
                        cur.url.isBlank() -> "빈 플레이리스트예요.\n다른 목록의 곡을 길게 눌러 '내 플레이리스트에 추가'로 담아보세요"
                        else -> "곡이 없어요. ⋮ 메뉴의 새로고침을 눌러보세요"
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        else -> {
            val shown = remember(cur.tracks, query) {
                cur.tracks.withIndex().filter {
                    query.isBlank() ||
                        it.value.title.contains(query, ignoreCase = true) ||
                        it.value.artist.contains(query, ignoreCase = true)
                }.toList()
            }
            val listState = rememberLazyListState()
            val curPos = if (vm.playingPid == cur.id) shown.indexOfFirst { it.value.url == vm.playingUrl } else -1
            val showJump by remember(curPos) {
                derivedStateOf { curPos >= 0 && listState.layoutInfo.visibleItemsInfo.none { it.index == curPos } }
            }

            // 배경과 확실히 구분되는 판 위에 검색 + 곡 목록
            GlassSurface(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp, bottom = 8.dp),
                shape = RoundedCornerShape(28.dp),
                strong = true
            ) {
                Column(Modifier.fillMaxSize()) {
                    GlassSurface(
                        modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 4.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        TextField(
                            value = query,
                            onValueChange = onQuery,
                            placeholder = { Text("곡 검색") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            trailingIcon = {
                                if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }) {
                                    Icon(Icons.Default.Close, "지우기")
                                }
                            },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 6.dp, end = 6.dp, top = 4.dp, bottom = 72.dp)
                        ) {
                            items(shown, key = { it.index }) { (i, t) ->
                                val isCurrent = vm.playingPid == cur.id && t.url == vm.playingUrl
                                val cached = t.url in vm.cachedUrls
                                val pinned = t.url in vm.pinnedUrls
                                TrackRow(
                                    t = t,
                                    selected = isCurrent,
                                    playing = isCurrent && vm.isPlaying,
                                    cached = cached,
                                    pinned = pinned,
                                    favorite = cur.id != FAV_ID && vm.isFavorite(t.url),
                                    dimmed = !vm.online && !cached && !pinned,
                                    onClick = { vm.playFrom(i) },
                                    onLongClick = { onMenu(t, cur.id, i) },
                                    onSwipeRight = { vm.playNext(t, cur.id) },
                                    onSwipeLeft = { vm.addToQueue(t, cur.id) },
                                    modifier = Modifier.animateItem()
                                )
                            }
                        }
                        if (showJump) {
                            Box(Modifier.align(Alignment.BottomEnd).padding(12.dp)) {
                                GlassChip("현재 곡", icon = Icons.Default.MyLocation) {
                                    scope.launch { listState.animateScrollToItem((curPos - 2).coerceAtLeast(0)) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
