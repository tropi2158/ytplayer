@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalSharedTransitionApi::class)

package com.example.ytplaylist

import androidx.compose.ui.layout.layout

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            YtTheme(vm) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    PlayerScreen(vm)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** 유튜브 앱 '공유' 또는 링크 열기로 들어온 플레이리스트 추가 */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val data = i.data
        if (i.action == Intent.ACTION_VIEW && data?.scheme == "playlist") {
            vm.handleShortcut(data.host ?: "")
            return
        }
        val text = when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i.dataString
            else -> null
        } ?: return
        vm.handleSharedText(text)
    }
}

private data class MenuTarget(val track: Track, val pid: String, val index: Int)

@Composable
fun PlayerScreen(vm: MainViewModel) {
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val askNotif: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { if (vm.onboarded) askNotif() }
    LaunchedEffect(Unit) { while (true) { vm.refreshPosition(); delay(1000) } }
    LaunchedEffect(vm.selectedId, vm.playingUrl, vm.tracks.size) { vm.refreshCacheInfo() }
    LaunchedEffect(Unit) { while (true) { delay(8000); vm.refreshCacheInfo() } }

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.toasts.collect { snackbar.showSnackbar(it) } }

    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var showQueue by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var showNewEmpty by remember { mutableStateOf(false) }
    var newWithTrack by remember { mutableStateOf<Track?>(null) }
    var renameId by remember { mutableStateOf<String?>(null) }
    var deleteId by remember { mutableStateOf<String?>(null) }
    var plMenuId by remember { mutableStateOf<String?>(null) }
    var menuTarget by remember { mutableStateOf<MenuTarget?>(null) }
    var infoTrack by remember { mutableStateOf<Track?>(null) }
    var showSearch by remember { mutableStateOf(false) }
    var showStats by remember { mutableStateOf(false) }
    var showMix by remember { mutableStateOf(false) }
    var tagId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(vm.openSearchRequest) { if (vm.openSearchRequest > 0) showSearch = true }

    val hasCurrent = vm.currentIndex >= 0
    val bottomInset = if (hasCurrent) 92.dp else 0.dp
    val open: (String) -> Unit = { id ->
        vm.select(id)
        openId = id
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val expand = remember { Animatable(0f) }
        val scope = rememberCoroutineScope()
        // 살짝 튕기며 자리를 잡는 스프링
        val panelSpring = spring<Float>(dampingRatio = 0.76f, stiffness = 240f)

        // 손을 뗀 순간의 속도와 위치를 이어받아 펼치거나 접기
        val settle: (Float) -> Unit = { v ->
            scope.launch {
                val target = when {
                    v < -1000f -> 1f
                    v > 1000f -> 0f
                    expand.value > 0.45f -> 1f
                    else -> 0f
                }
                expand.animateTo(target, panelSpring, initialVelocity = -v / heightPx)
            }
        }
        val openPlayer: () -> Unit = { scope.launch { expand.animateTo(1f, panelSpring) } }
        val closePlayer: () -> Unit = { scope.launch { expand.animateTo(0f, panelSpring) } }
        LaunchedEffect(hasCurrent) { if (!hasCurrent) expand.snapTo(0f) }

        // 리퀴드 글래스가 굴절시킬 뒤 화면: 배경만(목록 속 유리) / 배경+화면 내용(위에 떠 있는 미니 플레이어)
        val bgBackdrop = rememberBackdrop(detailed = true)
        val screenBackdrop = rememberBackdrop(detailed = true)
        Box(Modifier.fillMaxSize().backdropSource(screenBackdrop)) {
        // 한 장의 배경 (화면이 바뀌어도 그대로, 곡이 바뀌면 색만 번짐)
        Box(Modifier.fillMaxSize().backdropSource(bgBackdrop)) { GlassBackground(vm.bgColors, art = vm.nowArt) }
        CompositionLocalProvider(LocalBackdrop provides bgBackdrop) {

        // ----- 화면: 홈 <-> 플레이리스트 -----
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                // 플레이어가 펼쳐질수록 뒤 화면이 살짝 작아지고 흐려져요
                val e = expand.value
                val sc = 1f - 0.06f * e
                scaleX = sc
                scaleY = sc
                alpha = 1f - 0.4f * e
            }
        ) {
            SharedTransitionLayout(Modifier.fillMaxSize()) {
                AnimatedContent(
                    targetState = openId,
                    transitionSpec = {
                        val forward = targetState != null
                        (fadeIn(tween(320, delayMillis = 60)) +
                            scaleIn(spring(dampingRatio = 0.8f, stiffness = 260f), initialScale = if (forward) 0.94f else 1.04f)) togetherWith
                            (fadeOut(tween(200)) + scaleOut(tween(260), targetScale = if (forward) 1.04f else 0.94f))
                    },
                    label = "screen"
                ) { id ->
                    val pl = id?.let { pid -> vm.playlists.firstOrNull { it.id == pid } }
                    if (pl == null) {
                        HomeScreen(
                            vm = vm,
                            s = this@SharedTransitionLayout,
                            a = this@AnimatedContent,
                            bottomInset = bottomInset,
                            onOpen = open,
                            onPlaylistMenu = { plMenuId = it },
                            onAdd = { showAdd = true },
                            onSettings = { showSettings = true },
                            onSearch = { showSearch = true },
                            onStats = { showStats = true },
                            onMix = { showMix = true }
                        )
                        if (id != null) LaunchedEffect(id) { openId = null }
                    } else {
                        PlaylistScreen(
                            vm = vm,
                            pl = pl,
                            s = this@SharedTransitionLayout,
                            a = this@AnimatedContent,
                            bottomInset = bottomInset,
                            onBack = { openId = null },
                            onTrackMenu = { t, pid, i -> menuTarget = MenuTarget(t, pid, i) },
                            onRename = { renameId = pl.id },
                            onDelete = { deleteId = pl.id }
                        )
                    }
                }
            }
        }

        }
        }

        // ----- 미니 플레이어 (모든 화면 위에 떠 있음) -----
        AnimatedVisibility(
            visible = hasCurrent,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.7f, stiffness = 300f)) { it } + fadeIn(),
            exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(180))
        ) {
            Box(
                Modifier
                    .navigationBarsPadding()
                    .padding(start = 12.dp, end = 12.dp, bottom = 8.dp)
                    .graphicsLayer {
                        val e = expand.value
                        alpha = (1f - e * 3f).coerceIn(0f, 1f)
                        translationY = -e * heightPx * 0.25f
                    }
            ) {
                CompositionLocalProvider(LocalBackdrop provides screenBackdrop) {
                MiniPlayer(
                    vm,
                    onOpen = openPlayer,
                    onVerticalDrag = { dy ->
                        scope.launch { expand.snapTo((expand.value - dy / heightPx).coerceIn(0f, 1f)) }
                    },
                    onVerticalEnd = settle
                )
                }
            }
        }

        SnackbarHost(
            snackbar,
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = bottomInset + 8.dp)
        )

        PlayerOverlay(
            vm = vm,
            expand = expand,
            heightPx = heightPx,
            onSettle = settle,
            onCollapse = closePlayer,
            onOpenQueue = { showQueue = true },
            onOpenEq = { showEq = true },
            onFindArtist = {
                vm.findArtist(vm.nowArtist)
                showSearch = true
            },
            onInfo = {
                if (vm.playingUrl.isNotEmpty()) infoTrack = Track(vm.playingUrl, vm.nowTitle, vm.nowArtist, vm.nowArt, vm.durationMs / 1000)
            }
        )

        LaunchedEffect(vm.artColors) { AlbumAccent.update(vm.artColors) }

        // ----- 펼치고 접는 동안 날아다니는 아트 한 장 -----
        LaunchedEffect(Unit) {
            snapshotFlow { expand.value > 0.002f && expand.value < 0.998f }.collect { ArtMorph.flying = it }
        }
        if (ArtMorph.flying && ArtMorph.mini != androidx.compose.ui.geometry.Rect.Zero && ArtMorph.big != androidx.compose.ui.geometry.Rect.Zero) {
            val density = androidx.compose.ui.platform.LocalDensity.current
            Box(
                Modifier
                    .layout { m, c ->
                        val e = androidx.compose.animation.core.FastOutSlowInEasing.transform(expand.value.coerceIn(0f, 1f))
                        val r = androidx.compose.ui.geometry.lerp(ArtMorph.mini, ArtMorph.big, e)
                        val pl = m.measure(
                            androidx.compose.ui.unit.Constraints.fixed(
                                r.width.toInt().coerceAtLeast(1), r.height.toInt().coerceAtLeast(1)
                            )
                        )
                        layout(c.maxWidth, c.maxHeight) { pl.place(r.left.toInt(), r.top.toInt()) }
                    }
                    .graphicsLayer {
                        val e = expand.value.coerceIn(0f, 1f)
                        shape = RoundedCornerShape(with(density) { (10f + 4f * e).dp.toPx() })
                        clip = true
                    }
            ) {
                coil.compose.AsyncImage(
                    model = vm.nowArt, contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        if (!vm.onboarded) {
            Onboarding {
                vm.finishOnboarding()
                askNotif()
            }
        }
    }

    // ----- 시트와 대화상자 -----
    if (showQueue) QueueSheet(vm) { showQueue = false }
    if (showEq) EqualizerSheet { showEq = false }
    if (showSettings) SettingsSheet(vm) { showSettings = false }
    plMenuId?.let { pid ->
        PlaylistMenuSheet(
            vm, pid,
            onDismiss = { plMenuId = null },
            onOpen = { open(pid) },
            onRename = { renameId = pid },
            onDelete = { deleteId = pid },
            onTag = { tagId = pid }
        )
    }
    if (showSearch) SearchSheet(vm, onDismiss = { showSearch = false }) { t, pid, i -> menuTarget = MenuTarget(t, pid, i) }
    if (showStats) StatsSheet(vm) { showStats = false }
    if (showMix) MixDialog(vm) { showMix = false }
    tagId?.let { TagDialog(vm, it) { tagId = null } }
    menuTarget?.let { m ->
        TrackMenuSheet(
            vm, m.track, m.pid, m.index,
            onDismiss = { menuTarget = null },
            onNewPlaylist = { newWithTrack = it },
            onFindArtist = { artist ->
                vm.findArtist(artist)
                showSearch = true
            },
            onInfo = { infoTrack = it }
        )
    }
    infoTrack?.let { TrackInfoSheet(vm, it) { infoTrack = null } }
    if (showAdd) {
        AddPlaylistDialog(
            onDismiss = { showAdd = false },
            onAdd = vm::addPlaylist,
            onCreateEmpty = { showNewEmpty = true }
        )
    }
    if (showNewEmpty) {
        NameDialog("새 플레이리스트", "", "만들기", onDismiss = { showNewEmpty = false }) {
            open(vm.createLocalPlaylist(it))
        }
    }
    newWithTrack?.let { t ->
        NameDialog("새 플레이리스트", "", "만들고 곡 넣기", onDismiss = { newWithTrack = null }) {
            vm.createLocalPlaylist(it, t)
        }
    }
    renameId?.let { rid ->
        val p = vm.playlists.firstOrNull { it.id == rid }
        if (p != null) {
            NameDialog("이름 바꾸기", p.name, "확인", onDismiss = { renameId = null }) { vm.renamePlaylist(rid, it) }
        }
    }
    deleteId?.let { did ->
        val p = vm.playlists.firstOrNull { it.id == did }
        if (p != null) {
            AlertDialog(
                onDismissRequest = { deleteId = null },
                title = { Text("플레이리스트 삭제") },
                text = { Text("'${p.name}'을(를) 목록에서 삭제할까요? (유튜브의 원본은 그대로예요)") },
                confirmButton = {
                    TextButton(onClick = {
                        if (openId == did) openId = null
                        vm.deletePlaylist(did)
                        deleteId = null
                    }) { Text("삭제") }
                },
                dismissButton = { TextButton(onClick = { deleteId = null }) { Text("취소") } }
            )
        }
    }
}
