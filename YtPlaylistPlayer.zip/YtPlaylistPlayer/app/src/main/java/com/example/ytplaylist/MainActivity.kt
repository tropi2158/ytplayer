package com.example.ytplaylist

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val scheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize()) { PlayerScreen() }
            }
        }
    }
}

@Composable
fun PlayerScreen(vm: MainViewModel = viewModel()) {
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) {
        while (true) { vm.refreshPosition(); delay(500) }
    }

    Scaffold(
        bottomBar = { if (vm.currentIndex in vm.tracks.indices) NowPlayingBar(vm) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {
            OutlinedTextField(
                value = vm.url,
                onValueChange = { vm.url = it },
                label = { Text("유튜브 플레이리스트 URL") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = vm::load, enabled = !vm.loading) { Text("불러오기") }
                FilledTonalButton(
                    onClick = { vm.playFrom(0) },
                    enabled = vm.tracks.isNotEmpty()
                ) { Text("전체 재생") }
                if (vm.loading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
            }
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (vm.title.isNotBlank()) {
                Text(
                    "${vm.title} · ${vm.tracks.size}곡",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(vm.tracks, key = { i, t -> "$i${t.url}" }) { i, t ->
                    TrackRow(t, selected = i == vm.currentIndex) { vm.playFrom(i) }
                }
            }
        }
    }
}

@Composable
fun TrackRow(t: Track, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = t.thumb,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(56.dp).clip(RoundedCornerShape(6.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(fmt(t.durationSec * 1000), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun NowPlayingBar(vm: MainViewModel) {
    val track = vm.tracks[vm.currentIndex]
    var dragging by remember { mutableStateOf<Float?>(null) }

    Surface(tonalElevation = 3.dp) {
        Column(Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
            Slider(
                value = dragging ?: vm.positionMs.toFloat(),
                onValueChange = { dragging = it },
                onValueChangeFinished = { dragging?.let { vm.seek(it.toLong()) }; dragging = null },
                valueRange = 0f..maxOf(vm.durationMs, 1L).toFloat()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(vm.positionMs), style = MaterialTheme.typography.bodySmall)
                Text(fmt(vm.durationMs), style = MaterialTheme.typography.bodySmall)
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::toggleShuffle) {
                    Icon(
                        Icons.Default.Shuffle, "셔플",
                        tint = if (vm.shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = vm::previous) { Icon(Icons.Default.SkipPrevious, "이전") }
                FilledIconButton(onClick = vm::togglePlay, modifier = Modifier.size(56.dp)) {
                    Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "재생/일시정지")
                }
                IconButton(onClick = vm::next) { Icon(Icons.Default.SkipNext, "다음") }
                IconButton(onClick = vm::cycleRepeat) {
                    Icon(
                        if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "반복",
                        tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
