@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ytplaylist

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            YtTheme(vm) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    PlayerScreen(vm)
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(vm: MainViewModel) {
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { while (true) { vm.refreshPosition(); delay(500) } }
    LaunchedEffect(vm.tracks, vm.currentIndex) { vm.refreshCacheInfo() }
    LaunchedEffect(Unit) { while (true) { delay(5000); vm.refreshCacheInfo() } }

    var showPlayer by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(vm.selectedId) { query = "" }

    val hasCurrent = vm.currentIndex >= 0
    val cur = vm.current

    Box(Modifier.fillMaxSize()) {
        GlassBackground(vm.nowArt)

        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                if (hasCurrent) {
                    Box(
                        Modifier.navigationBarsPadding()
                            .padding(start = 12.dp, end = 12.dp, bottom = 8.dp)
                    ) { MiniPlayer(vm) { showPlayer = true } }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {
                // 헤더
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LibraryMusic, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "YT Playlist",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "설정") }
                }

                // 플레이리스트 선택 칩
                LazyRow(
                    Modifier.padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(vm.playlists, key = { it.id }) { p ->
                        GlassChip(p.name, selected = p.id == cur?.id) { vm.select(p.id) }
                    }
                    item { GlassChip("추가", icon = Icons.Default.Add) { showAdd = true } }
                }

                if (cur == null) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "플레이리스트가 없어요",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "유튜브 플레이리스트 링크를 추가해보세요",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(Modifier.height(16.dp))
                            GlassChip("플레이리스트 추가", icon = Icons.Default.Add) { showAdd = true }
                        }
                    }
                } else {
                    // 재생 버튼 줄
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GlassSurface(
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            tint = MaterialTheme.colorScheme.primary,
                            onClick = { vm.playFrom(0) }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayArrow, null, Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("전체 재생", fontWeight = FontWeight.SemiBold)
                            }
                        }
                        GlassSurface(
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(24.dp),
                            onClick = vm::playShuffled
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Shuffle, null, Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("셔플 재생", fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Box {
                            GlassSurface(
                                modifier = Modifier.size(48.dp),
                                shape = CircleShape,
                                onClick = { menuOpen = true }
                            ) { Icon(Icons.Default.MoreVert, "메뉴") }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("새로고침") },
                                    leadingIcon = { Icon(Icons.Default.Refresh, null) },
                                    onClick = { menuOpen = false; vm.refreshPlaylist() }
                                )
                                DropdownMenuItem(
                                    text = { Text("이름 바꾸기") },
                                    leadingIcon = { Icon(Icons.Default.Edit, null) },
                                    onClick = { menuOpen = false; showRename = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("삭제") },
                                    leadingIcon = { Icon(Icons.Default.Delete, null) },
                                    onClick = { menuOpen = false; showDelete = true }
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "${cur.name} · ${cur.tracks.size}곡",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (vm.loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    }

                    vm.error?.let {
                        Text(
                            it, color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    if (cur.tracks.isNotEmpty()) {
                        GlassSurface(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            TextField(
                                value = query,
                                onValueChange = { query = it },
                                placeholder = { Text("곡 검색") },
                                leadingIcon = { Icon(Icons.Default.Search, null) },
                                trailingIcon = {
                                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                                        Icon(Icons.Default.Close, "지우기")
                                    }
                                },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        val shown = remember(cur.tracks, query) {
                            cur.tracks.withIndex().filter {
                                query.isBlank() ||
                                    it.value.title.contains(query, ignoreCase = true) ||
                                    it.value.artist.contains(query, ignoreCase = true)
                            }.toList()
                        }
                        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 8.dp)) {
                            items(shown, key = { it.index }) { (i, t) ->
                                val isCurrent = vm.playingPid == cur.id && i == vm.currentIndex
                                TrackRow(
                                    t = t,
                                    selected = isCurrent,
                                    playing = isCurrent && vm.isPlaying,
                                    cached = t.url in vm.cachedUrls
                                ) { vm.playFrom(i) }
                            }
                        }
                    } else if (!vm.loading) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text(
                                "곡이 없어요. 새로고침을 눌러보세요",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }

    if (showPlayer && hasCurrent) FullPlayerSheet(vm) { showPlayer = false }
    if (showSettings) SettingsSheet(vm) { showSettings = false }
    if (showAdd) AddPlaylistDialog(onDismiss = { showAdd = false }, onAdd = vm::addPlaylist)
    if (showRename && cur != null) {
        RenameDialog(cur.name, onDismiss = { showRename = false }) { vm.renamePlaylist(cur.id, it) }
    }
    if (showDelete && cur != null) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("플레이리스트 삭제") },
            text = { Text("'${cur.name}'을(를) 목록에서 삭제할까요? (유튜브의 원본은 그대로예요)") },
            confirmButton = {
                TextButton(onClick = { vm.deletePlaylist(cur.id); showDelete = false }) { Text("삭제") }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("취소") } }
        )
    }
}

@Composable
fun GlassChip(label: String, selected: Boolean = false, icon: ImageVector? = null, onClick: () -> Unit) {
    GlassSurface(
        shape = CircleShape,
        tint = if (selected) MaterialTheme.colorScheme.primary else null,
        onClick = onClick
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(icon, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
            }
            Text(
                label, maxLines = 1,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}

@Composable
fun AddPlaylistDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("플레이리스트 추가") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("유튜브 플레이리스트 URL") },
                singleLine = true,
                trailingIcon = {
                    IconButton(onClick = { clipboard.getText()?.text?.let { text = it } }) {
                        Icon(Icons.Default.ContentPaste, "붙여넣기")
                    }
                }
            )
        },
        confirmButton = {
            TextButton(onClick = { onAdd(text); onDismiss() }, enabled = text.isNotBlank()) { Text("추가") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}

@Composable
fun RenameDialog(initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("이름 바꾸기") },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true)
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text); onDismiss() }, enabled = text.isNotBlank()) { Text("확인") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}

@Composable
fun TrackRowContent(t: Track, playing: Boolean, cached: Boolean, selected: Boolean) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(
            model = t.thumb,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(52.dp).clip(RoundedCornerShape(10.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            )
            Text(
                t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (cached) {
            Icon(Icons.Default.DownloadDone, "캐시됨", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
        }
        if (playing) {
            Icon(Icons.Default.GraphicEq, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
        }
        Text(
            fmt(t.durationSec * 1000),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun TrackRow(t: Track, selected: Boolean, playing: Boolean, cached: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    if (selected) {
        GlassSurface(
            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            shape = shape,
            tint = MaterialTheme.colorScheme.primary,
            onClick = onClick
        ) { TrackRowContent(t, playing, cached, true) }
    } else {
        Box(
            Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(shape).clickable(onClick = onClick)
        ) { TrackRowContent(t, playing, cached, false) }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        onClick = onOpen
    ) {
        Column {
            Row(
                Modifier.padding(start = 10.dp, end = 4.dp, top = 10.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = vm.nowArt, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(vm.nowTitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(
                        vm.nowArtist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = vm::togglePlay) {
                    Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "재생/일시정지")
                }
                IconButton(onClick = vm::next) { Icon(Icons.Default.SkipNext, "다음") }
            }
            LinearProgressIndicator(
                progress = {
                    if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
                },
                trackColor = Color.White.copy(alpha = 0.2f),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 10.dp)
                    .height(3.dp).clip(CircleShape)
            )
        }
    }
}

@Composable
fun FullPlayerSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var drag by remember { mutableStateOf<Float?>(null) }
    val max = maxOf(vm.durationMs, 1L).toFloat()
    val glass = LocalGlass.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = if (glass) 0.82f else 1f)
    ) {
        Box(Modifier.fillMaxWidth()) {
            if (glass && vm.nowArt != null && Build.VERSION.SDK_INT >= 31) {
                AsyncImage(
                    model = vm.nowArt, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize().blur(48.dp).alpha(0.35f)
                )
            }
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GlassSurface(
                    modifier = Modifier.widthIn(max = 320.dp).fillMaxWidth().aspectRatio(1f),
                    shape = RoundedCornerShape(30.dp)
                ) {
                    AsyncImage(
                        model = vm.nowArt, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().padding(5.dp).clip(RoundedCornerShape(25.dp))
                    )
                }
                Spacer(Modifier.height(20.dp))
                Text(
                    vm.nowTitle, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Text(
                    vm.nowArtist, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                Slider(
                    value = (drag ?: vm.positionMs.toFloat()).coerceIn(0f, max),
                    onValueChange = { drag = it },
                    onValueChangeFinished = { drag?.let { vm.seek(it.toLong()) }; drag = null },
                    valueRange = 0f..max
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fmt((drag ?: vm.positionMs.toFloat()).toLong()), style = MaterialTheme.typography.bodySmall)
                    Text(fmt(vm.durationMs), style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = vm::toggleShuffle) {
                        Icon(
                            Icons.Default.Shuffle, "셔플",
                            tint = if (vm.shuffle) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = vm::previous, modifier = Modifier.size(52.dp)) {
                        Icon(Icons.Default.SkipPrevious, "이전", Modifier.size(32.dp))
                    }
                    GlassSurface(
                        modifier = Modifier.size(76.dp),
                        shape = CircleShape,
                        tint = MaterialTheme.colorScheme.primary,
                        onClick = vm::togglePlay
                    ) {
                        Icon(
                            if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            "재생/일시정지", Modifier.size(40.dp)
                        )
                    }
                    IconButton(onClick = vm::next, modifier = Modifier.size(52.dp)) {
                        Icon(Icons.Default.SkipNext, "다음", Modifier.size(32.dp))
                    }
                    IconButton(onClick = vm::cycleRepeat) {
                        Icon(
                            if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                            "반복",
                            tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.onSurfaceVariant
                            else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val dynamicAvailable = Build.VERSION.SDK_INT >= 31
    val dynamicOn = vm.dynamicColor && dynamicAvailable
    val glass = LocalGlass.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = if (glass) 0.86f else 1f)
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("설정", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(8.dp))
            Text("테마", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("시스템", "라이트", "다크").forEachIndexed { i, label ->
                    FilterChip(
                        selected = vm.themeMode == i,
                        onClick = { vm.updateThemeMode(i) },
                        label = { Text(label) }
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Text("강조 색상", style = MaterialTheme.typography.titleSmall)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ACCENTS.forEachIndexed { i, (name, color) ->
                    val selected = vm.accent == i
                    val alpha = if (dynamicOn) 0.35f else 1f
                    val bg: Modifier = if (color == MONO) {
                        Modifier.background(
                            Brush.horizontalGradient(
                                0f to Color.Black, 0.5f to Color.Black, 0.5f to Color.White, 1f to Color.White
                            )
                        )
                    } else Modifier.background(color)
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .alpha(alpha)
                            .then(bg)
                            .border(
                                if (selected) 3.dp else 1.dp,
                                if (selected) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                CircleShape
                            )
                            .clickable { vm.updateAccent(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) {
                            Icon(
                                Icons.Default.Check, name,
                                tint = if (color == MONO) Color.Gray else Color.White
                            )
                        }
                    }
                }
            }
            Text(
                "마지막 '흑백'은 검정/흰색/회색만 쓰는 테마예요 (다크 모드에서는 완전한 검정 배경)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (dynamicAvailable) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("배경화면 색상 사용", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "켜면 폰 배경화면에서 색을 가져와요 (강조 색상은 무시)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = vm.dynamicColor, onCheckedChange = vm::updateDynamic)
                }
            }

            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("리퀴드 글래스", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "반투명 유리 질감과 앨범 아트 배경 (안드로이드 12 이상에서 배경이 흐리게 비쳐요)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = vm.glass, onCheckedChange = vm::updateGlass)
            }

            Spacer(Modifier.height(12.dp))
            Text("오디오 캐시", style = MaterialTheme.typography.titleSmall)
            Text(
                "${mb(vm.cacheBytes)} / ${mb(CacheProvider.MAX_BYTES)} 사용 중 · 한 번 끝까지 들은 곡은 인터넷 없이 재생돼요",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = vm::clearCache) {
                Icon(Icons.Default.DeleteSweep, null, Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("캐시 비우기")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun mb(bytes: Long): String = "%.0f MB".format(bytes / 1048576.0)

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
