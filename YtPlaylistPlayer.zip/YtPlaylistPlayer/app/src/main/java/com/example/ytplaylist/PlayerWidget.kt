@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaButtonReceiver

/** 홈 화면 위젯 (크게): 앨범 아트 + 제목 + 이전/재생/다음 */
class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.refresh(context)
    }
}

/** 홈 화면 위젯 (작게): 앨범 아트 + 제목 + 재생/다음 */
class PlayerWidgetSmall : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.refresh(context)
    }
}

object WidgetUpdater {
    @Volatile var art: Bitmap? = null
    @Volatile private var playing = false

    fun refresh(ctx: Context) {
        val p = ctx.getSharedPreferences("yt", Context.MODE_PRIVATE)
        update(ctx, p.getString("w_title", "") ?: "", p.getString("w_artist", "") ?: "", playing)
    }

    fun update(ctx: Context, title: String, artist: String, isPlaying: Boolean) {
        val app = ctx.applicationContext
        playing = isPlaying
        app.getSharedPreferences("yt", Context.MODE_PRIVATE).edit()
            .putString("w_title", title).putString("w_artist", artist).apply()
        val mgr = AppWidgetManager.getInstance(app) ?: return

        val bigIds = mgr.getAppWidgetIds(ComponentName(app, PlayerWidget::class.java)) ?: IntArray(0)
        if (bigIds.isNotEmpty()) mgr.updateAppWidget(bigIds, views(app, R.layout.widget_player, title, artist, isPlaying, true))
        val smallIds = mgr.getAppWidgetIds(ComponentName(app, PlayerWidgetSmall::class.java)) ?: IntArray(0)
        if (smallIds.isNotEmpty()) mgr.updateAppWidget(smallIds, views(app, R.layout.widget_player_small, title, artist, isPlaying, false))
    }

    private fun views(app: Context, layout: Int, title: String, artist: String, isPlaying: Boolean, big: Boolean): RemoteViews {
        val rv = RemoteViews(app.packageName, layout)
        rv.setTextViewText(R.id.w_title, title.ifBlank { if (big) "재생 중인 곡 없음" else "Playlist" })
        if (big) rv.setTextViewText(R.id.w_artist, artist)
        val bmp = art
        if (bmp != null) rv.setImageViewBitmap(R.id.w_art, bmp) else rv.setImageViewResource(R.id.w_art, R.drawable.ic_launcher_background)
        rv.setImageViewResource(
            R.id.w_play,
            if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
        if (big) rv.setOnClickPendingIntent(R.id.w_prev, mediaPi(app, 1, KeyEvent.KEYCODE_MEDIA_PREVIOUS))
        rv.setOnClickPendingIntent(R.id.w_play, mediaPi(app, 2, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        rv.setOnClickPendingIntent(R.id.w_next, mediaPi(app, 3, KeyEvent.KEYCODE_MEDIA_NEXT))
        rv.setOnClickPendingIntent(
            R.id.w_root,
            PendingIntent.getActivity(app, 0, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        )
        return rv
    }

    private fun mediaPi(ctx: Context, code: Int, key: Int): PendingIntent {
        val i = Intent(Intent.ACTION_MEDIA_BUTTON)
            .setComponent(ComponentName(ctx, MediaButtonReceiver::class.java))
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, key))
        return PendingIntent.getBroadcast(
            ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
