@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.view.KeyEvent
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaButtonReceiver
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** 재생 위젯 (4×2): 흐린 아트 배경 + 둥근 아트 + 제목 + 이전/재생/다음 + 좋아요 */
class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.refresh(context)
    }
}

/** 한 줄 위젯 (3×1) */
class PlayerWidgetSmall : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.refresh(context)
    }
}

/** 앨범 아트 위젯 (2×2): 아트가 꽉 차고 구석에 재생 버튼 */
class PlayerWidgetArt : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.refresh(context)
    }
}

/** 플레이리스트 위젯 (4×2): 내 플레이리스트 4개, 누르면 섞어 듣기 */
class PlaylistWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        PlaylistWidgetUpdater.update(context) { pending.finish() }
    }
}

/** 위젯의 ♥ 버튼: 앱을 열지 않고 재생 서비스에 바로 전달 */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_FAV) {
            val svc = PlaybackService.instance
            if (svc != null) svc.toggleFavExternal()
            else context.startActivity(
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    companion object {
        const val ACTION_FAV = "com.example.ytplaylist.WIDGET_FAV"
    }
}

object WidgetUpdater {
    @Volatile var art: Bitmap? = null
        set(value) {
            field = value
            artRound = value?.let { roundCorners(it, 0.14f) }
            artBlur = value?.let { blurDark(it) }
        }
    @Volatile private var artRound: Bitmap? = null
    @Volatile private var artBlur: Bitmap? = null
    @Volatile private var playing = false
    @Volatile private var fav = false

    fun refresh(ctx: Context) {
        val p = ctx.getSharedPreferences("yt", Context.MODE_PRIVATE)
        update(ctx, p.getString("w_title", "") ?: "", p.getString("w_artist", "") ?: "", playing, fav)
    }

    fun update(ctx: Context, title: String, artist: String, isPlaying: Boolean, isFav: Boolean = fav) {
        val app = ctx.applicationContext
        playing = isPlaying
        fav = isFav
        app.getSharedPreferences("yt", Context.MODE_PRIVATE).edit()
            .putString("w_title", title).putString("w_artist", artist).apply()
        val mgr = AppWidgetManager.getInstance(app) ?: return
        val shownTitle = TitleClean.title(title, artist)
        val shownArtist = TitleClean.artist(artist)

        fun ids(c: Class<*>) = mgr.getAppWidgetIds(ComponentName(app, c)) ?: IntArray(0)
        ids(PlayerWidget::class.java).takeIf { it.isNotEmpty() }?.let {
            mgr.updateAppWidget(it, big(app, shownTitle, shownArtist, isPlaying, isFav))
        }
        ids(PlayerWidgetSmall::class.java).takeIf { it.isNotEmpty() }?.let {
            mgr.updateAppWidget(it, small(app, shownTitle, isPlaying))
        }
        ids(PlayerWidgetArt::class.java).takeIf { it.isNotEmpty() }?.let {
            mgr.updateAppWidget(it, artOnly(app, shownTitle, shownArtist, isPlaying))
        }
    }

    private fun big(app: Context, title: String, artist: String, isPlaying: Boolean, isFav: Boolean): RemoteViews {
        val rv = RemoteViews(app.packageName, R.layout.widget_player)
        rv.setTextViewText(R.id.w_title, title.ifBlank { "재생 중인 곡 없음" })
        rv.setTextViewText(R.id.w_artist, artist)
        rv.setTextViewText(R.id.w_label, if (title.isBlank()) "Playlist" else if (isPlaying) "지금 재생 중" else "일시정지됨")
        setArt(rv, R.id.w_art, artRound)
        setBg(rv)
        rv.setImageViewResource(R.id.w_play, if (isPlaying) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        rv.setImageViewResource(R.id.w_fav, if (isFav) R.drawable.ic_fav_on else R.drawable.ic_fav_off)
        rv.setOnClickPendingIntent(R.id.w_prev, mediaPi(app, 1, KeyEvent.KEYCODE_MEDIA_PREVIOUS))
        rv.setOnClickPendingIntent(R.id.w_play, mediaPi(app, 2, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        rv.setOnClickPendingIntent(R.id.w_next, mediaPi(app, 3, KeyEvent.KEYCODE_MEDIA_NEXT))
        rv.setOnClickPendingIntent(R.id.w_fav, favPi(app))
        rv.setOnClickPendingIntent(R.id.w_root, openApp(app))
        return rv
    }

    private fun small(app: Context, title: String, isPlaying: Boolean): RemoteViews {
        val rv = RemoteViews(app.packageName, R.layout.widget_player_small)
        rv.setTextViewText(R.id.w_title, title.ifBlank { "Playlist" })
        setArt(rv, R.id.w_art, artRound)
        setBg(rv)
        rv.setImageViewResource(R.id.w_play, if (isPlaying) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        rv.setOnClickPendingIntent(R.id.w_play, mediaPi(app, 2, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        rv.setOnClickPendingIntent(R.id.w_next, mediaPi(app, 3, KeyEvent.KEYCODE_MEDIA_NEXT))
        rv.setOnClickPendingIntent(R.id.w_root, openApp(app))
        return rv
    }

    private fun artOnly(app: Context, title: String, artist: String, isPlaying: Boolean): RemoteViews {
        val rv = RemoteViews(app.packageName, R.layout.widget_art)
        rv.setTextViewText(R.id.w_title, title.ifBlank { "Playlist" })
        rv.setTextViewText(R.id.w_artist, artist)
        val a = art
        if (a != null) rv.setImageViewBitmap(R.id.w_bg, a) else rv.setImageViewResource(R.id.w_bg, R.drawable.ic_launcher_background)
        rv.setImageViewResource(R.id.w_play, if (isPlaying) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        rv.setOnClickPendingIntent(R.id.w_play, mediaPi(app, 2, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        rv.setOnClickPendingIntent(R.id.w_root, openApp(app))
        return rv
    }

    private fun setArt(rv: RemoteViews, id: Int, bmp: Bitmap?) {
        if (bmp != null) rv.setImageViewBitmap(id, bmp) else rv.setImageViewResource(id, R.drawable.ic_launcher_background)
    }

    private fun setBg(rv: RemoteViews) {
        val b = artBlur
        if (b != null) rv.setImageViewBitmap(R.id.w_bg, b) else rv.setImageViewBitmap(R.id.w_bg, null)
    }

    private fun openApp(app: Context): PendingIntent =
        PendingIntent.getActivity(app, 0, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun favPi(app: Context): PendingIntent =
        PendingIntent.getBroadcast(
            app, 9, Intent(app, WidgetActionReceiver::class.java).setAction(WidgetActionReceiver.ACTION_FAV),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun mediaPi(ctx: Context, code: Int, key: Int): PendingIntent {
        val i = Intent(Intent.ACTION_MEDIA_BUTTON)
            .setComponent(ComponentName(ctx, MediaButtonReceiver::class.java))
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, key))
        return PendingIntent.getBroadcast(
            ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    // ---------- 비트맵 다듬기 ----------

    /** 모서리를 둥글게 (가운데를 정사각형으로 잘라서) */
    fun roundCorners(src: Bitmap, radiusFrac: Float): Bitmap {
        val side = minOf(src.width, src.height)
        val out = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val m = android.graphics.Matrix()
        m.setTranslate(-(src.width - side) / 2f, -(src.height - side) / 2f)
        shader.setLocalMatrix(m)
        p.shader = shader
        val r = side * radiusFrac
        c.drawRoundRect(RectF(0f, 0f, side.toFloat(), side.toFloat()), r, r, p)
        return out
    }

    /** 아주 작게 줄였다 늘려서 흐리게 + 어둡게 (위젯 배경용) */
    private fun blurDark(src: Bitmap): Bitmap {
        val tiny = Bitmap.createScaledBitmap(src, 10, 10, true)
        val out = Bitmap.createScaledBitmap(tiny, 120, 120, true)
        val c = Canvas(out)
        c.drawColor(Color.argb(150, 0, 0, 0))
        return out
    }
}

/** 플레이리스트 위젯 채우기: 커버는 각 목록 첫 곡의 썸네일 (좋아요는 장밋빛 하트) */
object PlaylistWidgetUpdater {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** 앱에서 목록이 바뀌었을 때 (위젯이 있을 때만) */
    fun requestUpdate(ctx: Context) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app) ?: return
        val ids = mgr.getAppWidgetIds(ComponentName(app, PlaylistWidget::class.java)) ?: return
        if (ids.isNotEmpty()) update(app) {}
    }

    fun update(ctx: Context, done: () -> Unit) {
        val app = ctx.applicationContext
        scope.launch {
            try {
                val mgr = AppWidgetManager.getInstance(app) ?: return@launch
                val ids = mgr.getAppWidgetIds(ComponentName(app, PlaylistWidget::class.java)) ?: return@launch
                if (ids.isEmpty()) return@launch
                val prefs = app.getSharedPreferences("yt", Context.MODE_PRIVATE)
                val lists = Store.load(prefs).filter { it.tracks.isNotEmpty() }.take(4)
                val rv = RemoteViews(app.packageName, R.layout.widget_playlists)
                val covers = intArrayOf(R.id.pl_cover0, R.id.pl_cover1, R.id.pl_cover2, R.id.pl_cover3)
                val names = intArrayOf(R.id.pl_name0, R.id.pl_name1, R.id.pl_name2, R.id.pl_name3)
                val cells = intArrayOf(R.id.pl_cell0, R.id.pl_cell1, R.id.pl_cell2, R.id.pl_cell3)
                rv.setViewVisibility(R.id.pl_empty, if (lists.isEmpty()) View.VISIBLE else View.GONE)
                for (i in 0 until 4) {
                    val p = lists.getOrNull(i)
                    if (p == null) {
                        rv.setViewVisibility(cells[i], View.INVISIBLE)
                        continue
                    }
                    rv.setViewVisibility(cells[i], View.VISIBLE)
                    rv.setTextViewText(names[i], if (p.id == FAV_ID) "좋아요" else p.name)
                    val bmp = if (p.id == FAV_ID) favCover(app) else loadCover(app, p.tracks.first().thumb)
                    if (bmp != null) rv.setImageViewBitmap(covers[i], WidgetUpdater.roundCorners(bmp, 0.12f))
                    else rv.setImageViewResource(covers[i], R.drawable.ic_launcher_background)
                    rv.setOnClickPendingIntent(
                        cells[i],
                        PendingIntent.getActivity(
                            app, 100 + i,
                            Intent(Intent.ACTION_VIEW, Uri.parse("playlist://play/${Uri.encode(p.id)}"), app, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                        )
                    )
                }
                rv.setOnClickPendingIntent(
                    R.id.pl_mix,
                    PendingIntent.getActivity(
                        app, 99,
                        Intent(Intent.ACTION_VIEW, Uri.parse("playlist://shuffle"), app, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                )
                mgr.updateAppWidget(ids, rv)
            } catch (_: Exception) {
            } finally {
                done()
            }
        }
    }

    private suspend fun loadCover(ctx: Context, url: String?): Bitmap? {
        if (url == null) return null
        return try {
            val req = ImageRequest.Builder(ctx).data(url).size(240).allowHardware(false).build()
            (ctx.imageLoader.execute(req).drawable as? BitmapDrawable)?.bitmap
        } catch (_: Exception) {
            null
        }
    }

    /** 좋아요 커버: 장밋빛 → 보랏빛 그라데이션 + 흰 하트 */
    private fun favCover(ctx: Context): Bitmap {
        val s = 240
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, s.toFloat(), s.toFloat(),
            intArrayOf(0xFFFF6B8B.toInt(), 0xFFE0457B.toInt(), 0xFF7A3CF0.toInt()), null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        ContextCompat.getDrawable(ctx, R.drawable.ic_fav_on)?.let { d ->
            val h = (s * 0.36f).toInt()
            val o = (s - h) / 2
            d.setBounds(o, o, o + h, o + h)
            d.draw(c)
        }
        return out
    }
}
