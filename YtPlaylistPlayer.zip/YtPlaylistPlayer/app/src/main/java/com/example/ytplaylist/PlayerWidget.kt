@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaButtonReceiver

/** 홈 화면 위젯: 곡 제목 + 이전/재생/다음 */
class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val p = context.getSharedPreferences("yt", Context.MODE_PRIVATE)
        WidgetUpdater.update(context, p.getString("w_title", "") ?: "", p.getString("w_artist", "") ?: "", false)
    }
}

object WidgetUpdater {
    fun update(ctx: Context, title: String, artist: String, playing: Boolean) {
        val app = ctx.applicationContext
        app.getSharedPreferences("yt", Context.MODE_PRIVATE).edit()
            .putString("w_title", title).putString("w_artist", artist).apply()

        val mgr = AppWidgetManager.getInstance(app) ?: return
        val ids = mgr.getAppWidgetIds(ComponentName(app, PlayerWidget::class.java))
        if (ids == null || ids.isEmpty()) return

        val rv = RemoteViews(app.packageName, R.layout.widget_player)
        rv.setTextViewText(R.id.w_title, title.ifBlank { "재생 중인 곡 없음" })
        rv.setTextViewText(R.id.w_artist, artist)
        rv.setImageViewResource(
            R.id.w_play,
            if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
        rv.setOnClickPendingIntent(R.id.w_prev, mediaPi(app, 1, KeyEvent.KEYCODE_MEDIA_PREVIOUS))
        rv.setOnClickPendingIntent(R.id.w_play, mediaPi(app, 2, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        rv.setOnClickPendingIntent(R.id.w_next, mediaPi(app, 3, KeyEvent.KEYCODE_MEDIA_NEXT))
        rv.setOnClickPendingIntent(
            R.id.w_root,
            PendingIntent.getActivity(app, 0, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        )
        mgr.updateAppWidget(ids, rv)
    }

    private fun mediaPi(ctx: Context, code: Int, key: Int): PendingIntent {
        val i = Intent(Intent.ACTION_MEDIA_BUTTON)
            .setComponent(ComponentName(ctx, MediaButtonReceiver::class.java))
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, key))
        return PendingIntent.getBroadcast(
            ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
