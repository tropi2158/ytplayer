@file:OptIn(ExperimentalSharedTransitionApi::class)

package com.example.ytplaylist

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val SORTS = listOf("기본 순서", "제목순", "짧은 곡부터", "최근 추가된 순")

private fun totalLabel(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    return if (h > 0) "${h}시간 ${m}분" else "${m}분"
}

@Composable
fun PlaylistScreen(
    vm: MainViewModel,
    pl: Playlist,
    s: SharedTransitionScope?,
    a: AnimatedVisibilityScope?,
    bottomInset: Dp,
    onBack: () -> Unit,
    onTrackMenu: (Track, String, Int) -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    BackHandler { onBack() }
    var sort by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val name = if (pl.id == FAV_ID) "좋아요" else pl.name
    val total = remember(pl.tracks) { pl.tracks.sumOf { it.durationSec } }
    val downloading = PinnedDownloader.progress[pl.id]

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(bottom = bottomInset)) {
        // ----- 상단 막대 -----
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBackIosNew, "뒤로", Modifier.size(20.dp)) }
            Spacer(Modifier.weight(1f))
            Box {
                IconButton(onClick = { sortOpen = true }) { Icon(Icons.Default.Sort, "정렬") }
                DropdownMenu(expanded = sortOpen, onDismissRequest = { sortOpen = false }) {
                    SORTS.forEachIndexed { i, label ->
                        DropdownMenuItem(
                            text = { Text(label) },
                            trailingIcon = { if (sort == i) Icon(Icons.Default.Check, null) },
                            onClick = { sort = i; sortOpen = false }
                        )
                    }
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreHoriz, "메뉴") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    if (pl.url.isNotBlank()) {
                        DropdownMenuItem(
                            text = { Text("새로고침") },
                            leadingIcon = { Icon(Icons.Default.Refresh, null) },
                            onClick = { menuOpen = false; vm.refreshPlaylist(pl.id) }
                        )
                    }
                    if (pl.tracks.isNotEmpty()) {
                        if (downloading != null) {
                            DropdownMenuItem(
                                text = { Text("오프라인 저장 멈추기") },
                                leadingIcon = { Icon(Icons.Default.Close, null) },
                                onClick = { menuOpen = false; vm.cancelOffline(pl.id) }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("오프라인에 저장") },
                                leadingIcon = { Icon(Icons.Default.Download, null) },
                                onClick = { menuOpen = false; vm.startOffline(pl.id) }
                            )
                            DropdownMenuItem(
                                text = { Text("저장한 곡 지우기") },
                                leadingIcon = { Icon(Icons.Default.DeleteSweep, null) },
                                onClick = { menuOpen = false; vm.removeOffline(pl.id) }
                            )
                        }
                    }
                    if (vm.duplicateCount(pl.id) > 0) {
                        DropdownMenuItem(
                            text = { Text("중복 곡 정리") },
                            leadingIcon = { Icon(Icons.Default.CleaningServices, null) },
                            onClick = { menuOpen = false; vm.removeDuplicates(pl.id) }
                        )
                    }
                    if (isAutoId(pl.id)) {
                        DropdownMenuItem(
                            text = { Text("내 플레이리스트로 저장") },
                            leadingIcon = { Icon(Icons.Default.LibraryAdd, null) },
                            onClick = { menuOpen = false; vm.saveTracksAsPlaylist(pl.name, pl.tracks) }
                        )
                    }
                    if (pl.id != FAV_ID && !isAutoId(pl.id)) {
                        DropdownMenuItem(
                            text = { Text("맨 앞으로 옮기기") },
                            leadingIcon = { Icon(Icons.Default.VerticalAlignTop, null) },
                            onClick = { menuOpen = false; vm.movePlaylistToFront(pl.id) }
                        )
                        DropdownMenuItem(
                            text = { Text("이름 바꾸기") },
                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                            onClick = { menuOpen = false; onRename() }
                        )
                        DropdownMenuItem(
                            text = { Text("삭제") },
                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                            onClick = { menuOpen = false; onDelete() }
                        )
                    }
                }
            }
        }

        // ----- 하나로 스크롤되는 화면: 커버 → 이름 → 재생/셔플 → 검색 → 곡 -----
        val shown = remember(pl.tracks, query, sort) {
            val base = pl.tracks.withIndex().filter {
                query.isBlank() ||
                    it.value.title.contains(query, ignoreCase = true) ||
                    it.value.artist.contains(query, ignoreCase = true)
            }
            when (sort) {
                1 -> base.sortedBy { it.value.shownTitle.lowercase() }
                2 -> base.sortedBy { it.value.durationSec }
                3 -> base.reversed()
                else -> base
            }
        }
        val listState = rememberLazyListState()
        LaunchedEffect(sort) { if (listState.firstVisibleItemIndex > 1) listState.scrollToItem(1) }
        val curPos = if (vm.playingPid == pl.id) shown.indexOfFirst { it.value.url == vm.playingUrl } else -1
        val headerCount = 2
        val showJump by remember(curPos) {
            derivedStateOf { curPos >= 0 && listState.layoutInfo.visibleItemsInfo.none { it.index == curPos + headerCount } }
        }
        val muted = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val coverSize = (maxWidth * 0.55f).coerceIn(180.dp, 260.dp)
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().widthIn(max = 760.dp).align(Alignment.TopCenter),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp)
            ) {
                item(key = "__head__") {
                    Column(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        PlaylistCover(
                            pl,
                            Modifier.sharedEl("cover-${pl.id}", s, a).size(coverSize)
                                .shadow(24.dp, RoundedCornerShape(16.dp), ambientColor = Color.Black, spotColor = Color.Black),
                            16.dp
                        )
                        Spacer(Modifier.height(18.dp))
                        Text(
                            name,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 24.dp).sharedBox("title-${pl.id}", s, a)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            buildString {
                                append(
                                    when {
                                        pl.id == FAV_ID -> "좋아요한 곡"
                                        pl.url.isBlank() -> "내가 만든 목록"
                                        else -> "YouTube"
                                    }
                                )
                                append(" · ${pl.tracks.size}곡")
                                if (total > 0) append(" · ${totalLabel(total)}")
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = muted,
                            modifier = Modifier.riseIn(a, 80)
                        )
                        if (pl.tracks.isNotEmpty()) {
                            Spacer(Modifier.height(18.dp))
                            Row(
                                Modifier.widthIn(max = 420.dp).fillMaxWidth().padding(horizontal = 8.dp).riseIn(a, 120, 2),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                PillButton(Icons.Default.PlayArrow, "재생", Modifier.weight(1f)) { vm.playAllIn(pl.id) }
                                PillButton(Icons.Default.Shuffle, "셔플", Modifier.weight(1f)) { vm.shuffleIn(pl.id) }
                            }
                        }
                        if (downloading != null) {
                            val (done, all) = downloading
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                LinearProgressIndicator(
                                    progress = { if (all > 0) done / all.toFloat() else 0f },
                                    modifier = Modifier.weight(1f).height(3.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("저장 중 $done/$all", style = MaterialTheme.typography.labelSmall, color = muted)
                                TextButton(onClick = { vm.cancelOffline(pl.id) }) { Text("멈추기") }
                            }
                        }
                        vm.error?.let {
                            Spacer(Modifier.height(8.dp))
                            ErrorCard(it, vm.retry, vm::clearError)
                        }
                    }
                }
                item(key = "__search__") {
                    if (pl.tracks.size > 8) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.07f))
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Search, null, Modifier.size(18.dp), tint = muted)
                            Spacer(Modifier.width(8.dp))
                            Box(Modifier.weight(1f).padding(vertical = 11.dp)) {
                                if (query.isEmpty()) Text("이 목록에서 찾기", color = muted, style = MaterialTheme.typography.bodyMedium)
                                androidx.compose.foundation.text.BasicTextField(
                                    value = query,
                                    onValueChange = { query = it },
                                    singleLine = true,
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                                    cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.onSurface),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            if (query.isNotEmpty()) {
                                Icon(
                                    Icons.Default.Close, "지우기",
                                    Modifier.size(18.dp).clip(CircleShape).clickable { query = "" }, tint = muted
                                )
                            }
                        }
                    } else Spacer(Modifier.height(8.dp))
                }

                when {
                    pl.tracks.isEmpty() && vm.loading -> item(key = "__skel__") { SkeletonList(Modifier.fillMaxWidth().height(400.dp)) }
                    pl.tracks.isEmpty() -> item(key = "__empty__") {
                        Text(
                            when {
                                pl.id == FAV_ID -> "좋아요한 곡이 없어요.\n플레이어의 ♥를 눌러 담아보세요"
                                pl.url.isBlank() -> "빈 플레이리스트예요.\n다른 목록의 곡을 길게 눌러 '내 플레이리스트에 추가'로 담아보세요"
                                else -> "곡이 없어요. ⋯ 메뉴의 새로고침을 눌러보세요"
                            },
                            color = muted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(32.dp)
                        )
                    }
                    else -> itemsIndexed(shown, key = { _, it -> it.index }, contentType = { _, _ -> "track" }) { pos, (i, t) ->
                        val isCurrent = vm.playingPid == pl.id && t.url == vm.playingUrl
                        val cached = t.url in vm.cachedUrls
                        val pinned = t.url in vm.pinnedUrls
                        TrackRow(
                            t = t,
                            selected = isCurrent,
                            playing = isCurrent && vm.isPlaying,
                            cached = cached,
                            pinned = pinned,
                            favorite = pl.id != FAV_ID && vm.isFavorite(t.url),
                            dimmed = !vm.online && !cached && !pinned,
                            onClick = { vm.playIn(pl.id, i) },
                            onLongClick = { onTrackMenu(t, pl.id, i) },
                            onSwipeRight = { vm.playNext(t, pl.id) },
                            onSwipeLeft = { vm.addToQueue(t, pl.id) },
                            // 처음 보이는 곡들이 위에서부터 차례로 떠올라요
                            modifier = Modifier.animateItem().riseIn(a, 140 + 28 * pos.coerceAtMost(14), 2),
                            isNew = t.url in vm.newUrls
                        )
                    }
                }
            }
            if (showJump) {
                Box(Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
                    PillButton(Icons.Default.MyLocation, "현재 곡", Modifier) {
                        scope.launch { listState.animateScrollToItem((curPos + headerCount - 2).coerceAtLeast(0)) }
                    }
                }
            }
        }
    }
}


/** 납작한 알약 버튼 (Apple Music의 재생/셔플 버튼 느낌) */
@Composable
fun PillButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    val tick = rememberTick()
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.5f, stiffness = 650f), label = "pill")
    Row(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.10f))
            .clickable(interactionSource = src, indication = null) { tick(); onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, Modifier.size(20.dp), tint = AlbumAccent.color)
        Spacer(Modifier.width(6.dp))
        Text(label, fontWeight = FontWeight.SemiBold, color = AlbumAccent.color)
    }
}
