@file:OptIn(ExperimentalSharedTransitionApi::class)

package com.example.ytplaylist

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val SORTS = listOf("기본 순서", "제목순", "짧은 곡부터", "최근 추가된 순")

private fun totalLabel(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    return if (h > 0) "${h}시간 ${m}분" else "${m}분"
}

@Composable
fun PlaylistScreen(
    vm: MainViewModel,
    pl: Playlist,
    s: SharedTransitionScope?,
    a: AnimatedVisibilityScope?,
    bottomInset: Dp,
    onBack: () -> Unit,
    onTrackMenu: (Track, String, Int) -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    BackHandler { onBack() }
    var sort by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val name = if (pl.id == FAV_ID) "좋아요" else pl.name
    val total = remember(pl.tracks) { pl.tracks.sumOf { it.durationSec } }
    val downloading = PinnedDownloader.progress[pl.id]

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(bottom = bottomInset)) {
        // ----- 상단 막대 -----
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "뒤로") }
            Spacer(Modifier.weight(1f))
            Box {
                IconButton(onClick = { sortOpen = true }) { Icon(Icons.Default.Sort, "정렬") }
                DropdownMenu(expanded = sortOpen, onDismissRequest = { sortOpen = false }) {
                    SORTS.forEachIndexed { i, label ->
                        DropdownMenuItem(
                            text = { Text(label) },
                            trailingIcon = { if (sort == i) Icon(Icons.Default.Check, null) },
                            onClick = { sort = i; sortOpen = false }
                        )
                    }
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "메뉴") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    if (pl.url.isNotBlank()) {
                        DropdownMenuItem(
                            text = { Text("새로고침") },
                            leadingIcon = { Icon(Icons.Default.Refresh, null) },
                            onClick = { menuOpen = false; vm.refreshPlaylist(pl.id) }
                        )
                    }
                    if (pl.tracks.isNotEmpty()) {
                        if (downloading != null) {
                            DropdownMenuItem(
                                text = { Text("오프라인 저장 멈추기") },
                                leadingIcon = { Icon(Icons.Default.Close, null) },
                                onClick = { menuOpen = false; vm.cancelOffline(pl.id) }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("오프라인에 저장") },
                                leadingIcon = { Icon(Icons.Default.Download, null) },
                                onClick = { menuOpen = false; vm.startOffline(pl.id) }
                            )
                            DropdownMenuItem(
                                text = { Text("저장한 곡 지우기") },
                                leadingIcon = { Icon(Icons.Default.DeleteSweep, null) },
                                onClick = { menuOpen = false; vm.removeOffline(pl.id) }
                            )
                        }
                    }
                    if (pl.id != FAV_ID) {
                        DropdownMenuItem(
                            text = { Text("맨 앞으로 옮기기") },
                            leadingIcon = { Icon(Icons.Default.VerticalAlignTop, null) },
                            onClick = { menuOpen = false; vm.movePlaylistToFront(pl.id) }
                        )
                        DropdownMenuItem(
                            text = { Text("이름 바꾸기") },
                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                            onClick = { menuOpen = false; onRename() }
                        )
                        DropdownMenuItem(
                            text = { Text("삭제") },
                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                            onClick = { menuOpen = false; onDelete() }
                        )
                    }
                }
            }
        }

        // ----- 머리: 커버 + 이름 (홈의 카드에서 이어져 커져요) -----
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            PlaylistCover(pl, Modifier.sharedEl("cover-${pl.id}", s, a).size(116.dp), 22.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    name,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.sharedBox("title-${pl.id}", s, a)
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "${pl.tracks.size}곡 · 총 ${totalLabel(total)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.riseIn(a, 80)
                )
                Text(
                    when {
                        pl.id == FAV_ID -> "내가 좋아요한 곡"
                        pl.url.isBlank() -> "직접 만든 플레이리스트"
                        else -> "YouTube 플레이리스트"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.riseIn(a, 120)
                )
            }
        }

        // ----- 재생 버튼 -----
        if (pl.tracks.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp).riseIn(a, 120, 2),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GlassSurface(
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(25.dp),
                    tint = MaterialTheme.colorScheme.primary,
                    onClick = { vm.playAllIn(pl.id) }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, null, Modifier.size(22.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("전체 재생", fontWeight = FontWeight.SemiBold)
                    }
                }
                GlassSurface(
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(25.dp),
                    strong = true,
                    onClick = { vm.shuffleIn(pl.id) }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shuffle, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("셔플 재생", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        } else {
            Spacer(Modifier.height(14.dp))
        }

        if (downloading != null) {
            val (done, all) = downloading
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(
                    progress = { if (all > 0) done / all.toFloat() else 0f },
                    modifier = Modifier.weight(1f).height(4.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text("오프라인 저장 $done/$all", style = MaterialTheme.typography.labelSmall)
                TextButton(onClick = { vm.cancelOffline(pl.id) }) { Text("멈추기") }
            }
        }

        vm.error?.let {
            Box(Modifier.padding(horizontal = 16.dp)) { ErrorCard(it, vm.retry, vm::clearError) }
        }

        // ----- 곡 목록 판 -----
        when {
            pl.tracks.isEmpty() && vm.loading -> SkeletonList(Modifier.weight(1f).padding(horizontal = 16.dp))

            pl.tracks.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        pl.id == FAV_ID -> "좋아요한 곡이 없어요.\n곡을 길게 누르거나 플레이어의 ♥를 눌러 담아보세요"
                        pl.url.isBlank() -> "빈 플레이리스트예요.\n다른 목록의 곡을 길게 눌러 '내 플레이리스트에 추가'로 담아보세요"
                        else -> "곡이 없어요. ⋮ 메뉴의 새로고침을 눌러보세요"
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            else -> {
                val shown = remember(pl.tracks, query, sort) {
                    val base = pl.tracks.withIndex().filter {
                        query.isBlank() ||
                            it.value.title.contains(query, ignoreCase = true) ||
                            it.value.artist.contains(query, ignoreCase = true)
                    }
                    when (sort) {
                        1 -> base.sortedBy { it.value.title.lowercase() }
                        2 -> base.sortedBy { it.value.durationSec }
                        3 -> base.reversed()
                        else -> base
                    }
                }
                val listState = rememberLazyListState()
                LaunchedEffect(sort) { listState.scrollToItem(0) }
                val curPos = if (vm.playingPid == pl.id) shown.indexOfFirst { it.value.url == vm.playingUrl } else -1
                val showJump by remember(curPos) {
                    derivedStateOf { curPos >= 0 && listState.layoutInfo.visibleItemsInfo.none { it.index == curPos } }
                }

                GlassSurface(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 8.dp).riseIn(a, 160, 3),
                    shape = RoundedCornerShape(28.dp),
                    strong = true
                ) {
                    Column(Modifier.fillMaxSize()) {
                        GlassSurface(
                            modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 4.dp),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            TextField(
                                value = query,
                                onValueChange = { query = it },
                                placeholder = { Text("곡 검색") },
                                leadingIcon = { Icon(Icons.Default.Search, null) },
                                trailingIcon = {
                                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                                        Icon(Icons.Default.Close, "지우기")
                                    }
                                },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(start = 6.dp, end = 6.dp, top = 4.dp, bottom = 72.dp)
                            ) {
                                items(shown, key = { it.index }, contentType = { "track" }) { (i, t) ->
                                    val isCurrent = vm.playingPid == pl.id && t.url == vm.playingUrl
                                    val cached = t.url in vm.cachedUrls
                                    val pinned = t.url in vm.pinnedUrls
                                    TrackRow(
                                        t = t,
                                        selected = isCurrent,
                                        playing = isCurrent && vm.isPlaying,
                                        cached = cached,
                                        pinned = pinned,
                                        favorite = pl.id != FAV_ID && vm.isFavorite(t.url),
                                        dimmed = !vm.online && !cached && !pinned,
                                        onClick = { vm.playIn(pl.id, i) },
                                        onLongClick = { onTrackMenu(t, pl.id, i) },
                                        onSwipeRight = { vm.playNext(t, pl.id) },
                                        onSwipeLeft = { vm.addToQueue(t, pl.id) },
                                        modifier = Modifier.animateItem()
                                    )
                                }
                            }
                            if (showJump) {
                                Box(Modifier.align(Alignment.BottomEnd).padding(12.dp)) {
                                    GlassChip("현재 곡", icon = Icons.Default.MyLocation) {
                                        scope.launch { listState.animateScrollToItem((curPos - 2).coerceAtLeast(0)) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
