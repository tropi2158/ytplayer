@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.net.Uri
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** 유튜브 영상 URL을 재생 직전에 실제 오디오 스트림 URL로 바꿔주는 Resolver (URL 만료 대응). */
private class YtResolver : ResolvingDataSource.Resolver {
    private val cache = ConcurrentHashMap<String, Pair<String, Long>>()

    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val key = dataSpec.uri.toString()
        if (!(key.contains("youtube.com/watch") || key.contains("youtu.be/"))) return dataSpec

        val now = SystemClock.elapsedRealtime()
        val hit = cache[key]
        val resolved = if (hit != null && now - hit.second < 3 * 3600_000L) {
            hit.first
        } else {
            val url = try {
                YtRepo.resolveAudioUrl(key)
            } catch (e: Exception) {
                throw IOException("스트림 추출 실패: ${e.message}", e)
            }
            cache[key] = url to now
            url
        }
        return dataSpec.withUri(Uri.parse(resolved))
    }
}

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var errorStreak = 0

    override fun onCreate() {
        super.onCreate()

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(NewPipeDownloader.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
        val upstream = ResolvingDataSource.Factory(http, YtResolver())
        // 캐시가 바깥, 스트림 추출이 안쪽: 캐시된 곡은 인터넷/추출 없이 재생됨 (캐시 키 = 영상 URL)
        val cacheFactory = CacheDataSource.Factory()
            .setCache(CacheProvider.get(this))
            .setUpstreamDataSourceFactory(upstream)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        // 한 곡을 통째로 미리 받아 캐시되도록 버퍼를 길게 (최대 10분)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 600_000, 2_500, 5_000)
            .setTargetBufferBytes(64 * 1024 * 1024)
            .build()

        val player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(cacheFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) errorStreak = 0
            }

            // 추출 실패한 곡은 건너뛰기 (연속 5회 실패 시 중단)
            override fun onPlayerError(error: PlaybackException) {
                if (++errorStreak <= 5 && player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }
            }
        })

        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
