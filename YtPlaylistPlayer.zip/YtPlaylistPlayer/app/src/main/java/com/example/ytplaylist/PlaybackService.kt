@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.ServiceInfo
import android.graphics.drawable.BitmapDrawable
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** 유튜브 영상 URL을 재생 직전에 실제 오디오 스트림 URL로 바꿔주는 Resolver (URL 만료 대응) */
internal class YtResolver(private val lowQuality: () -> Boolean = { false }) : ResolvingDataSource.Resolver {
    private val cache = ConcurrentHashMap<String, Pair<String, Long>>()

    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val key = dataSpec.uri.toString()
        if (!(key.contains("youtube.com/watch") || key.contains("youtu.be/"))) return dataSpec

        val now = SystemClock.elapsedRealtime()
        val hit = cache[key]
        val resolved = if (hit != null && now - hit.second < 3 * 3600_000L) {
            hit.first
        } else {
            val url = try {
                YtRepo.resolveAudioUrl(key, lowQuality())
            } catch (e: Exception) {
                throw IOException("스트림 추출 실패: ${e.message}", e)
            }
            cache[key] = url to now
            url
        }
        return dataSpec.withUri(Uri.parse(resolved))
    }
}

/** 재생 서비스 -> 화면으로 보내는 짧은 알림 문구 */
object PlaybackEvents {
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
}

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null
    private var errorStreak = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    private val prefetchExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var prefetchWriter: CacheWriter? = null
    private lateinit var prefetchFactory: CacheDataSource.Factory

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var segments: List<LongRange> = emptyList()
    private var segmentsFor = ""
    private var lastTickAt = 0L
    private var listenedThisItem = 0L
    private var countedThisItem = false
    private var lastStatsSave = 0L
    private var alarmRampStart = 0L
    private var alarmNotif = false
    private var deviceReady = false

    /**
     * 0.1초마다: 음악 아닌 구간 건너뛰기, 청취 통계, 페이드 전환/알람 볼륨 조절
     * (재생 중일 때만 돌아요)
     */
    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 100L)
        }
    }

    /** 이어폰/블루투스가 연결되면 자동 재생 */
    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            if (!deviceReady) {
                deviceReady = true // 등록 직전에 이미 연결돼 있던 기기는 무시
                return
            }
            if (!prefs.getBoolean("auto_play_connect", false)) return
            val types = mutableSetOf(
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_USB_HEADSET
            )
            if (Build.VERSION.SDK_INT >= 31) types.add(AudioDeviceInfo.TYPE_BLE_HEADSET)
            val headset = addedDevices?.any { it.isSink && it.type in types } == true
            val p = exo ?: return
            if (headset && !p.isPlaying && p.mediaItemCount > 0) {
                if (p.playbackState == Player.STATE_IDLE) p.prepare()
                p.play()
                PlaybackEvents.messages.tryEmit("이어폰이 연결돼서 재생을 시작했어요")
            }
        }
    }

    /** 10초마다 '어디까지 들었는지' 저장 (이어듣기) */
    private val saveTick = object : Runnable {
        override fun run() {
            saveResume()
            handler.postDelayed(this, 10_000L)
        }
    }

    /** 앱이 꺼져 있을 때 알림/위젯/블루투스에서 '재생'을 누르면 마지막 곡부터 이어서 */
    private val sessionCallback = object : MediaSession.Callback {
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val pid = prefs.getString("resume_pid", null)
            val url = prefs.getString("resume_url", null)
            val pos = prefs.getLong("resume_pos", 0L)
            val pl = Store.load(prefs).firstOrNull { it.id == pid }
            if (pl == null || pl.tracks.isEmpty()) {
                return Futures.immediateFailedFuture(UnsupportedOperationException("재생 기록 없음"))
            }
            val idx = pl.tracks.indexOfFirst { it.url == url }
            return Futures.immediateFuture(
                MediaSession.MediaItemsWithStartPosition(
                    pl.tracks.map { it.toMediaItem(pl.id) },
                    idx.coerceAtLeast(0),
                    if (idx >= 0) pos else 0L
                )
            )
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("yt", Context.MODE_PRIVATE)

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(NewPipeDownloader.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
        val upstream = ResolvingDataSource.Factory(http, YtResolver { prefs.getBoolean("low_quality", false) })

        // 자동 캐시(들은 곡 저장) <- 스트림 추출
        val autoFactory = CacheDataSource.Factory()
            .setCache(CacheProvider.get(this))
            .setUpstreamDataSourceFactory(upstream)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        prefetchFactory = autoFactory

        // 오프라인 저장소(읽기 전용)를 맨 앞에: 저장된 곡은 인터넷/추출 없이 바로 재생
        val playFactory = CacheDataSource.Factory()
            .setCache(CacheProvider.getPinned(this))
            .setCacheWriteDataSinkFactory(null)
            .setUpstreamDataSourceFactory(autoFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        // 한 곡을 통째로 미리 받아 캐시되도록 버퍼를 길게 (최대 10분)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 600_000, 2_500, 5_000)
            .setTargetBufferBytes(64 * 1024 * 1024)
            .build()

        val player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(playFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        exo = player
        PlayerHolder.player = player

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(saveTick)
                handler.removeCallbacks(tick)
                if (isPlaying) {
                    errorStreak = 0
                    handler.postDelayed(saveTick, 10_000L)
                    lastTickAt = 0L
                    handler.post(tick)
                    if (alarmNotif) {
                        // 미디어 알림이 자리를 잡은 뒤 알람 알림 정리
                        handler.postDelayed({ cancelAlarmNotif() }, 3_000L)
                        handler.postDelayed({ cancelAlarmNotif() }, 10_000L)
                    }
                } else {
                    saveResume()
                    Stats.save(prefs)
                }
                updateWidget()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                listenedThisItem = 0L
                countedThisItem = false
                saveResume()
                updateWidget()
                schedulePrefetch()
                loadSegments()
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                updateWidget()
                loadWidgetArt(mediaMetadata.artworkUri?.toString())
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioFx.attach(applicationContext, audioSessionId)
            }

            // 추출에 실패한 곡은 건너뛰기 (재생 중일 때만, 연속 5회 실패 시 중단)
            override fun onPlayerError(error: PlaybackException) {
                if (player.playWhenReady && ++errorStreak <= 5 && player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }
            }
        })
        AudioFx.attach(applicationContext, player.audioSessionId)

        session = MediaSession.Builder(this, player)
            .setCallback(sessionCallback)
            .build()

        runCatching { getSystemService(AudioManager::class.java)?.registerAudioDeviceCallback(deviceCallback, handler) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == AlarmScheduler.ACTION_ALARM) {
            startAlarmForeground()
            startAlarmPlayback()
            AlarmScheduler.schedule(this) // 다음 날 알람 다시 예약
            return START_NOT_STICKY
        }
        return super.onStartCommand(intent, flags, startId)
    }

    // ---------------- 알람 ----------------
    private fun startAlarmForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.createNotificationChannel(NotificationChannel("alarm", "음악 알람", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "alarm")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("음악 알람")
            .setContentText("좋은 아침이에요. 음악을 틀고 있어요")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(open)
            .build()
        ServiceCompat.startForeground(
            this, 2001, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )
        alarmNotif = true
    }

    private fun cancelAlarmNotif() {
        if (!alarmNotif) return
        getSystemService(NotificationManager::class.java)?.cancel(2001)
        alarmNotif = false
    }

    private fun startAlarmPlayback() {
        val p = exo ?: return
        val all = Store.load(prefs)
        val pid = prefs.getString("alarm_pid", null)
        val pl = all.firstOrNull { it.id == pid && it.tracks.isNotEmpty() }
            ?: all.firstOrNull { it.tracks.isNotEmpty() } ?: return
        p.shuffleModeEnabled = true
        p.setMediaItems(pl.tracks.map { it.toMediaItem(pl.id) }, Random.nextInt(pl.tracks.size), 0L)
        p.volume = 0.08f
        alarmRampStart = SystemClock.elapsedRealtime()
        p.prepare()
        p.play()
    }

    // ---------------- 0.1초 타이머 ----------------
    private fun onTick() {
        val p = exo ?: return
        val now = SystemClock.elapsedRealtime()
        val dt = if (lastTickAt == 0L) 0L else (now - lastTickAt).coerceAtMost(1000L)
        lastTickAt = now
        val pos = p.currentPosition
        val dur = p.duration

        // 1) 뮤직비디오의 음악 아닌 구간 건너뛰기
        if (prefs.getBoolean("skip_offtopic", true)) {
            val seg = segments.firstOrNull { pos >= it.first && pos < it.last - 500 }
            if (seg != null) {
                p.seekTo(seg.last)
                PlaybackEvents.messages.tryEmit("음악이 아닌 구간을 건너뛰었어요")
                return
            }
        }

        // 2) 청취 통계 (30초 이상 들으면 1회로 셈)
        val item = p.currentMediaItem
        if (item != null && dt > 0) {
            listenedThisItem += dt
            val count = !countedThisItem && listenedThisItem >= 30_000L
            if (count) countedThisItem = true
            val md = p.mediaMetadata
            Stats.addListen(
                prefs, urlOf(item.mediaId), pidOf(item.mediaId),
                md.title?.toString().orEmpty(), md.artist?.toString().orEmpty(), md.artworkUri?.toString(),
                dt, count
            )
            if (now - lastStatsSave > 30_000L) {
                Stats.save(prefs)
                lastStatsSave = now
            }
        }

        // 3) 볼륨: 곡 처음/끝 페이드 + 알람 볼륨 서서히 키우기
        if (!SleepTimer.fading) {
            var v = 1f
            val fade = prefs.getInt("fade_ms", 0)
            if (fade > 0) {
                if (pos < fade) v = min(v, pos / fade.toFloat())
                if (dur != C.TIME_UNSET && dur > 0 && dur - pos < fade) v = min(v, (dur - pos) / fade.toFloat())
            }
            if (alarmRampStart > 0L) {
                val r = (now - alarmRampStart) / 40_000f
                if (r >= 1f) alarmRampStart = 0L else v = min(v, 0.08f + 0.92f * r)
            }
            v = v.coerceIn(0f, 1f)
            if (abs(p.volume - v) > 0.01f) p.volume = v
        }
    }

    private fun loadSegments() {
        val item = exo?.currentMediaItem ?: return
        val id = videoIdOf(urlOf(item.mediaId))
        if (id == null) {
            segments = emptyList()
            segmentsFor = ""
            return
        }
        if (segmentsFor == id) return
        segmentsFor = id
        segments = emptyList()
        if (!prefs.getBoolean("skip_offtopic", true)) return
        io.execute {
            val s = SponsorBlock.fetch(id)
            handler.post { if (segmentsFor == id) segments = s }
        }
    }

    private fun loadWidgetArt(uri: String?) {
        if (uri == null) return
        scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    val req = ImageRequest.Builder(this@PlaybackService).data(uri).size(192).allowHardware(false).build()
                    (applicationContext.imageLoader.execute(req).drawable as? BitmapDrawable)?.bitmap
                } catch (e: Exception) {
                    null
                }
            }
            if (bmp != null) {
                WidgetUpdater.art = bmp
                updateWidget()
            }
        }
    }

    private fun saveResume() {
        val p = exo ?: return
        if (p.mediaItemCount == 0) return
        val item = p.currentMediaItem ?: return
        val pid = pidOf(item.mediaId)
        if (pid.isEmpty()) return
        prefs.edit()
            .putString("resume_pid", pid)
            .putString("resume_url", urlOf(item.mediaId))
            .putLong("resume_pos", p.currentPosition)
            .apply()
    }

    private fun updateWidget() {
        val p = exo ?: return
        runCatching {
            WidgetUpdater.update(
                this,
                p.mediaMetadata.title?.toString().orEmpty(),
                p.mediaMetadata.artist?.toString().orEmpty(),
                p.isPlaying
            )
        }
    }

    /** 다음 곡을 미리 캐시에 받아두기 (곡 사이 끊김 방지, 오프라인에 강해짐) */
    private fun schedulePrefetch() {
        prefetchWriter?.cancel()
        val p = exo ?: return
        if (!prefs.getBoolean("prefetch", true)) return
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val net = cm.activeNetwork ?: return
        val caps = cm.getNetworkCapabilities(net) ?: return
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return
        if (prefs.getBoolean("prefetch_wifi", false) && cm.isActiveNetworkMetered) return

        val idx = p.nextMediaItemIndex
        if (idx == C.INDEX_UNSET) return
        val uri = p.getMediaItemAt(idx).localConfiguration?.uri ?: return
        val key = uri.toString()
        if (CacheProvider.isFullyCached(CacheProvider.get(this), key) ||
            CacheProvider.isFullyCached(CacheProvider.getPinned(this), key)
        ) return

        prefetchExecutor.execute {
            val writer = CacheWriter(prefetchFactory.createDataSource(), DataSpec(uri), null, null)
            prefetchWriter = writer
            try {
                writer.cache()
            } catch (e: Exception) {
                // 실패해도 재생에는 영향 없음
            } finally {
                if (prefetchWriter === writer) prefetchWriter = null
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        saveResume()
        Stats.save(prefs)
        runCatching { getSystemService(AudioManager::class.java)?.unregisterAudioDeviceCallback(deviceCallback) }
        scope.cancel()
        io.shutdownNow()
        handler.removeCallbacksAndMessages(null)
        SleepTimer.cancel()
        prefetchWriter?.cancel()
        prefetchExecutor.shutdownNow()
        PlayerHolder.player = null
        AudioFx.release()
        session?.run {
            player.release()
            release()
        }
        session = null
        exo = null
        super.onDestroy()
    }
}
