@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** 유튜브 영상 URL을 재생 직전에 실제 오디오 스트림 URL로 바꿔주는 Resolver (URL 만료 대응) */
internal class YtResolver(private val lowQuality: () -> Boolean = { false }) : ResolvingDataSource.Resolver {
    private val cache = ConcurrentHashMap<String, Pair<String, Long>>()

    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val key = dataSpec.uri.toString()
        if (!(key.contains("youtube.com/watch") || key.contains("youtu.be/"))) return dataSpec

        val now = SystemClock.elapsedRealtime()
        val hit = cache[key]
        val resolved = if (hit != null && now - hit.second < 3 * 3600_000L) {
            hit.first
        } else {
            val url = try {
                YtRepo.resolveAudioUrl(key, lowQuality())
            } catch (e: Exception) {
                throw IOException("스트림 추출 실패: ${e.message}", e)
            }
            cache[key] = url to now
            url
        }
        return dataSpec.withUri(Uri.parse(resolved))
    }
}

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null
    private var errorStreak = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    private val prefetchExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var prefetchWriter: CacheWriter? = null
    private lateinit var prefetchFactory: CacheDataSource.Factory

    /** 10초마다 '어디까지 들었는지' 저장 (이어듣기) */
    private val saveTick = object : Runnable {
        override fun run() {
            saveResume()
            handler.postDelayed(this, 10_000L)
        }
    }

    /** 앱이 꺼져 있을 때 알림/위젯/블루투스에서 '재생'을 누르면 마지막 곡부터 이어서 */
    private val sessionCallback = object : MediaSession.Callback {
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val pid = prefs.getString("resume_pid", null)
            val url = prefs.getString("resume_url", null)
            val pos = prefs.getLong("resume_pos", 0L)
            val pl = Store.load(prefs).firstOrNull { it.id == pid }
            if (pl == null || pl.tracks.isEmpty()) {
                return Futures.immediateFailedFuture(UnsupportedOperationException("재생 기록 없음"))
            }
            val idx = pl.tracks.indexOfFirst { it.url == url }
            return Futures.immediateFuture(
                MediaSession.MediaItemsWithStartPosition(
                    pl.tracks.map { it.toMediaItem(pl.id) },
                    idx.coerceAtLeast(0),
                    if (idx >= 0) pos else 0L
                )
            )
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("yt", Context.MODE_PRIVATE)

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(NewPipeDownloader.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
        val upstream = ResolvingDataSource.Factory(http, YtResolver { prefs.getBoolean("low_quality", false) })

        // 자동 캐시(들은 곡 저장) <- 스트림 추출
        val autoFactory = CacheDataSource.Factory()
            .setCache(CacheProvider.get(this))
            .setUpstreamDataSourceFactory(upstream)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        prefetchFactory = autoFactory

        // 오프라인 저장소(읽기 전용)를 맨 앞에: 저장된 곡은 인터넷/추출 없이 바로 재생
        val playFactory = CacheDataSource.Factory()
            .setCache(CacheProvider.getPinned(this))
            .setCacheWriteDataSinkFactory(null)
            .setUpstreamDataSourceFactory(autoFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        // 한 곡을 통째로 미리 받아 캐시되도록 버퍼를 길게 (최대 10분)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 600_000, 2_500, 5_000)
            .setTargetBufferBytes(64 * 1024 * 1024)
            .build()

        val player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(playFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        exo = player
        PlayerHolder.player = player

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(saveTick)
                if (isPlaying) {
                    errorStreak = 0
                    handler.postDelayed(saveTick, 10_000L)
                } else {
                    saveResume()
                }
                updateWidget()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                saveResume()
                updateWidget()
                schedulePrefetch()
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                updateWidget()
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioFx.attach(applicationContext, audioSessionId)
            }

            // 추출에 실패한 곡은 건너뛰기 (재생 중일 때만, 연속 5회 실패 시 중단)
            override fun onPlayerError(error: PlaybackException) {
                if (player.playWhenReady && ++errorStreak <= 5 && player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }
            }
        })
        AudioFx.attach(applicationContext, player.audioSessionId)

        session = MediaSession.Builder(this, player)
            .setCallback(sessionCallback)
            .build()
    }

    private fun saveResume() {
        val p = exo ?: return
        if (p.mediaItemCount == 0) return
        val item = p.currentMediaItem ?: return
        val pid = pidOf(item.mediaId)
        if (pid.isEmpty()) return
        prefs.edit()
            .putString("resume_pid", pid)
            .putString("resume_url", urlOf(item.mediaId))
            .putLong("resume_pos", p.currentPosition)
            .apply()
    }

    private fun updateWidget() {
        val p = exo ?: return
        runCatching {
            WidgetUpdater.update(
                this,
                p.mediaMetadata.title?.toString().orEmpty(),
                p.mediaMetadata.artist?.toString().orEmpty(),
                p.isPlaying
            )
        }
    }

    /** 다음 곡을 미리 캐시에 받아두기 (곡 사이 끊김 방지, 오프라인에 강해짐) */
    private fun schedulePrefetch() {
        prefetchWriter?.cancel()
        val p = exo ?: return
        if (!prefs.getBoolean("prefetch", true)) return
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val net = cm.activeNetwork ?: return
        val caps = cm.getNetworkCapabilities(net) ?: return
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return
        if (prefs.getBoolean("prefetch_wifi", false) && cm.isActiveNetworkMetered) return

        val idx = p.nextMediaItemIndex
        if (idx == C.INDEX_UNSET) return
        val uri = p.getMediaItemAt(idx).localConfiguration?.uri ?: return
        val key = uri.toString()
        if (CacheProvider.isFullyCached(CacheProvider.get(this), key) ||
            CacheProvider.isFullyCached(CacheProvider.getPinned(this), key)
        ) return

        prefetchExecutor.execute {
            val writer = CacheWriter(prefetchFactory.createDataSource(), DataSpec(uri), null, null)
            prefetchWriter = writer
            try {
                writer.cache()
            } catch (e: Exception) {
                // 실패해도 재생에는 영향 없음
            } finally {
                if (prefetchWriter === writer) prefetchWriter = null
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        saveResume()
        handler.removeCallbacksAndMessages(null)
        SleepTimer.cancel()
        prefetchWriter?.cancel()
        prefetchExecutor.shutdownNow()
        PlayerHolder.player = null
        AudioFx.release()
        session?.run {
            player.release()
            release()
        }
        session = null
        exo = null
        super.onDestroy()
    }
}
