@file:OptIn(UnstableApi::class)

package com.example.ytplaylist

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.ServiceInfo
import android.graphics.drawable.BitmapDrawable
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.source.ShuffleOrder.DefaultShuffleOrder
import androidx.media3.session.CommandButton
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import android.os.Bundle
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** 유튜브 영상 URL을 재생 직전에 실제 오디오 스트림 URL로 바꿔주는 Resolver (URL 만료 대응) */
internal class YtResolver(private val lowQuality: () -> Boolean = { false }) : ResolvingDataSource.Resolver {
    private val cache = ConcurrentHashMap<String, Pair<String, Long>>()

    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val key = dataSpec.uri.toString()
        if (!(key.contains("youtube.com/watch") || key.contains("youtu.be/"))) return dataSpec

        val now = SystemClock.elapsedRealtime()
        val hit = cache[key]
        val resolved = if (hit != null && now - hit.second < 3 * 3600_000L) {
            hit.first
        } else {
            val url = try {
                YtRepo.resolveAudioUrl(key, lowQuality())
            } catch (e: Exception) {
                throw IOException("스트림 추출 실패: ${e.message}", e)
            }
            cache[key] = url to now
            url
        }
        return dataSpec.withUri(Uri.parse(resolved))
    }
}

/** 재생 서비스 -> 화면으로 보내는 짧은 알림 문구 */
object PlaybackEvents {
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    /** 서비스(알림 좋아요 버튼)가 좋아요를 바꿈 -> 화면이 목록을 다시 읽음 */
    val favChangedByService = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
    /** 화면이 좋아요를 바꿈 -> 알림 버튼 모양 갱신 */
    val favChangedByUi = MutableSharedFlow<Unit>(extraBufferCapacity = 4)
}

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null
    private var errorStreak = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences

    private val prefetchExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var prefetchWriter: CacheWriter? = null
    private lateinit var prefetchFactory: CacheDataSource.Factory

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var segments: List<LongRange> = emptyList()
    private var segmentsFor = ""
    private var lastTickAt = 0L
    private var listenedThisItem = 0L
    private var lastItemUrl = ""
    private var energySum = 0f
    private var energyN = 0
    private var lastLyricIdx = -2
    private val bands = FloatArray(Spectrum.BANDS)
    private var bassAvg = 0f
    private var lastBuzz = 0L
    private var countedThisItem = false
    private var lastStatsSave = 0L
    private var alarmRampStart = 0L
    private var alarmNotif = false
    private var deviceReady = false
    private var lastLongSave = 0L
    private var queueSig = ""
    private var expectAppend = false
    private var radioBusy = false
    private val favCommand = SessionCommand("TOGGLE_FAV", Bundle.EMPTY)
    private var favUrls: Set<String> = emptySet()
    private var lastShake = 0L
    private var shakeOn = false

    /** 흔들어서 다음 곡 (재생 중일 때만 센서를 켜요) */
    private val shakeListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / SensorManager.GRAVITY_EARTH
            val now = SystemClock.elapsedRealtime()
            if (g > 2.6f && now - lastShake > 1500L) {
                lastShake = now
                val p = exo ?: return
                if (p.hasNextMediaItem()) {
                    p.seekToNextMediaItem()
                    PlaybackEvents.messages.tryEmit("흔들어서 다음 곡으로 넘겼어요")
                }
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private fun updateShake(playing: Boolean) {
        val want = playing && prefs.getBoolean("shake_skip", false)
        if (want == shakeOn) return
        val sm = getSystemService(SensorManager::class.java) ?: return
        if (want) {
            val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            sm.registerListener(shakeListener, acc, SensorManager.SENSOR_DELAY_UI)
        } else {
            sm.unregisterListener(shakeListener)
        }
        shakeOn = want
    }

    /**
     * 0.1초마다: 음악 아닌 구간 건너뛰기, 청취 통계, 페이드 전환/알람 볼륨 조절
     * (재생 중일 때만 돌아요)
     */
    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 100L)
        }
    }

    /** 이어폰/블루투스가 연결되면 자동 재생 */
    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            if (!deviceReady) {
                deviceReady = true // 등록 직전에 이미 연결돼 있던 기기는 무시
                return
            }
            if (!prefs.getBoolean("auto_play_connect", false)) return
            val types = mutableSetOf(
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_USB_HEADSET
            )
            if (Build.VERSION.SDK_INT >= 31) types.add(AudioDeviceInfo.TYPE_BLE_HEADSET)
            val headset = addedDevices?.any { it.isSink && it.type in types } == true
            val p = exo ?: return
            if (headset && !p.isPlaying && p.mediaItemCount > 0) {
                if (p.playbackState == Player.STATE_IDLE) p.prepare()
                p.play()
                PlaybackEvents.messages.tryEmit("이어폰이 연결돼서 재생을 시작했어요")
            }
        }
    }

    /** 10초마다 '어디까지 들었는지' 저장 (이어듣기) */
    private val saveTick = object : Runnable {
        override fun run() {
            saveResume()
            handler.postDelayed(this, 10_000L)
        }
    }

    /** 앱이 꺼져 있을 때 알림/위젯/블루투스에서 '재생'을 누르면 마지막 곡부터 이어서 */
    private val sessionCallback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon().add(favCommand).build()
            return MediaSession.ConnectionResult.accept(cmds, MediaSession.ConnectionResult.DEFAULT_PLAYER_COMMANDS)
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == "TOGGLE_FAV") {
                toggleFavFromNotification()
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_NOT_SUPPORTED))
        }

        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val pid = prefs.getString("resume_pid", null)
            val url = prefs.getString("resume_url", null)
            val pos = prefs.getLong("resume_pos", 0L)
            val pl = Store.load(prefs).firstOrNull { it.id == pid }
            if (pl == null || pl.tracks.isEmpty()) {
                return Futures.immediateFailedFuture(UnsupportedOperationException("재생 기록 없음"))
            }
            val idx = pl.tracks.indexOfFirst { it.url == url }
            return Futures.immediateFuture(
                MediaSession.MediaItemsWithStartPosition(
                    pl.tracks.map { it.toMediaItem(pl.id) },
                    idx.coerceAtLeast(0),
                    if (idx >= 0) pos else 0L
                )
            )
        }
    }

    companion object {
        private const val LYRIC_NOTIF = 4033
        /** 위젯 ♥ 버튼이 서비스에 바로 닿을 수 있게 */
        @Volatile var instance: PlaybackService? = null
    }

    fun isPlayingNow(): Boolean = exo?.isPlaying == true

    /** 위젯에서 누른 ♥ */
    fun toggleFavExternal() {
        handler.post { toggleFavFromNotification() }
    }

    override fun onCreate() {
        instance = this
        SongPrefs.init(this)
        SoundFx.load(this)
        super.onCreate()
        prefs = getSharedPreferences("yt", Context.MODE_PRIVATE)

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(NewPipeDownloader.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
        val upstream = ResolvingDataSource.Factory(http, YtResolver { prefs.getBoolean("low_quality", false) && isMetered() })

        // 자동 캐시(들은 곡 저장) <- 스트림 추출
        val autoFactory = CacheDataSource.Factory()
            .setCache(CacheProvider.get(this))
            .setUpstreamDataSourceFactory(upstream)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        prefetchFactory = autoFactory

        // 오프라인 저장소(읽기 전용)를 맨 앞에: 저장된 곡은 인터넷/추출 없이 바로 재생
        val playFactory = CacheDataSource.Factory()
            .setCache(CacheProvider.getPinned(this))
            .setCacheWriteDataSinkFactory(null)
            .setUpstreamDataSourceFactory(autoFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        // 한 곡을 통째로 미리 받아 캐시되도록 버퍼를 길게 (최대 10분)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 600_000, 2_500, 5_000)
            .setTargetBufferBytes(64 * 1024 * 1024)
            .build()

        // 재생되는 소리를 비주얼라이저로도 흘려보내요 (Spectrum)
        val renderers = object : androidx.media3.exoplayer.DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): androidx.media3.exoplayer.audio.AudioSink =
                androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(SoundFx.Processor(), androidx.media3.exoplayer.audio.TeeAudioProcessor(Spectrum.sink)))
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .build()
        }

        val player = ExoPlayer.Builder(this, renderers)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(playFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        exo = player
        PlayerHolder.player = player

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(saveTick)
                handler.removeCallbacks(tick)
                if (isPlaying) {
                    errorStreak = 0
                    handler.postDelayed(saveTick, 10_000L)
                    lastTickAt = 0L
                    handler.post(tick)
                    updateShake(true)
                    if (alarmNotif) {
                        // 미디어 알림이 자리를 잡은 뒤 알람 알림 정리
                        handler.postDelayed({ cancelAlarmNotif() }, 3_000L)
                        handler.postDelayed({ cancelAlarmNotif() }, 10_000L)
                    }
                } else {
                    saveResume()
                    Stats.save(prefs)
                    updateShake(false)
                }
                updateWidget()
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                if (shuffleModeEnabled) freshShuffle(player)
            }

            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                if (reason != Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) return
                val n = player.mediaItemCount
                val sig = if (n == 0) "0" else "$n|${player.getMediaItemAt(0).mediaId}|${player.getMediaItemAt(n - 1).mediaId}"
                val oldN = queueSig.substringBefore('|').toIntOrNull() ?: 0
                val changed = sig != queueSig
                queueSig = sig
                if (expectAppend) {
                    expectAppend = false
                    return
                }
                // 새 목록이 들어왔고 셔플 중이면: 매번 새로운 무작위 순서
                if (changed && player.shuffleModeEnabled && abs(n - oldN) > 1) freshShuffle(player)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) maybeExtendQueue(atEnd = true)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                updateFavButton()
                maybeExtendQueue(atEnd = false)
                // 방금 곡: 일찍 넘겼으면 '건너뜀', 끝까지 갔으면 '다 들음' + 소리 세기 기록
                val prev = lastItemUrl
                if (prev.isNotEmpty()) {
                    if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK && listenedThisItem < 30_000L) SongPrefs.markSkip(prev)
                    if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) SongPrefs.markDone(prev)
                    if (energyN > 80) SongPrefs.putEnergy(prev, energySum / energyN)
                }
                energySum = 0f
                energyN = 0
                lastLyricIdx = -2
                lastItemUrl = mediaItem?.mediaId?.let { urlOf(it) } ?: ""
                listenedThisItem = 0L
                countedThisItem = false
                val newUrl = mediaItem?.mediaId?.let { urlOf(it) } ?: ""
                if (AbLoop.url.isNotEmpty() && AbLoop.url != newUrl) AbLoop.clear()
                // 긴 곡이면 지난번 들은 곳부터
                if (newUrl.isNotEmpty() && prefs.getBoolean("long_resume", true) &&
                    reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT
                ) {
                    val saved = LongPositions.get(prefs, newUrl)
                    if (saved > 30_000L) {
                        player.seekTo(saved)
                        PlaybackEvents.messages.tryEmit("지난번 들은 ${fmtTime(saved)}부터 이어서 재생해요")
                    } else {
                        startAtSaved(player, newUrl, reason)
                    }
                } else if (newUrl.isNotEmpty()) {
                    startAtSaved(player, newUrl, reason)
                }
                saveResume()
                updateWidget()
                schedulePrefetch()
                loadSegments()
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                updateWidget()
                loadWidgetArt(mediaMetadata.artworkUri?.toString())
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioFx.attach(applicationContext, audioSessionId)
                SoundFx.attach(audioSessionId)
            }

            // 추출에 실패한 곡은 건너뛰기 (재생 중일 때만, 연속 5회 실패 시 중단)
            override fun onPlayerError(error: PlaybackException) {
                if (player.playWhenReady && ++errorStreak <= 5 && player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }
            }
        })
        AudioFx.attach(applicationContext, player.audioSessionId)
        SoundFx.attach(player.audioSessionId)
        handler.post(extraTick)

        session = MediaSession.Builder(this, player)
            .setCallback(sessionCallback)
            .build()

        runCatching { getSystemService(AudioManager::class.java)?.registerAudioDeviceCallback(deviceCallback, handler) }
        reloadFavs()
        updateFavButton()
        scope.launch {
            PlaybackEvents.favChangedByUi.collect {
                reloadFavs()
                updateFavButton()
            }
        }
    }

    // ---------------- 완전 무작위 셔플 ----------------
    /** 지금 곡을 맨 앞에 두고 나머지는 매번 새로 섞어요 */
    private fun freshShuffle(p: ExoPlayer) {
        val n = p.mediaItemCount
        if (n < 2) return
        val cur = p.currentMediaItemIndex.coerceIn(0, n - 1)
        val rnd = Random(System.nanoTime() xor java.security.SecureRandom().nextLong())
        val others = (0 until n).filter { it != cur }
        val urlAt = { i: Int -> urlOf(p.getMediaItemAt(i).mediaId) }
        val rest = when {
            // 분위기 이어 섞기: 소리 세기가 비슷한 곡끼리 이어지게
            prefs.getBoolean("mood_shuffle", false) -> ShuffleSmart.moodOrder(urlOf(p.getMediaItemAt(cur).mediaId), others, urlAt, rnd)
            // 건너뛴 곡 기억: 자주 넘긴 곡은 뒤로, 끝까지 듣는 곡은 앞으로 (확률적으로)
            prefs.getBoolean("smart_shuffle", true) -> ShuffleSmart.weightedOrder(others, urlAt, rnd)
            else -> others.shuffled(rnd)
        }
        val arr = IntArray(n)
        arr[0] = cur
        rest.forEachIndexed { i, v -> arr[i + 1] = v }
        p.setShuffleOrder(DefaultShuffleOrder(arr, rnd.nextLong()))
    }

    // ---------------- 비슷한 곡 이어 재생 ----------------
    private fun maybeExtendQueue(atEnd: Boolean) {
        val p = exo ?: return
        val force = prefs.getBoolean("radio_force", false)
        if (!force) {
            if (!prefs.getBoolean("autoplay_related", true)) return
            if (p.repeatMode != Player.REPEAT_MODE_OFF) return
            if (p.hasNextMediaItem()) return
        }
        if (radioBusy) return
        val item = p.currentMediaItem ?: return
        val url = urlOf(item.mediaId)
        if (videoIdOf(url) == null) return
        radioBusy = true
        if (force) prefs.edit().putBoolean("radio_force", false).apply()
        val existing = (0 until p.mediaItemCount).map { urlOf(p.getMediaItemAt(it).mediaId) }.toSet()
        io.execute {
            val tracks = runCatching { YtRepo.related(url) }.getOrDefault(emptyList())
                .filter { it.url !in existing }
                .distinctBy { it.url }
                .take(12)
            handler.post {
                radioBusy = false
                val pl = exo ?: return@post
                if (tracks.isEmpty()) return@post
                val start = pl.mediaItemCount
                expectAppend = true
                pl.addMediaItems(tracks.map { it.toMediaItem(RADIO_PID) })
                if (pl.shuffleModeEnabled) {
                    // 새 곡은 지금까지 순서 뒤에 이어 붙여요
                    val order = ArrayList<Int>()
                    val tl = pl.currentTimeline
                    var i = tl.getFirstWindowIndex(true)
                    while (i != C.INDEX_UNSET && order.size < pl.mediaItemCount) {
                        if (i < start) order.add(i)
                        i = tl.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, true)
                    }
                    for (k in start until pl.mediaItemCount) order.add(k)
                    if (order.size == pl.mediaItemCount) {
                        expectAppend = true
                        pl.setShuffleOrder(DefaultShuffleOrder(order.toIntArray(), Random.nextLong()))
                    }
                }
                PlaybackEvents.messages.tryEmit("비슷한 곡 ${tracks.size}개를 이어서 재생해요")
                if (atEnd || pl.playbackState == Player.STATE_ENDED) {
                    pl.seekTo(start, 0L)
                    pl.prepare()
                    pl.play()
                }
            }
        }
    }

    // ---------------- 알림·잠금화면 좋아요 버튼 ----------------
    private fun reloadFavs() {
        favUrls = Store.load(prefs).firstOrNull { it.id == FAV_ID }?.tracks?.map { it.url }?.toSet() ?: emptySet()
    }

    private fun updateFavButton() {
        val s = session ?: return
        val url = exo?.currentMediaItem?.mediaId?.let { urlOf(it) } ?: ""
        val on = url.isNotEmpty() && url in favUrls
        val btn = CommandButton.Builder()
            .setDisplayName(if (on) "좋아요 취소" else "좋아요")
            .setIconResId(if (on) R.drawable.ic_fav_on else R.drawable.ic_fav_off)
            .setSessionCommand(favCommand)
            .build()
        runCatching { s.setCustomLayout(listOf(btn)) }
        updateWidget()
    }

    private fun toggleFavFromNotification() {
        val p = exo ?: return
        val item = p.currentMediaItem ?: return
        val url = urlOf(item.mediaId)
        val all = Store.load(prefs).toMutableList()
        var fav = all.firstOrNull { it.id == FAV_ID } ?: Playlist(FAV_ID, "좋아요", "", emptyList()).also { all.add(0, it) }
        val on = fav.tracks.any { it.url == url }
        val track = all.flatMap { it.tracks }.firstOrNull { it.url == url } ?: Track(
            url,
            item.mediaMetadata.title?.toString().orEmpty(),
            item.mediaMetadata.artist?.toString().orEmpty(),
            item.mediaMetadata.artworkUri?.toString(),
            p.duration.takeIf { it != C.TIME_UNSET }?.div(1000) ?: 0L
        )
        fav = fav.copy(tracks = if (on) fav.tracks.filterNot { it.url == url } else listOf(track) + fav.tracks)
        val updated = all.map { if (it.id == FAV_ID) fav else it }
        Store.save(prefs, updated)
        favUrls = fav.tracks.map { it.url }.toSet()
        updateFavButton()
        PlaybackEvents.favChangedByService.tryEmit(Unit)
        PlaybackEvents.messages.tryEmit(if (on) "좋아요를 취소했어요" else "좋아요에 추가했어요")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == AlarmScheduler.ACTION_ALARM) {
            startAlarmForeground()
            startAlarmPlayback()
            AlarmScheduler.schedule(this) // 다음 날 알람 다시 예약
            return START_NOT_STICKY
        }
        return super.onStartCommand(intent, flags, startId)
    }

    // ---------------- 알람 ----------------
    private fun startAlarmForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.createNotificationChannel(NotificationChannel("alarm", "음악 알람", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "alarm")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("음악 알람")
            .setContentText("좋은 아침이에요. 음악을 틀고 있어요")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(open)
            .build()
        ServiceCompat.startForeground(
            this, 2001, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )
        alarmNotif = true
    }

    private fun cancelAlarmNotif() {
        if (!alarmNotif) return
        getSystemService(NotificationManager::class.java)?.cancel(2001)
        alarmNotif = false
    }

    private fun startAlarmPlayback() {
        val p = exo ?: return
        val all = Store.load(prefs)
        val pid = prefs.getString("alarm_pid", null)
        val pl = all.firstOrNull { it.id == pid && it.tracks.isNotEmpty() }
            ?: all.firstOrNull { it.tracks.isNotEmpty() } ?: return
        p.shuffleModeEnabled = true
        p.setMediaItems(pl.tracks.map { it.toMediaItem(pl.id) }, Random.nextInt(pl.tracks.size), 0L)
        p.volume = 0.08f
        alarmRampStart = SystemClock.elapsedRealtime()
        p.prepare()
        p.play()
    }

    // ---------------- 0.1초 타이머 ----------------
    private fun onTick() {
        val p = exo ?: return
        val now = SystemClock.elapsedRealtime()
        val dt = if (lastTickAt == 0L) 0L else (now - lastTickAt).coerceAtMost(1000L)
        lastTickAt = now
        val pos = p.currentPosition
        val dur = p.duration

        // 1) 뮤직비디오의 음악 아닌 구간 건너뛰기
        if (prefs.getBoolean("skip_offtopic", true)) {
            val seg = segments.firstOrNull { pos >= it.first && pos < it.last - 500 }
            if (seg != null) {
                p.seekTo(seg.last)
                PlaybackEvents.messages.tryEmit("음악이 아닌 구간을 건너뛰었어요")
                return
            }
        }

        // 1-2) A-B 구간 반복
        if (AbLoop.active && item0Url(p) == AbLoop.url && pos >= AbLoop.b) {
            p.seekTo(AbLoop.a)
            return
        }

        // 1-3) 긴 곡 위치 기억 (5초마다)
        if (dur != C.TIME_UNSET && dur > 10 * 60_000L && now - lastLongSave > 5_000L) {
            lastLongSave = now
            val u = item0Url(p)
            if (u.isNotEmpty()) {
                LongPositions.put(prefs, u, if (pos > 30_000L && dur - pos > 60_000L) pos else 0L)
            }
        }

        // 2) 청취 통계 (30초 이상 들으면 1회로 셈)
        val item = p.currentMediaItem
        if (item != null && dt > 0) {
            listenedThisItem += dt
            val count = !countedThisItem && listenedThisItem >= 30_000L
            if (count) {
                countedThisItem = true
                SongPrefs.addDay(Stats.dayKey(now), urlOf(item.mediaId))
            }
            val md = p.mediaMetadata
            Stats.addListen(
                prefs, urlOf(item.mediaId), pidOf(item.mediaId),
                md.title?.toString().orEmpty(), md.artist?.toString().orEmpty(), md.artworkUri?.toString(),
                dt, count
            )
            if (now - lastStatsSave > 30_000L) {
                Stats.save(prefs)
                lastStatsSave = now
            }
        }

        // 3) 볼륨: 곡 처음/끝 페이드 + 알람 볼륨 서서히 키우기
        if (!SleepTimer.fading) {
            var v = 1f
            val fade = prefs.getInt("fade_ms", 0)
            if (fade > 0) {
                if (pos < fade) v = min(v, pos / fade.toFloat())
                if (dur != C.TIME_UNSET && dur > 0 && dur - pos < fade) v = min(v, (dur - pos) / fade.toFloat())
            }
            if (alarmRampStart > 0L) {
                val r = (now - alarmRampStart) / 40_000f
                if (r >= 1f) alarmRampStart = 0L else v = min(v, 0.08f + 0.92f * r)
            }
            v = v.coerceIn(0f, 1f)
            if (abs(p.volume - v) > 0.01f) p.volume = v
        }
    }

    /** 곡마다 정해 둔 시작 지점부터 */
    private fun startAtSaved(player: Player, url: String, reason: Int) {
        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) return
        val st = SongPrefs.startMs[url] ?: return
        if (st > 0 && player.currentPosition < st) player.seekTo(st)
    }

    /**
     * 0.03초마다 (재생 중일 때만): 소리 세기 기록, 베이스 진동, 잠금화면 가사 한 줄
     */
    private val extraTick = object : Runnable {
        override fun run() {
            val p = exo
            var next = 500L
            if (p != null && p.isPlaying) {
                Spectrum.current(bands)
                // 1) 분위기용 소리 세기
                var sum = 0f
                for (v in bands) sum += v
                energySum += sum / bands.size
                energyN++
                // 2) 베이스 진동
                if (prefs.getBoolean("bass_haptic", false)) {
                    next = 30L
                    var low = 0f
                    for (i in 0 until 6) low += bands[i]
                    low /= 6f
                    val now = SystemClock.elapsedRealtime()
                    if (low > 0.5f && low - bassAvg > 0.14f && now - lastBuzz > 140L) {
                        lastBuzz = now
                        buzz(((low - 0.4f) * 400).toInt().coerceIn(40, 255))
                    }
                    bassAvg = bassAvg * 0.85f + low * 0.15f
                } else next = 100L
                // 3) 잠금화면 가사
                if (prefs.getBoolean("lock_lyrics", false)) updateLyricNotif(p)
            } else if (lastLyricIdx != -2) {
                getSystemService(NotificationManager::class.java)?.cancel(LYRIC_NOTIF)
                lastLyricIdx = -2
            }
            handler.postDelayed(this, next)
        }
    }

    private fun buzz(amp: Int) {
        val v = if (Build.VERSION.SDK_INT >= 31) getSystemService(android.os.VibratorManager::class.java)?.defaultVibrator
        else @Suppress("DEPRECATION") getSystemService(android.os.Vibrator::class.java)
        if (v == null || !v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) runCatching { v.vibrate(android.os.VibrationEffect.createOneShot(28L, amp)) }
    }

    /** 지금 부르는 가사 한 줄을 조용한 알림으로 (잠금화면에도 보여요) */
    private fun updateLyricNotif(p: Player) {
        val url = item0Url(p)
        val lines = LyricsBridge.lines
        if (LyricsBridge.url != url || lines.isEmpty()) return
        val pos = p.currentPosition + (SongPrefs.lyricOffset[url] ?: 0L) + 250L
        val idx = lines.indexOfLast { it.ms <= pos }
        if (idx == lastLyricIdx) return
        lastLyricIdx = idx
        val nm = getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("lyrics") == null) {
            nm.createNotificationChannel(
                android.app.NotificationChannel("lyrics", "잠금화면 가사", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
            )
        }
        val line = lines.getOrNull(idx)?.text?.ifBlank { "♪" } ?: "♪"
        val nextLine = lines.getOrNull(idx + 1)?.text.orEmpty()
        val n = androidx.core.app.NotificationCompat.Builder(this, "lyrics")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle(line)
            .setContentText(nextLine)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(PendingIntent.getActivity(this, 7, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
        runCatching { nm.notify(LYRIC_NOTIF, n) }
    }

    /** 모바일 데이터처럼 요금이 드는 연결인지 */
    private fun isMetered(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.isActiveNetworkMetered
    }

    private fun item0Url(p: Player): String = p.currentMediaItem?.mediaId?.let { urlOf(it) } ?: ""

    private fun loadSegments() {
        val item = exo?.currentMediaItem ?: return
        val id = videoIdOf(urlOf(item.mediaId))
        if (id == null) {
            segments = emptyList()
            segmentsFor = ""
            return
        }
        if (segmentsFor == id) return
        segmentsFor = id
        segments = emptyList()
        if (!prefs.getBoolean("skip_offtopic", true)) return
        io.execute {
            val s = SponsorBlock.fetch(id)
            handler.post { if (segmentsFor == id) segments = s }
        }
    }

    private fun loadWidgetArt(uri: String?) {
        if (uri == null) return
        scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    val req = ImageRequest.Builder(this@PlaybackService).data(uri).size(192).allowHardware(false).build()
                    (applicationContext.imageLoader.execute(req).drawable as? BitmapDrawable)?.bitmap
                } catch (e: Exception) {
                    null
                }
            }
            if (bmp != null) {
                WidgetUpdater.art = bmp
                updateWidget()
            }
        }
    }

    private fun saveResume() {
        val p = exo ?: return
        if (p.mediaItemCount == 0) return
        val item = p.currentMediaItem ?: return
        val pid = pidOf(item.mediaId)
        if (pid.isEmpty()) return
        prefs.edit()
            .putString("resume_pid", pid)
            .putString("resume_url", urlOf(item.mediaId))
            .putLong("resume_pos", p.currentPosition)
            .apply()
    }

    private fun updateWidget() {
        val p = exo ?: return
        val url = p.currentMediaItem?.let { urlOf(it.mediaId) }
        runCatching {
            WidgetUpdater.update(
                this,
                p.mediaMetadata.title?.toString().orEmpty(),
                p.mediaMetadata.artist?.toString().orEmpty(),
                p.isPlaying,
                url != null && url in favUrls
            )
        }
    }

    /** 다음 곡을 미리 캐시에 받아두기 (곡 사이 끊김 방지, 오프라인에 강해짐) */
    private fun schedulePrefetch() {
        prefetchWriter?.cancel()
        val p = exo ?: return
        if (!prefs.getBoolean("prefetch", true)) return
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val net = cm.activeNetwork ?: return
        val caps = cm.getNetworkCapabilities(net) ?: return
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return
        if (prefs.getBoolean("prefetch_wifi", false) && cm.isActiveNetworkMetered) return

        val idx = p.nextMediaItemIndex
        if (idx == C.INDEX_UNSET) return
        val uri = p.getMediaItemAt(idx).localConfiguration?.uri ?: return
        val key = uri.toString()
        if (CacheProvider.isFullyCached(CacheProvider.get(this), key) ||
            CacheProvider.isFullyCached(CacheProvider.getPinned(this), key)
        ) return

        prefetchExecutor.execute {
            val writer = CacheWriter(prefetchFactory.createDataSource(), DataSpec(uri), null, null)
            prefetchWriter = writer
            try {
                writer.cache()
            } catch (e: Exception) {
                // 실패해도 재생에는 영향 없음
            } finally {
                if (prefetchWriter === writer) prefetchWriter = null
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        saveResume()
        Stats.save(prefs)
        runCatching { getSystemService(AudioManager::class.java)?.unregisterAudioDeviceCallback(deviceCallback) }
        runCatching { getSystemService(SensorManager::class.java)?.unregisterListener(shakeListener) }
        scope.cancel()
        io.shutdownNow()
        handler.removeCallbacksAndMessages(null)
        SleepTimer.cancel()
        prefetchWriter?.cancel()
        prefetchExecutor.shutdownNow()
        PlayerHolder.player = null
        AudioFx.release()
        SoundFx.release()
        handler.removeCallbacks(extraTick)
        getSystemService(NotificationManager::class.java)?.cancel(LYRIC_NOTIF)
        session?.run {
            player.release()
            release()
        }
        session = null
        exo = null
        super.onDestroy()
    }
}
