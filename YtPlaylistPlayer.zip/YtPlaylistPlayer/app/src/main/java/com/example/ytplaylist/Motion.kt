package com.example.ytplaylist

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

/** 앱 전체에서 같이 쓰는 움직임 곡선 */
object Motion {
    /** 살짝 지나쳤다가 돌아오는 (통통 튀는) 곡선 */
    val Overshoot = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)
    /** 빠르게 출발해서 부드럽게 멈추는 곡선 */
    val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
}

/**
 * 재생 화면을 펼치는 정도(expand)를 그대로 따라, k번째 덩어리가 차례로 떠오르게.
 * 손가락으로 끄는 동안에도 실시간으로 따라와서 끊김 없이 이어져요.
 */
fun Modifier.expandStagger(expand: Animatable<Float, AnimationVector1D>, k: Int): Modifier = graphicsLayer {
    val e = expand.value
    val p = ((e - 0.18f - 0.07f * k) / 0.42f).coerceIn(0f, 1f)
    val q = Motion.Overshoot.transform(p)
    translationY = (1f - q) * (36 + 10 * k).dp.toPx()
    alpha = p
}
