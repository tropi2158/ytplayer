@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)

package com.example.ytplaylist

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** 도구 모음의 항목 */
enum class Tool(val label: String, val desc: String) {
    FOCUS("집중 모드", "뽀모도로 타이머 + 배경 소리"),
    STANDBY("스탠바이 화면", "큰 시계와 앨범 아트"),
    RECAP("나만의 결산", "많이 들은 곡·가수·시간"),
    CALENDAR("청취 달력", "날마다 얼마나 들었는지"),
    COLORS("색으로 둘러보기", "앨범 색깔별로 골라 듣기"),
    QUIZ("인트로 퀴즈", "앞부분 듣고 제목 맞히기"),
    STORAGE("저장 공간", "캐시·저장한 곡 정리"),
    SYNC("PC와 맞추기", "목록 옮기기 · 이어 듣기 링크")
}

private fun toolIcon(t: Tool) = when (t) {
    Tool.FOCUS -> Icons.Default.Timer
    Tool.STANDBY -> Icons.Default.Bedtime
    Tool.RECAP -> Icons.Default.AutoAwesome
    Tool.CALENDAR -> Icons.Default.CalendarMonth
    Tool.COLORS -> Icons.Default.Palette
    Tool.QUIZ -> Icons.Default.Quiz
    Tool.STORAGE -> Icons.Default.Storage
    Tool.SYNC -> Icons.Default.Devices
}

// ======================= 도구 모음 =======================

@Composable
fun ToolsSheet(onDismiss: () -> Unit, onPick: (Tool) -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text("도구 모음", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.heightIn(max = 560.dp)
            ) {
                items(Tool.entries) { t ->
                    Column(
                        Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.06f))
                            .clickable { onDismiss(); onPick(t) }.padding(14.dp)
                    ) {
                        Icon(toolIcon(t), null, tint = AlbumAccent.color)
                        Spacer(Modifier.height(8.dp))
                        Text(t.label, fontWeight = FontWeight.SemiBold)
                        Text(t.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolSheet(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = sheetColor()) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

// ======================= 집중 모드 =======================

@Composable
fun FocusSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { FocusMode.load(ctx) }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    ToolSheet("집중 모드", onDismiss) {
        Text("공부하는 동안 음악이 흐르고, 쉬는 시간이 되면 음악을 멈추고 알려줘요. 앱을 닫아도 재생이 이어지는 동안 동작해요.", style = MaterialTheme.typography.bodySmall, color = muted)
        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (FocusMode.running) fmtTime(FocusMode.remainingMs) else "${FocusMode.workMin}:00",
                    style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.ExtraBold
                )
                Text(
                    when {
                        !FocusMode.running -> "오늘 ${FocusMode.doneToday}세트 완료"
                        FocusMode.onBreak -> "쉬는 시간 · 오늘 ${FocusMode.doneToday}세트"
                        else -> "집중하는 중 · 오늘 ${FocusMode.doneToday}세트"
                    },
                    color = if (FocusMode.onBreak) AlbumAccent.color else muted
                )
            }
        }
        if (!FocusMode.running) {
            Text("공부 시간", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 25, 45, 50).forEach { m -> FilterChip(selected = FocusMode.workMin == m, onClick = { FocusMode.workMin = m; FocusMode.persist(ctx) }, label = { Text("${m}분") }) }
            }
            Text("쉬는 시간", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 15).forEach { m -> FilterChip(selected = FocusMode.breakMin == m, onClick = { FocusMode.breakMin = m; FocusMode.persist(ctx) }, label = { Text("${m}분") }) }
            }
        }
        SwitchRow("가사 없는 곡만", "가사가 있는 곡은 자동으로 넘겨요 (가사 검색 결과로 판단)", FocusMode.instrumentalOnly) {
            FocusMode.instrumentalOnly = it
            FocusMode.persist(ctx)
            if (it && FocusMode.running) vm.loadLyrics()
        }
        Text("배경 소리", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NoisePlayer.names.forEachIndexed { i, n -> FilterChip(selected = NoisePlayer.type == i, onClick = { NoisePlayer.select(i) }, label = { Text(n) }) }
        }
        if (NoisePlayer.type != 0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VolumeDown, null, tint = muted)
                Slider(value = NoisePlayer.volume, onValueChange = NoisePlayer::updateVolume, modifier = Modifier.weight(1f))
                Icon(Icons.Default.VolumeUp, null, tint = muted)
            }
        }
        Spacer(Modifier.height(4.dp))
        if (!FocusMode.running) {
            Button(onClick = {
                FocusMode.start(
                    ctx,
                    play = { if (!vm.isPlaying) { if (vm.playingUrl.isEmpty()) vm.handleShortcut("shuffle") else vm.togglePlay() } },
                    pause = { if (vm.isPlaying) vm.togglePlay() },
                    notify = { android.widget.Toast.makeText(ctx, it, android.widget.Toast.LENGTH_LONG).show() }
                )
                if (FocusMode.instrumentalOnly) vm.loadLyrics()
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("집중 시작") }
        } else {
            OutlinedButton(onClick = { FocusMode.stop(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("집중 모드 끝내기") }
        }
    }
}

// ======================= 스탠바이 화면 =======================

/** 충전하며 가로로 세워 둘 때: 큰 시계 + 앨범 아트 + 파동. 밤엔 어둡고 붉게. 누르면 닫혀요 */
@Composable
fun StandbyScreen(vm: MainViewModel, onExit: () -> Unit) {
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000L) } }
    val hour = Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY)
    val night = hour >= 22 || hour < 6
    val ink = if (night) Color(0xFFFF3B30).copy(alpha = 0.85f) else Color.White
    val landscape = LocalConfiguration.current.screenWidthDp > LocalConfiguration.current.screenHeightDp
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null) { onExit() }
    ) {
        if (!night && vm.nowArt != null) {
            AsyncImage(
                model = vm.nowArt, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(60.dp).graphicsLayerAlpha(0.35f)
            )
        }
        val clock: @Composable () -> Unit = {
            Column {
                Text(
                    SimpleDateFormat("HH:mm", Locale.KOREA).format(Date(now)),
                    fontSize = if (landscape) 120.sp else 96.sp, fontWeight = FontWeight.ExtraBold, color = ink,
                    letterSpacing = (-4).sp
                )
                Text(SimpleDateFormat("M월 d일 EEEE", Locale.KOREA).format(Date(now)), style = MaterialTheme.typography.titleLarge, color = ink.copy(alpha = 0.7f))
            }
        }
        val music: @Composable () -> Unit = {
            if (vm.playingUrl.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = vm.nowArt, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.size(if (landscape) 150.dp else 110.dp).clip(RoundedCornerShape(16.dp)).graphicsLayerAlpha(if (night) 0.4f else 1f)
                    )
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.widthIn(max = 320.dp)) {
                        Text(TitleClean.title(vm.nowTitle, vm.nowArtist), color = ink, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(TitleClean.artist(vm.nowArtist), color = ink.copy(alpha = 0.6f), maxLines = 1)
                        Spacer(Modifier.height(8.dp))
                        Row {
                            IconButton(onClick = vm::previous) { Icon(Icons.Default.SkipPrevious, "이전", tint = ink) }
                            IconButton(onClick = vm::togglePlay) { Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "재생", tint = ink) }
                            IconButton(onClick = vm::next) { Icon(Icons.Default.SkipNext, "다음", tint = ink) }
                        }
                    }
                }
            }
        }
        if (landscape) {
            Row(Modifier.fillMaxSize().padding(48.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                clock(); music()
            }
        } else {
            Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.SpaceEvenly) { clock(); music() }
        }
        Text(
            "아무 곳이나 누르면 닫혀요", style = MaterialTheme.typography.labelSmall, color = ink.copy(alpha = 0.35f),
            modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp)
        )
    }
}

private fun Modifier.graphicsLayerAlpha(a: Float) = this.then(Modifier.graphicsLayer { alpha = a })

/** 충전 중인지 */
fun isCharging(ctx: Context): Boolean {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
    return i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
}

// ======================= 결산 카드 =======================

@Composable
fun RecapSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snap = remember { vm.statsSnapshot() }
    val now = Calendar.getInstance()
    val ym = SimpleDateFormat("yyyyMM", Locale.US).format(now.time)
    val y = SimpleDateFormat("yyyy", Locale.US).format(now.time)
    val monthMs = snap.daily.filterKeys { it.startsWith(ym) }.values.sum()
    val yearMs = snap.daily.filterKeys { it.startsWith(y) }.values.sum()
    val top = snap.tracks.sortedByDescending { it.count }.filter { it.count > 0 }.take(5)
    val artists = snap.tracks.groupBy { TitleClean.artist(it.artist).ifBlank { "알 수 없음" } }
        .mapValues { (_, v) -> v.sumOf { it.ms } }.entries.sortedByDescending { it.value }.take(3)
    val peak = snap.hourly.withIndex().maxByOrNull { it.value }?.index ?: 21
    val peakLabel = when (peak) { in 5..10 -> "아침형 리스너"; in 11..16 -> "낮의 리스너"; in 17..21 -> "저녁의 리스너"; else -> "밤의 리스너" }
    val l0 = rememberGraphicsLayer(); val l1 = rememberGraphicsLayer(); val l2 = rememberGraphicsLayer(); val l3 = rememberGraphicsLayer()
    val layers = listOf(l0, l1, l2, l3)
    val pager = rememberPagerState { 4 }
    val bgArt = top.firstOrNull()?.thumb
    ToolSheet("나만의 결산", onDismiss) {
        Text("넘겨 보고, 마음에 드는 카드를 저장하거나 공유해요", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        HorizontalPager(state = pager, contentPadding = PaddingValues(horizontal = 12.dp), pageSpacing = 12.dp) { page ->
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                ShareCardFrame(layers[page]) {
                    AsyncImage(model = bgArt, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize().blur(40.dp))
                    Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.75f)))))
                    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Text("Playlist 결산 · ${now.get(Calendar.MONTH) + 1}월", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        when (page) {
                            0 -> Column {
                                Text("이번 달", color = Color.White.copy(alpha = 0.8f))
                                Text("${monthMs / 60_000}분", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                                Text("올해는 ${yearMs / 3_600_000}시간 ${(yearMs / 60_000) % 60}분 들었어요", color = Color.White.copy(alpha = 0.8f))
                            }
                            1 -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("가장 많이 들은 곡", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                                top.forEachIndexed { i, t ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("${i + 1}", color = AlbumAccent.color, fontWeight = FontWeight.ExtraBold, modifier = Modifier.width(22.dp))
                                        AsyncImage(model = t.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(36.dp).clip(RoundedCornerShape(6.dp)))
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(TitleClean.title(t.title, t.artist), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                            Text("${t.count}회", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                                if (top.isEmpty()) Text("아직 기록이 부족해요", color = Color.White.copy(alpha = 0.7f))
                            }
                            2 -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("가장 많이 들은 가수", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                                artists.forEachIndexed { i, (a, ms) ->
                                    Column {
                                        Text("${i + 1}. $a", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${ms / 60_000}분", color = Color.White.copy(alpha = 0.6f))
                                    }
                                }
                            }
                            else -> Column {
                                Text("나는", color = Color.White.copy(alpha = 0.8f))
                                Text(peakLabel, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 46.sp)
                                Text("주로 ${peak}시쯤 음악을 들어요", color = Color.White.copy(alpha = 0.8f))
                            }
                        }
                        Text("Playlist", color = Color.White.copy(alpha = 0.5f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            CardActions(scope, layers[pager.currentPage], ctx, "recap_${pager.currentPage}_${System.currentTimeMillis()}") {}
        }
    }
}

// ======================= 청취 달력 =======================

@Composable
fun CalendarSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val snap = remember { vm.statsSnapshot() }
    val byUrl = remember { snap.tracks.associateBy { it.url } }
    var picked by remember { mutableStateOf<String?>(null) }
    val weeks = 20
    // 오늘이 맨 오른쪽 열에 오도록, 일요일 시작 주로 맞춰서
    val cal = Calendar.getInstance()
    val todayDow = cal.get(Calendar.DAY_OF_WEEK) - 1
    cal.add(Calendar.DAY_OF_YEAR, -(weeks - 1) * 7 - todayDow)
    val days = remember {
        List(weeks * 7) { i ->
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, i)
            Stats.dayKey(c.timeInMillis)
        }
    }
    val today = Stats.dayKey(System.currentTimeMillis())
    fun level(ms: Long) = when { ms <= 0 -> 0; ms < 15 * 60_000 -> 1; ms < 45 * 60_000 -> 2; ms < 90 * 60_000 -> 3; else -> 4 }
    ToolSheet("청취 달력", onDismiss) {
        Text("최근 ${weeks}주 · 칸이 진할수록 많이 들은 날이에요. 칸을 누르면 그날 들은 곡이 보여요", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState(Int.MAX_VALUE)), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (w in 0 until weeks) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (d in 0 until 7) {
                        val key = days[w * 7 + d]
                        val future = key > today
                        val lv = level(snap.daily[key] ?: 0L)
                        Box(
                            Modifier.size(16.dp).clip(RoundedCornerShape(4.dp))
                                .background(
                                    if (future) Color.Transparent
                                    else if (lv == 0) Color.White.copy(alpha = 0.06f)
                                    else AlbumAccent.color.copy(alpha = 0.25f + 0.19f * lv)
                                )
                                .then(if (picked == key) Modifier.border(1.5.dp, Color.White, RoundedCornerShape(4.dp)) else Modifier)
                                .clickable(enabled = !future) { picked = key }
                        )
                    }
                }
            }
        }
        val total = snap.daily.filterKeys { it in days }.values.sum()
        Text("이 기간 동안 ${total / 3_600_000}시간 ${(total / 60_000) % 60}분 들었어요", fontWeight = FontWeight.SemiBold)
        picked?.let { key ->
            val label = runCatching { SimpleDateFormat("M월 d일 (E)", Locale.KOREA).format(SimpleDateFormat("yyyyMMdd", Locale.US).parse(key)!!) }.getOrDefault(key)
            HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
            Text("$label · ${(snap.daily[key] ?: 0L) / 60_000}분", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            val urls = SongPrefs.dayUrls(key)
            if (urls.isEmpty()) Text("이날 곡 기록이 없어요 (곡 기록은 이번 업데이트부터 쌓여요)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            urls.forEach { u ->
                val t = byUrl[u]
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { vm.openVideo(u) }.padding(4.dp)) {
                    AsyncImage(model = t?.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(40.dp).clip(RoundedCornerShape(6.dp)))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(TitleClean.title(t?.title ?: u, t?.artist ?: ""), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(TitleClean.artist(t?.artist ?: ""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
            }
        }
    }
}

// ======================= 색으로 둘러보기 =======================

object ColorIndex {
    var running by mutableStateOf(false)
        private set
    var done by mutableIntStateOf(0)
        private set
    var total by mutableIntStateOf(0)
        private set

    /** 아직 색을 모르는 곡의 썸네일을 작게 받아 대표 색을 기억해요 */
    suspend fun build(ctx: Context, tracks: List<Track>) {
        if (running) return
        val todo = tracks.filter { SongPrefs.colorOf(it.url) == null && it.thumb != null }
        total = todo.size
        done = 0
        if (todo.isEmpty()) return
        running = true
        try {
            withContext(Dispatchers.IO) {
                val batch = HashMap<String, Int>()
                for (t in todo) {
                    runCatching {
                        val req = ImageRequest.Builder(ctx).data(t.thumb).size(64).allowHardware(false).build()
                        val bmp = (ctx.imageLoader.execute(req).drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap
                        if (bmp != null) {
                            val p = Palette.from(bmp).maximumColorCount(12).generate()
                            val sw = p.vibrantSwatch ?: p.dominantSwatch
                            if (sw != null) batch[t.url] = sw.rgb
                        }
                    }
                    withContext(Dispatchers.Main) { done++ }
                    if (batch.size >= 20) { SongPrefs.putColors(batch); batch.clear() }
                }
                if (batch.isNotEmpty()) SongPrefs.putColors(batch)
            }
        } finally {
            running = false
        }
    }

    /** 0~11: 무지개 색 칸, 12: 무채색 */
    fun bucketOf(rgb: Int): Int {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(rgb, hsv)
        if (hsv[1] < 0.22f || hsv[2] < 0.2f) return 12
        return ((hsv[0] + 15f) / 30f).toInt() % 12
    }

    fun bucketColor(b: Int): Color =
        if (b == 12) Color(0xFF9E9E9E) else Color(android.graphics.Color.HSVToColor(floatArrayOf(b * 30f, 0.65f, 0.95f)))
}

@Composable
fun ColorSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val lib = remember { vm.playlists.flatMap { it.tracks }.distinctBy { it.url } }
    LaunchedEffect(Unit) { ColorIndex.build(ctx, lib) }
    val buckets = remember(ColorIndex.done, ColorIndex.running) {
        lib.mapNotNull { t -> SongPrefs.colorOf(t.url)?.let { ColorIndex.bucketOf(it) to t } }
            .groupBy({ it.first }, { it.second })
    }
    var picked by remember { mutableStateOf<Int?>(null) }
    ToolSheet("색으로 둘러보기", onDismiss) {
        if (ColorIndex.running) {
            Text("앨범 색을 살펴보는 중… ${ColorIndex.done}/${ColorIndex.total}", style = MaterialTheme.typography.bodySmall)
            LinearProgressIndicator(progress = { if (ColorIndex.total > 0) ColorIndex.done / ColorIndex.total.toFloat() else 0f }, modifier = Modifier.fillMaxWidth())
        } else {
            Text("색을 누르면 그 색 앨범의 곡들이 나와요", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            (0..12).forEach { b ->
                val n = buckets[b]?.size ?: 0
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(ColorIndex.bucketColor(b))
                        .then(if (picked == b) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                        .clickable(enabled = n > 0) { picked = b }
                        .graphicsLayer { alpha = if (n > 0) 1f else 0.25f },
                    contentAlignment = Alignment.Center
                ) { Text("$n", color = Color.Black.copy(alpha = 0.7f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium) }
            }
        }
        picked?.let { b ->
            val list = buckets[b].orEmpty()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${list.size}곡", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(onClick = { vm.playList(list.shuffled(), "__color__", 0); onDismiss() }) {
                    Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("섞어 듣기")
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list.take(40), key = { it.url }) { t ->
                    AsyncImage(
                        model = t.thumb, contentDescription = t.title, contentScale = ContentScale.Crop,
                        modifier = Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)).clickable { vm.playList(list, "__color__", list.indexOf(t)) }
                    )
                }
            }
        }
    }
}

// ======================= 인트로 퀴즈 =======================

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun QuizSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("yt", Context.MODE_PRIVATE) }
    val lib = remember { vm.playlists.flatMap { it.tracks }.distinctBy { it.url }.filter { it.title.isNotBlank() } }
    val player = remember {
        val http = androidx.media3.datasource.DefaultHttpDataSource.Factory().setUserAgent(NewPipeDownloader.USER_AGENT).setAllowCrossProtocolRedirects(true)
        val src = androidx.media3.datasource.ResolvingDataSource.Factory(http, YtResolver())
        androidx.media3.exoplayer.ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(ctx).setDataSourceFactory(src))
            .build()
    }
    val wasPlaying = remember { vm.isPlaying }
    DisposableEffect(Unit) {
        if (vm.isPlaying) vm.togglePlay()
        onDispose {
            player.release()
            if (wasPlaying && !vm.isPlaying) vm.togglePlay()
        }
    }
    var answer by remember { mutableStateOf<Track?>(null) }
    var options by remember { mutableStateOf<List<Track>>(emptyList()) }
    var chosen by remember { mutableStateOf<Track?>(null) }
    var loadingClip by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var rounds by remember { mutableIntStateOf(0) }
    var best by remember { mutableIntStateOf(prefs.getInt("quiz_best", 0)) }
    var streak by remember { mutableIntStateOf(0) }

    fun playClip(seconds: Long) {
        val a = answer ?: return
        scope.launch {
            loadingClip = true
            player.setMediaItem(androidx.media3.common.MediaItem.fromUri(a.url))
            player.prepare()
            player.seekTo(SongPrefs.startMs[a.url] ?: 0L)
            // 소리가 나기 시작할 때까지 기다렸다가 정해진 시간만 들려줘요
            var waited = 0
            while (player.playbackState != androidx.media3.common.Player.STATE_READY && waited < 150) { delay(100); waited++ }
            loadingClip = false
            player.play()
            delay(seconds * 1000)
            player.pause()
        }
    }

    fun next() {
        if (lib.size < 4) return
        val a = lib.random()
        answer = a
        options = (lib.filter { it.url != a.url }.shuffled().take(3) + a).shuffled()
        chosen = null
        playClip(3)
    }
    LaunchedEffect(Unit) { next() }

    ToolSheet("인트로 퀴즈", onDismiss) {
        if (lib.size < 4) {
            Text("곡이 4개 이상 있어야 퀴즈를 할 수 있어요")
            return@ToolSheet
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("점수 $score / $rounds", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("연속 $streak · 최고 $best", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
        Box(Modifier.fillMaxWidth().height(110.dp), contentAlignment = Alignment.Center) {
            if (loadingClip) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Text("곡을 불러오는 중…", style = MaterialTheme.typography.bodySmall)
            } else if (chosen != null) {
                AsyncImage(model = answer?.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(100.dp).clip(RoundedCornerShape(14.dp)))
            } else {
                Icon(Icons.Default.QuestionMark, null, Modifier.size(64.dp), tint = AlbumAccent.color)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { playClip(3) }, enabled = !loadingClip) { Text("3초 다시") }
            OutlinedButton(onClick = { playClip(8) }, enabled = !loadingClip && chosen == null) { Text("8초 힌트") }
        }
        options.forEach { o ->
            val right = chosen != null && o.url == answer?.url
            val wrong = chosen != null && o.url == chosen?.url && o.url != answer?.url
            Text(
                o.shownTitle,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(
                        when {
                            right -> Color(0xFF34C759).copy(alpha = 0.35f)
                            wrong -> Color(0xFFFF3B30).copy(alpha = 0.35f)
                            else -> Color.White.copy(alpha = 0.07f)
                        }
                    )
                    .clickable(enabled = chosen == null) {
                        chosen = o
                        rounds++
                        player.pause()
                        if (o.url == answer?.url) {
                            score++; streak++
                            if (streak > best) { best = streak; prefs.edit().putInt("quiz_best", best).apply() }
                        } else streak = 0
                    }
                    .padding(14.dp)
            )
        }
        if (chosen != null) {
            Button(onClick = { next() }, modifier = Modifier.fillMaxWidth()) { Text("다음 문제") }
        }
    }
}

// ======================= 저장 공간 =======================

@Composable
fun StorageSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pinnedAll by remember { mutableStateOf<List<Track>?>(null) }
    var stale by remember { mutableStateOf<List<Track>>(emptyList()) }
    suspend fun scan() {
        val lib = vm.playlists.flatMap { it.tracks }.distinctBy { it.url }
        val snap = vm.statsSnapshot()
        val last = snap.tracks.associate { it.url to it.last }
        val now = System.currentTimeMillis()
        val pinned = withContext(Dispatchers.Default) {
            val c = CacheProvider.getPinned(ctx)
            lib.filter { CacheProvider.isFullyCached(c, it.url) }
        }
        pinnedAll = pinned
        stale = pinned.filter { now - (last[it.url] ?: 0L) > 60L * 86_400_000L }
        vm.refreshCacheInfo()
    }
    LaunchedEffect(Unit) { scan() }
    fun mb(b: Long) = "%.0fMB".format(b / 1_048_576.0)
    ToolSheet("저장 공간", onDismiss) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StorageTile("자동 캐시", mb(vm.cacheBytes), Modifier.weight(1f))
            StorageTile("오프라인 저장", mb(vm.pinnedBytes), Modifier.weight(1f))
        }
        Text("자동 캐시는 들은 곡이 저절로 쌓이는 공간이에요. 비워도 다시 들으면 또 쌓여요.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = { vm.clearCache(); scope.launch { delay(500); scan() } }, modifier = Modifier.fillMaxWidth()) { Text("자동 캐시 비우기") }
        HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
        val p = pinnedAll
        if (p == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        } else {
            Text("오프라인 저장한 곡 ${p.size}개", fontWeight = FontWeight.SemiBold)
            vm.playlists.filter { pl -> pl.tracks.any { t -> p.any { it.url == t.url } } }.forEach { pl ->
                val n = pl.tracks.count { t -> p.any { it.url == t.url } }
                Text("· ${if (pl.id == FAV_ID) "좋아요" else pl.name}: ${n}/${pl.tracks.size}곡", style = MaterialTheme.typography.bodyMedium)
            }
            if (stale.isNotEmpty()) {
                Text("두 달 넘게 안 들은 저장 곡 ${stale.size}개", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(stale.take(30), key = { it.url }) { t ->
                        AsyncImage(model = t.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)))
                    }
                }
                Button(onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { CacheProvider.removePinned(ctx, stale.map { it.url }) }
                        android.widget.Toast.makeText(ctx, "${stale.size}곡을 지웠어요", android.widget.Toast.LENGTH_SHORT).show()
                        scan()
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("안 들은 저장 곡 지우기") }
            }
        }
    }
}

@Composable
private fun StorageTile(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.06f)).padding(14.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

// ======================= PC와 맞추기 =======================

@Composable
fun SyncSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u -> if (u != null) vm.exportTo(u) }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importFrom(u) }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    ToolSheet("PC와 맞추기", onDismiss) {
        Text("플레이리스트 옮기기", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("파일 하나로 폰과 PC의 목록·좋아요·직접 넣은 곡을 맞춰요. PC 버전 설정의 '가져오기/내보내기'와 같은 파일을 써요. 가져오면 기존 목록은 그대로 두고 없는 것만 더해요.", style = MaterialTheme.typography.bodySmall, color = muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { export.launch("playlist-backup.json") }, modifier = Modifier.weight(1f)) { Text("내보내기") }
            OutlinedButton(onClick = { import.launch(arrayOf("application/json", "text/plain", "*/*")) }, modifier = Modifier.weight(1f)) { Text("가져오기") }
        }
        HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
        Text("이어 듣기", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("지금 듣는 곡과 위치를 링크로 넘겨요. PC의 '플레이리스트 추가' 칸에 붙여 넣으면 그 위치부터 이어서 재생돼요. 반대로 PC에서 복사한 링크는 아래 '붙여 넣어 열기'로 이어 들어요.", style = MaterialTheme.typography.bodySmall, color = muted)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = {
                val link = vm.handoffLink()
                if (link == null) {
                    android.widget.Toast.makeText(ctx, "재생 중인 곡이 없어요", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("이어 듣기", link))
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link), "이어 듣기 링크").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }, modifier = Modifier.weight(1f)) { Text("링크 보내기") }
            OutlinedButton(onClick = {
                val t = ctx.getSystemService(ClipboardManager::class.java)?.primaryClip?.getItemAt(0)?.text?.toString()
                if (t.isNullOrBlank()) android.widget.Toast.makeText(ctx, "복사한 링크가 없어요", android.widget.Toast.LENGTH_SHORT).show()
                else { vm.handleSharedText(t); onDismiss() }
            }, modifier = Modifier.weight(1f)) { Text("붙여 넣어 열기") }
        }
    }
}
