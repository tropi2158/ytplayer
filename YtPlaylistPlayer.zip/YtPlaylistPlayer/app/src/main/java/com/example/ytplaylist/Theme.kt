package com.example.ytplaylist

import android.app.Activity
import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import java.util.Calendar

/** 흑백 테마 표식 색 (실제 화면 색은 monoScheme 사용) */
val MONO = Color(0xFF808080)

val ACCENTS = listOf(
    "레드" to Color(0xFFE53935),
    "오렌지" to Color(0xFFFB8C00),
    "옐로" to Color(0xFFF9A825),
    "그린" to Color(0xFF43A047),
    "틸" to Color(0xFF00897B),
    "블루" to Color(0xFF1E88E5),
    "인디고" to Color(0xFF5C6BC0),
    "퍼플" to Color(0xFF8E24AA),
    "핑크" to Color(0xFFD81B60),
    "흑백" to MONO
)

private fun monoScheme(dark: Boolean): ColorScheme =
    if (dark) darkColorScheme(
        primary = Color.White,
        onPrimary = Color.Black,
        primaryContainer = Color(0xFF2B2B2B),
        onPrimaryContainer = Color.White,
        secondary = Color(0xFFBDBDBD),
        onSecondary = Color.Black,
        background = Color.Black,
        onBackground = Color.White,
        surface = Color.Black,
        onSurface = Color.White,
        surfaceVariant = Color(0xFF1E1E1E),
        onSurfaceVariant = Color(0xFFB5B5B5),
        outline = Color(0xFF777777)
    ) else lightColorScheme(
        primary = Color.Black,
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE6E6E6),
        onPrimaryContainer = Color.Black,
        secondary = Color(0xFF555555),
        onSecondary = Color.White,
        background = Color.White,
        onBackground = Color.Black,
        surface = Color.White,
        onSurface = Color.Black,
        surfaceVariant = Color(0xFFF0F0F0),
        onSurfaceVariant = Color(0xFF555555),
        outline = Color(0xFF888888)
    )

private fun colorScheme(seed: Color, dark: Boolean): ColorScheme {
    // 너무 밝거나 어두운 색(앨범 아트에서 뽑은 색 등)은 글자가 잘 보이게 보정
    val c = when {
        !dark && seed.luminance() > 0.5f -> lerp(seed, Color.Black, 0.35f)
        dark && seed.luminance() < 0.08f -> lerp(seed, Color.White, 0.3f)
        else -> seed
    }
    return if (dark) darkColorScheme(
        primary = lerp(c, Color.White, 0.3f),
        onPrimary = Color(0xFF101010),
        primaryContainer = lerp(c, Color.Black, 0.55f),
        onPrimaryContainer = Color.White,
        secondary = lerp(c, Color.White, 0.3f),
        background = Color(0xFF111113),
        surface = Color(0xFF111113),
        surfaceVariant = Color(0xFF26262B),
        onSurfaceVariant = Color(0xFFC4C4CC)
    ) else lightColorScheme(
        primary = c,
        onPrimary = Color.White,
        primaryContainer = lerp(c, Color.White, 0.82f),
        onPrimaryContainer = lerp(c, Color.Black, 0.6f),
        secondary = c,
        background = Color(0xFFFAF9FB),
        surface = Color(0xFFFAF9FB),
        surfaceVariant = lerp(c, Color.White, 0.9f),
        onSurfaceVariant = Color(0xFF55555C)
    )
}

private fun currentHour(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

fun isNightHour(h: Int, start: Int, end: Int): Boolean = when {
    start == end -> false
    start < end -> h in start until end
    else -> h >= start || h < end
}

@Composable
fun YtTheme(vm: MainViewModel, content: @Composable () -> Unit) {
    val hour by produceState(initialValue = currentHour()) {
        while (true) {
            delay(60_000L)
            value = currentHour()
        }
    }
    val dark = when (vm.themeMode) {
        1 -> false
        2 -> true
        3 -> isNightHour(hour, vm.nightStart, vm.nightEnd)
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current

    val accentColor = ACCENTS[vm.accent.coerceIn(0, ACCENTS.lastIndex)].second
    val mono = accentColor == MONO
    val art = vm.artColor
    val seed = if (vm.useArtColor && art != null && !mono) art else accentColor

    val scheme = when {
        vm.dynamicColor && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        mono -> monoScheme(dark)
        else -> colorScheme(seed, dark)
    }

    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !dark
        controller.isAppearanceLightNavigationBars = !dark
    }

    val base = LocalDensity.current
    CompositionLocalProvider(
        LocalGlass provides vm.glass,
        LocalHaptics provides vm.haptics,
        LocalDensity provides Density(base.density, base.fontScale * vm.fontScale)
    ) {
        MaterialTheme(colorScheme = scheme, typography = PretendardTypography, content = content)
    }
}


// ======================= 글꼴: Pretendard (SIL OFL 1.1, assets/Pretendard-LICENSE.txt) =======================

val Pretendard = androidx.compose.ui.text.font.FontFamily(
    androidx.compose.ui.text.font.Font(R.font.pretendard_regular, androidx.compose.ui.text.font.FontWeight.Normal),
    androidx.compose.ui.text.font.Font(R.font.pretendard_medium, androidx.compose.ui.text.font.FontWeight.Medium),
    androidx.compose.ui.text.font.Font(R.font.pretendard_semibold, androidx.compose.ui.text.font.FontWeight.SemiBold),
    androidx.compose.ui.text.font.Font(R.font.pretendard_bold, androidx.compose.ui.text.font.FontWeight.Bold),
    androidx.compose.ui.text.font.Font(R.font.pretendard_extrabold, androidx.compose.ui.text.font.FontWeight.ExtraBold)
)

private val PretendardTypography: androidx.compose.material3.Typography = androidx.compose.material3.Typography().let { t ->
    fun androidx.compose.ui.text.TextStyle.p() = copy(fontFamily = Pretendard, letterSpacing = androidx.compose.ui.unit.TextUnit.Unspecified)
    // 큰 글씨는 자간을 살짝 좁혀서 단단하게
    fun androidx.compose.ui.text.TextStyle.tight(em: Float) = copy(fontFamily = Pretendard, letterSpacing = androidx.compose.ui.unit.TextUnit(em, androidx.compose.ui.unit.TextUnitType.Em))
    t.copy(
        displayLarge = t.displayLarge.tight(-0.03f), displayMedium = t.displayMedium.tight(-0.03f), displaySmall = t.displaySmall.tight(-0.03f),
        headlineLarge = t.headlineLarge.tight(-0.025f), headlineMedium = t.headlineMedium.tight(-0.025f), headlineSmall = t.headlineSmall.tight(-0.02f),
        titleLarge = t.titleLarge.tight(-0.015f), titleMedium = t.titleMedium.tight(-0.01f), titleSmall = t.titleSmall.p(),
        bodyLarge = t.bodyLarge.p(), bodyMedium = t.bodyMedium.p(), bodySmall = t.bodySmall.p(),
        labelLarge = t.labelLarge.p(), labelMedium = t.labelMedium.p(), labelSmall = t.labelSmall.p()
    )
}
