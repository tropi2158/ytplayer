package com.example.ytplaylist

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val ACCENTS = listOf(
    "레드" to Color(0xFFE53935),
    "오렌지" to Color(0xFFFB8C00),
    "옐로" to Color(0xFFF9A825),
    "그린" to Color(0xFF43A047),
    "틸" to Color(0xFF00897B),
    "블루" to Color(0xFF1E88E5),
    "인디고" to Color(0xFF5C6BC0),
    "퍼플" to Color(0xFF8E24AA),
    "핑크" to Color(0xFFD81B60)
)

private fun buildScheme(c: Color, dark: Boolean): ColorScheme =
    if (dark) darkColorScheme(
        primary = lerp(c, Color.White, 0.3f),
        onPrimary = Color(0xFF101010),
        primaryContainer = lerp(c, Color.Black, 0.55f),
        onPrimaryContainer = Color.White,
        secondary = lerp(c, Color.White, 0.3f),
        background = Color(0xFF111113),
        surface = Color(0xFF111113),
        surfaceVariant = Color(0xFF26262B),
        onSurfaceVariant = Color(0xFFC4C4CC)
    ) else lightColorScheme(
        primary = c,
        onPrimary = Color.White,
        primaryContainer = lerp(c, Color.White, 0.82f),
        onPrimaryContainer = lerp(c, Color.Black, 0.6f),
        secondary = c,
        background = Color(0xFFFAF9FB),
        surface = Color(0xFFFAF9FB),
        surfaceVariant = lerp(c, Color.White, 0.9f),
        onSurfaceVariant = Color(0xFF55555C)
    )

@Composable
fun YtTheme(vm: MainViewModel, content: @Composable () -> Unit) {
    val dark = when (vm.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val scheme = if (vm.dynamicColor && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        buildScheme(ACCENTS[vm.accent.coerceIn(0, ACCENTS.lastIndex)].second, dark)
    }

    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !dark
        controller.isAppearanceLightNavigationBars = !dark
    }

    MaterialTheme(colorScheme = scheme, content = content)
}
